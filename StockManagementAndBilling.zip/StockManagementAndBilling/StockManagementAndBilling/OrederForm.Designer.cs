﻿namespace StockManagementAndBilling
{
    partial class OrderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OrderForm));
            this.ClientSideMenu = new System.Windows.Forms.MenuStrip();
            this.searchItemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.unpaidOrderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.LogoRectangle = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.LogoLabel = new System.Windows.Forms.Label();
            this.GroupBox = new System.Windows.Forms.GroupBox();
            this.CompanyComboBox = new System.Windows.Forms.ComboBox();
            this.TransactionDate = new System.Windows.Forms.DateTimePicker();
            this.AddToCartButton = new System.Windows.Forms.Button();
            this.OrderNumberLabel = new System.Windows.Forms.Label();
            this.CurrentStockTextBox = new System.Windows.Forms.TextBox();
            this.TransactionLabel = new System.Windows.Forms.Label();
            this.CurrentStockLabel = new System.Windows.Forms.Label();
            this.OrderNumberTextBox = new System.Windows.Forms.TextBox();
            this.PriceTextBox = new System.Windows.Forms.TextBox();
            this.UnitPriceLabel = new System.Windows.Forms.Label();
            this.CloustomerNameLabel = new System.Windows.Forms.Label();
            this.QuantityTextBox = new System.Windows.Forms.TextBox();
            this.CoustomerNameTextBox = new System.Windows.Forms.TextBox();
            this.QuantityLabel = new System.Windows.Forms.Label();
            this.PaymentType = new System.Windows.Forms.Label();
            this.ItemsComboBox = new System.Windows.Forms.ComboBox();
            this.PaymentComboBox = new System.Windows.Forms.ComboBox();
            this.CompanyLabel = new System.Windows.Forms.Label();
            this.itemNameLabel = new System.Windows.Forms.Label();
            this.NewOrderButton = new System.Windows.Forms.Button();
            this.PrintPreviewButton = new System.Windows.Forms.Button();
            this.PrintOrderButton = new System.Windows.Forms.Button();
            this.ItemsGridView = new System.Windows.Forms.DataGridView();
            this.DiscountTextBox = new System.Windows.Forms.TextBox();
            this.DiscountLabel = new System.Windows.Forms.Label();
            this.TotalToPayLabel = new System.Windows.Forms.Label();
            this.TotalAmountTextBox = new System.Windows.Forms.TextBox();
            this.TotalToPayTextBox = new System.Windows.Forms.TextBox();
            this.TotalAmountLabel = new System.Windows.Forms.Label();
            this.CgstLabel = new System.Windows.Forms.Label();
            this.CgstTextBox = new System.Windows.Forms.TextBox();
            this.SgstLabel = new System.Windows.Forms.Label();
            this.SgstTextBox = new System.Windows.Forms.TextBox();
            this.CancelOrderButton = new System.Windows.Forms.Button();
            this.ContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.PrintDocument = new System.Drawing.Printing.PrintDocument();
            this.PrintPreviewDialog = new System.Windows.Forms.PrintPreviewDialog();
            this.ClientSideMenu.SuspendLayout();
            this.GroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ItemsGridView)).BeginInit();
            this.ContextMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // ClientSideMenu
            // 
            this.ClientSideMenu.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.ClientSideMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.searchItemToolStripMenuItem,
            this.toolStripMenuItem1,
            this.unpaidOrderToolStripMenuItem,
            this.toolStripMenuItem2,
            this.exitToolStripMenuItem});
            this.ClientSideMenu.Location = new System.Drawing.Point(0, 0);
            this.ClientSideMenu.Name = "ClientSideMenu";
            this.ClientSideMenu.Size = new System.Drawing.Size(1211, 29);
            this.ClientSideMenu.TabIndex = 15;
            this.ClientSideMenu.Text = "Menu";
            // 
            // searchItemToolStripMenuItem
            // 
            this.searchItemToolStripMenuItem.Name = "searchItemToolStripMenuItem";
            this.searchItemToolStripMenuItem.Size = new System.Drawing.Size(104, 25);
            this.searchItemToolStripMenuItem.Text = "&Search Item";
            this.searchItemToolStripMenuItem.Click += new System.EventHandler(this.searchItemToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Enabled = false;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(26, 25);
            this.toolStripMenuItem1.Text = "|";
            // 
            // unpaidOrderToolStripMenuItem
            // 
            this.unpaidOrderToolStripMenuItem.Name = "unpaidOrderToolStripMenuItem";
            this.unpaidOrderToolStripMenuItem.Size = new System.Drawing.Size(117, 25);
            this.unpaidOrderToolStripMenuItem.Text = "&Unpaid Order";
            this.unpaidOrderToolStripMenuItem.Click += new System.EventHandler(this.unpaidOrderToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Enabled = false;
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(26, 25);
            this.toolStripMenuItem2.Text = "|";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(46, 25);
            this.exitToolStripMenuItem.Text = "&Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click_1);
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.LogoRectangle});
            this.shapeContainer1.Size = new System.Drawing.Size(1211, 648);
            this.shapeContainer1.TabIndex = 17;
            this.shapeContainer1.TabStop = false;
            // 
            // LogoRectangle
            // 
            this.LogoRectangle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LogoRectangle.BackColor = System.Drawing.Color.Black;
            this.LogoRectangle.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.LogoRectangle.BorderColor = System.Drawing.Color.White;
            this.LogoRectangle.Location = new System.Drawing.Point(-13, 30);
            this.LogoRectangle.Name = "LogoRectangle";
            this.LogoRectangle.Size = new System.Drawing.Size(1239, 69);
            // 
            // LogoLabel
            // 
            this.LogoLabel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.LogoLabel.AutoSize = true;
            this.LogoLabel.BackColor = System.Drawing.Color.Black;
            this.LogoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogoLabel.ForeColor = System.Drawing.Color.White;
            this.LogoLabel.Location = new System.Drawing.Point(359, 40);
            this.LogoLabel.Name = "LogoLabel";
            this.LogoLabel.Size = new System.Drawing.Size(493, 46);
            this.LogoLabel.TabIndex = 18;
            this.LogoLabel.Text = "Stock Management & Billing";
            this.LogoLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.LogoLabel.ClientSizeChanged += new System.EventHandler(this.LogoLabel_ClientSizeChanged);
            // 
            // GroupBox
            // 
            this.GroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GroupBox.Controls.Add(this.CompanyComboBox);
            this.GroupBox.Controls.Add(this.TransactionDate);
            this.GroupBox.Controls.Add(this.AddToCartButton);
            this.GroupBox.Controls.Add(this.OrderNumberLabel);
            this.GroupBox.Controls.Add(this.CurrentStockTextBox);
            this.GroupBox.Controls.Add(this.TransactionLabel);
            this.GroupBox.Controls.Add(this.CurrentStockLabel);
            this.GroupBox.Controls.Add(this.OrderNumberTextBox);
            this.GroupBox.Controls.Add(this.PriceTextBox);
            this.GroupBox.Controls.Add(this.UnitPriceLabel);
            this.GroupBox.Controls.Add(this.CloustomerNameLabel);
            this.GroupBox.Controls.Add(this.QuantityTextBox);
            this.GroupBox.Controls.Add(this.CoustomerNameTextBox);
            this.GroupBox.Controls.Add(this.QuantityLabel);
            this.GroupBox.Controls.Add(this.PaymentType);
            this.GroupBox.Controls.Add(this.ItemsComboBox);
            this.GroupBox.Controls.Add(this.PaymentComboBox);
            this.GroupBox.Controls.Add(this.CompanyLabel);
            this.GroupBox.Controls.Add(this.itemNameLabel);
            this.GroupBox.Location = new System.Drawing.Point(25, 118);
            this.GroupBox.Name = "GroupBox";
            this.GroupBox.Size = new System.Drawing.Size(956, 222);
            this.GroupBox.TabIndex = 19;
            this.GroupBox.TabStop = false;
            // 
            // CompanyComboBox
            // 
            this.CompanyComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CompanyComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CompanyComboBox.FormattingEnabled = true;
            this.CompanyComboBox.Location = new System.Drawing.Point(242, 170);
            this.CompanyComboBox.Name = "CompanyComboBox";
            this.CompanyComboBox.Size = new System.Drawing.Size(153, 28);
            this.CompanyComboBox.TabIndex = 25;
            this.CompanyComboBox.SelectedIndexChanged += new System.EventHandler(this.CompanyComboBox_SelectedIndexChanged);
            // 
            // TransactionDate
            // 
            this.TransactionDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.TransactionDate.Enabled = false;
            this.TransactionDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TransactionDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.TransactionDate.Location = new System.Drawing.Point(567, 35);
            this.TransactionDate.Name = "TransactionDate";
            this.TransactionDate.Size = new System.Drawing.Size(224, 26);
            this.TransactionDate.TabIndex = 24;
            // 
            // AddToCartButton
            // 
            this.AddToCartButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.AddToCartButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddToCartButton.Location = new System.Drawing.Point(816, 89);
            this.AddToCartButton.Name = "AddToCartButton";
            this.AddToCartButton.Size = new System.Drawing.Size(123, 109);
            this.AddToCartButton.TabIndex = 5;
            this.AddToCartButton.Text = "Add To Cart";
            this.AddToCartButton.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.AddToCartButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.AddToCartButton.UseVisualStyleBackColor = true;
            this.AddToCartButton.Click += new System.EventHandler(this.AddToCartButton_Click);
            // 
            // OrderNumberLabel
            // 
            this.OrderNumberLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.OrderNumberLabel.AutoSize = true;
            this.OrderNumberLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OrderNumberLabel.Location = new System.Drawing.Point(25, 37);
            this.OrderNumberLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.OrderNumberLabel.Name = "OrderNumberLabel";
            this.OrderNumberLabel.Size = new System.Drawing.Size(109, 20);
            this.OrderNumberLabel.TabIndex = 8;
            this.OrderNumberLabel.Text = "Order Number";
            // 
            // CurrentStockTextBox
            // 
            this.CurrentStockTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.CurrentStockTextBox.Enabled = false;
            this.CurrentStockTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CurrentStockTextBox.Location = new System.Drawing.Point(671, 172);
            this.CurrentStockTextBox.Name = "CurrentStockTextBox";
            this.CurrentStockTextBox.ReadOnly = true;
            this.CurrentStockTextBox.Size = new System.Drawing.Size(120, 26);
            this.CurrentStockTextBox.TabIndex = 15;
            this.CurrentStockTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TransactionLabel
            // 
            this.TransactionLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.TransactionLabel.AutoSize = true;
            this.TransactionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TransactionLabel.Location = new System.Drawing.Point(428, 35);
            this.TransactionLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.TransactionLabel.Name = "TransactionLabel";
            this.TransactionLabel.Size = new System.Drawing.Size(131, 20);
            this.TransactionLabel.TabIndex = 9;
            this.TransactionLabel.Text = "Transaction Date";
            // 
            // CurrentStockLabel
            // 
            this.CurrentStockLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.CurrentStockLabel.AutoSize = true;
            this.CurrentStockLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CurrentStockLabel.Location = new System.Drawing.Point(667, 141);
            this.CurrentStockLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.CurrentStockLabel.Name = "CurrentStockLabel";
            this.CurrentStockLabel.Size = new System.Drawing.Size(107, 20);
            this.CurrentStockLabel.TabIndex = 10;
            this.CurrentStockLabel.Text = "Current Stock";
            // 
            // OrderNumberTextBox
            // 
            this.OrderNumberTextBox.Enabled = false;
            this.OrderNumberTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OrderNumberTextBox.Location = new System.Drawing.Point(159, 32);
            this.OrderNumberTextBox.Name = "OrderNumberTextBox";
            this.OrderNumberTextBox.ReadOnly = true;
            this.OrderNumberTextBox.Size = new System.Drawing.Size(218, 26);
            this.OrderNumberTextBox.TabIndex = 16;
            this.OrderNumberTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // PriceTextBox
            // 
            this.PriceTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.PriceTextBox.Enabled = false;
            this.PriceTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PriceTextBox.Location = new System.Drawing.Point(542, 172);
            this.PriceTextBox.Name = "PriceTextBox";
            this.PriceTextBox.ReadOnly = true;
            this.PriceTextBox.Size = new System.Drawing.Size(109, 26);
            this.PriceTextBox.TabIndex = 17;
            this.PriceTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // UnitPriceLabel
            // 
            this.UnitPriceLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.UnitPriceLabel.AutoSize = true;
            this.UnitPriceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UnitPriceLabel.Location = new System.Drawing.Point(546, 141);
            this.UnitPriceLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.UnitPriceLabel.Name = "UnitPriceLabel";
            this.UnitPriceLabel.Size = new System.Drawing.Size(77, 20);
            this.UnitPriceLabel.TabIndex = 11;
            this.UnitPriceLabel.Text = "Unit Price";
            // 
            // CloustomerNameLabel
            // 
            this.CloustomerNameLabel.AutoSize = true;
            this.CloustomerNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CloustomerNameLabel.Location = new System.Drawing.Point(25, 89);
            this.CloustomerNameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.CloustomerNameLabel.Name = "CloustomerNameLabel";
            this.CloustomerNameLabel.Size = new System.Drawing.Size(133, 20);
            this.CloustomerNameLabel.TabIndex = 12;
            this.CloustomerNameLabel.Text = "Coustomer Name";
            // 
            // QuantityTextBox
            // 
            this.QuantityTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.QuantityTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QuantityTextBox.Location = new System.Drawing.Point(411, 172);
            this.QuantityTextBox.Name = "QuantityTextBox";
            this.QuantityTextBox.Size = new System.Drawing.Size(112, 26);
            this.QuantityTextBox.TabIndex = 4;
            this.QuantityTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.QuantityTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.QuantityTextBox_KeyPress);
            // 
            // CoustomerNameTextBox
            // 
            this.CoustomerNameTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CoustomerNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CoustomerNameTextBox.Location = new System.Drawing.Point(159, 87);
            this.CoustomerNameTextBox.Name = "CoustomerNameTextBox";
            this.CoustomerNameTextBox.Size = new System.Drawing.Size(251, 26);
            this.CoustomerNameTextBox.TabIndex = 1;
            this.CoustomerNameTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.CoustomerNameTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CoustomerNameTextBox_KeyPress);
            // 
            // QuantityLabel
            // 
            this.QuantityLabel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.QuantityLabel.AutoSize = true;
            this.QuantityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QuantityLabel.Location = new System.Drawing.Point(428, 141);
            this.QuantityLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.QuantityLabel.Name = "QuantityLabel";
            this.QuantityLabel.Size = new System.Drawing.Size(68, 20);
            this.QuantityLabel.TabIndex = 13;
            this.QuantityLabel.Text = "Quantity";
            // 
            // PaymentType
            // 
            this.PaymentType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.PaymentType.AutoSize = true;
            this.PaymentType.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PaymentType.Location = new System.Drawing.Point(432, 89);
            this.PaymentType.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.PaymentType.Name = "PaymentType";
            this.PaymentType.Size = new System.Drawing.Size(109, 20);
            this.PaymentType.TabIndex = 14;
            this.PaymentType.Text = "Payment Type";
            // 
            // ItemsComboBox
            // 
            this.ItemsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ItemsComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemsComboBox.FormattingEnabled = true;
            this.ItemsComboBox.Location = new System.Drawing.Point(29, 170);
            this.ItemsComboBox.Name = "ItemsComboBox";
            this.ItemsComboBox.Size = new System.Drawing.Size(195, 28);
            this.ItemsComboBox.Sorted = true;
            this.ItemsComboBox.TabIndex = 3;
            this.ItemsComboBox.SelectedIndexChanged += new System.EventHandler(this.ItemsComboBox_SelectedIndexChanged);
            // 
            // PaymentComboBox
            // 
            this.PaymentComboBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.PaymentComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PaymentComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PaymentComboBox.FormattingEnabled = true;
            this.PaymentComboBox.Items.AddRange(new object[] {
            "Paid",
            "Unpaid"});
            this.PaymentComboBox.Location = new System.Drawing.Point(567, 85);
            this.PaymentComboBox.Name = "PaymentComboBox";
            this.PaymentComboBox.Size = new System.Drawing.Size(224, 28);
            this.PaymentComboBox.TabIndex = 2;
            // 
            // CompanyLabel
            // 
            this.CompanyLabel.AutoSize = true;
            this.CompanyLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CompanyLabel.Location = new System.Drawing.Point(266, 141);
            this.CompanyLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.CompanyLabel.Name = "CompanyLabel";
            this.CompanyLabel.Size = new System.Drawing.Size(76, 20);
            this.CompanyLabel.TabIndex = 23;
            this.CompanyLabel.Text = "Company";
            // 
            // itemNameLabel
            // 
            this.itemNameLabel.AutoSize = true;
            this.itemNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemNameLabel.Location = new System.Drawing.Point(25, 141);
            this.itemNameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.itemNameLabel.Name = "itemNameLabel";
            this.itemNameLabel.Size = new System.Drawing.Size(87, 20);
            this.itemNameLabel.TabIndex = 23;
            this.itemNameLabel.Text = "Item Name";
            // 
            // NewOrderButton
            // 
            this.NewOrderButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.NewOrderButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewOrderButton.Location = new System.Drawing.Point(998, 133);
            this.NewOrderButton.Name = "NewOrderButton";
            this.NewOrderButton.Size = new System.Drawing.Size(176, 40);
            this.NewOrderButton.TabIndex = 0;
            this.NewOrderButton.Text = "  New Order";
            this.NewOrderButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.NewOrderButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.NewOrderButton.UseVisualStyleBackColor = true;
            this.NewOrderButton.Click += new System.EventHandler(this.NewOrderButton_Click);
            // 
            // PrintPreviewButton
            // 
            this.PrintPreviewButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.PrintPreviewButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PrintPreviewButton.Location = new System.Drawing.Point(998, 187);
            this.PrintPreviewButton.Name = "PrintPreviewButton";
            this.PrintPreviewButton.Size = new System.Drawing.Size(176, 40);
            this.PrintPreviewButton.TabIndex = 6;
            this.PrintPreviewButton.Text = "  Print Preview";
            this.PrintPreviewButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.PrintPreviewButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.PrintPreviewButton.UseVisualStyleBackColor = true;
            this.PrintPreviewButton.Click += new System.EventHandler(this.PrintPreviewButton_Click);
            // 
            // PrintOrderButton
            // 
            this.PrintOrderButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.PrintOrderButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PrintOrderButton.Location = new System.Drawing.Point(998, 249);
            this.PrintOrderButton.Name = "PrintOrderButton";
            this.PrintOrderButton.Size = new System.Drawing.Size(176, 40);
            this.PrintOrderButton.TabIndex = 7;
            this.PrintOrderButton.Text = "  Print Order";
            this.PrintOrderButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.PrintOrderButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.PrintOrderButton.UseVisualStyleBackColor = true;
            this.PrintOrderButton.Click += new System.EventHandler(this.PrintOrderButton_Click);
            // 
            // ItemsGridView
            // 
            this.ItemsGridView.AllowUserToAddRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ItemsGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.ItemsGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ItemsGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ItemsGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.ItemsGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ItemsGridView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.ItemsGridView.Location = new System.Drawing.Point(25, 355);
            this.ItemsGridView.MultiSelect = false;
            this.ItemsGridView.Name = "ItemsGridView";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ItemsGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.ItemsGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ItemsGridView.Size = new System.Drawing.Size(1157, 171);
            this.ItemsGridView.TabIndex = 21;
            this.ItemsGridView.MouseDown += new System.Windows.Forms.MouseEventHandler(this.ItemsGridView_MouseDown);
            // 
            // DiscountTextBox
            // 
            this.DiscountTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.DiscountTextBox.Enabled = false;
            this.DiscountTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DiscountTextBox.Location = new System.Drawing.Point(436, 555);
            this.DiscountTextBox.Name = "DiscountTextBox";
            this.DiscountTextBox.ReadOnly = true;
            this.DiscountTextBox.Size = new System.Drawing.Size(100, 26);
            this.DiscountTextBox.TabIndex = 23;
            this.DiscountTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // DiscountLabel
            // 
            this.DiscountLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.DiscountLabel.AutoSize = true;
            this.DiscountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DiscountLabel.Location = new System.Drawing.Point(336, 558);
            this.DiscountLabel.Name = "DiscountLabel";
            this.DiscountLabel.Size = new System.Drawing.Size(72, 20);
            this.DiscountLabel.TabIndex = 28;
            this.DiscountLabel.Text = "Discount";
            // 
            // TotalToPayLabel
            // 
            this.TotalToPayLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.TotalToPayLabel.AutoSize = true;
            this.TotalToPayLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalToPayLabel.Location = new System.Drawing.Point(856, 597);
            this.TotalToPayLabel.Name = "TotalToPayLabel";
            this.TotalToPayLabel.Size = new System.Drawing.Size(96, 20);
            this.TotalToPayLabel.TabIndex = 29;
            this.TotalToPayLabel.Text = "Total To Pay";
            // 
            // TotalAmountTextBox
            // 
            this.TotalAmountTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.TotalAmountTextBox.Enabled = false;
            this.TotalAmountTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalAmountTextBox.Location = new System.Drawing.Point(978, 552);
            this.TotalAmountTextBox.Name = "TotalAmountTextBox";
            this.TotalAmountTextBox.ReadOnly = true;
            this.TotalAmountTextBox.Size = new System.Drawing.Size(162, 26);
            this.TotalAmountTextBox.TabIndex = 24;
            this.TotalAmountTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TotalToPayTextBox
            // 
            this.TotalToPayTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.TotalToPayTextBox.Enabled = false;
            this.TotalToPayTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalToPayTextBox.Location = new System.Drawing.Point(978, 591);
            this.TotalToPayTextBox.Name = "TotalToPayTextBox";
            this.TotalToPayTextBox.ReadOnly = true;
            this.TotalToPayTextBox.Size = new System.Drawing.Size(162, 26);
            this.TotalToPayTextBox.TabIndex = 25;
            this.TotalToPayTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TotalAmountLabel
            // 
            this.TotalAmountLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.TotalAmountLabel.AutoSize = true;
            this.TotalAmountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalAmountLabel.Location = new System.Drawing.Point(856, 555);
            this.TotalAmountLabel.Name = "TotalAmountLabel";
            this.TotalAmountLabel.Size = new System.Drawing.Size(104, 20);
            this.TotalAmountLabel.TabIndex = 30;
            this.TotalAmountLabel.Text = "Total Amount";
            // 
            // CgstLabel
            // 
            this.CgstLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.CgstLabel.AutoSize = true;
            this.CgstLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CgstLabel.Location = new System.Drawing.Point(588, 600);
            this.CgstLabel.Name = "CgstLabel";
            this.CgstLabel.Size = new System.Drawing.Size(53, 20);
            this.CgstLabel.TabIndex = 31;
            this.CgstLabel.Text = "CGST";
            // 
            // CgstTextBox
            // 
            this.CgstTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.CgstTextBox.Enabled = false;
            this.CgstTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CgstTextBox.Location = new System.Drawing.Point(667, 597);
            this.CgstTextBox.Name = "CgstTextBox";
            this.CgstTextBox.ReadOnly = true;
            this.CgstTextBox.Size = new System.Drawing.Size(100, 26);
            this.CgstTextBox.TabIndex = 26;
            this.CgstTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // SgstLabel
            // 
            this.SgstLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.SgstLabel.AutoSize = true;
            this.SgstLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SgstLabel.Location = new System.Drawing.Point(588, 558);
            this.SgstLabel.Name = "SgstLabel";
            this.SgstLabel.Size = new System.Drawing.Size(53, 20);
            this.SgstLabel.TabIndex = 32;
            this.SgstLabel.Text = "SGST";
            // 
            // SgstTextBox
            // 
            this.SgstTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.SgstTextBox.Enabled = false;
            this.SgstTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SgstTextBox.Location = new System.Drawing.Point(667, 555);
            this.SgstTextBox.Name = "SgstTextBox";
            this.SgstTextBox.ReadOnly = true;
            this.SgstTextBox.Size = new System.Drawing.Size(100, 26);
            this.SgstTextBox.TabIndex = 27;
            this.SgstTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // CancelOrderButton
            // 
            this.CancelOrderButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.CancelOrderButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CancelOrderButton.Location = new System.Drawing.Point(25, 542);
            this.CancelOrderButton.Name = "CancelOrderButton";
            this.CancelOrderButton.Size = new System.Drawing.Size(189, 48);
            this.CancelOrderButton.TabIndex = 8;
            this.CancelOrderButton.Text = " Cancel Order";
            this.CancelOrderButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.CancelOrderButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.CancelOrderButton.UseVisualStyleBackColor = true;
            this.CancelOrderButton.Click += new System.EventHandler(this.CancelOrderButton_Click);
            // 
            // ContextMenuStrip
            // 
            this.ContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteToolStripMenuItem});
            this.ContextMenuStrip.Name = "ContextMenuStrip";
            this.ContextMenuStrip.Size = new System.Drawing.Size(108, 26);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.deleteToolStripMenuItem.Text = "&Delete";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // PrintDocument
            // 
            this.PrintDocument.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.PrintDocument_PrintPage);
            // 
            // PrintPreviewDialog
            // 
            this.PrintPreviewDialog.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.PrintPreviewDialog.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.PrintPreviewDialog.ClientSize = new System.Drawing.Size(400, 300);
            this.PrintPreviewDialog.Enabled = true;
            this.PrintPreviewDialog.Icon = ((System.Drawing.Icon)(resources.GetObject("PrintPreviewDialog.Icon")));
            this.PrintPreviewDialog.Name = "PrintPreviewDialog";
            this.PrintPreviewDialog.Visible = false;
            // 
            // OrderForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1211, 648);
            this.Controls.Add(this.DiscountTextBox);
            this.Controls.Add(this.DiscountLabel);
            this.Controls.Add(this.TotalToPayLabel);
            this.Controls.Add(this.TotalAmountTextBox);
            this.Controls.Add(this.TotalToPayTextBox);
            this.Controls.Add(this.TotalAmountLabel);
            this.Controls.Add(this.CgstLabel);
            this.Controls.Add(this.CgstTextBox);
            this.Controls.Add(this.SgstLabel);
            this.Controls.Add(this.SgstTextBox);
            this.Controls.Add(this.CancelOrderButton);
            this.Controls.Add(this.ItemsGridView);
            this.Controls.Add(this.PrintOrderButton);
            this.Controls.Add(this.PrintPreviewButton);
            this.Controls.Add(this.NewOrderButton);
            this.Controls.Add(this.GroupBox);
            this.Controls.Add(this.LogoLabel);
            this.Controls.Add(this.ClientSideMenu);
            this.Controls.Add(this.shapeContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "OrderForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Order Form";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OrderForm_FormClosing);
            this.Load += new System.EventHandler(this.OrderForm_Load);
            this.ClientSideMenu.ResumeLayout(false);
            this.ClientSideMenu.PerformLayout();
            this.GroupBox.ResumeLayout(false);
            this.GroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ItemsGridView)).EndInit();
            this.ContextMenuStrip.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip ClientSideMenu;
        private System.Windows.Forms.ToolStripMenuItem searchItemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape LogoRectangle;
        private System.Windows.Forms.Label LogoLabel;
        private System.Windows.Forms.GroupBox GroupBox;
        private System.Windows.Forms.Button AddToCartButton;
        private System.Windows.Forms.Label OrderNumberLabel;
        private System.Windows.Forms.TextBox CurrentStockTextBox;
        private System.Windows.Forms.Label TransactionLabel;
        private System.Windows.Forms.Label CurrentStockLabel;
        private System.Windows.Forms.TextBox OrderNumberTextBox;
        private System.Windows.Forms.TextBox PriceTextBox;
        private System.Windows.Forms.Label UnitPriceLabel;
        private System.Windows.Forms.Label CloustomerNameLabel;
        private System.Windows.Forms.TextBox QuantityTextBox;
        private System.Windows.Forms.TextBox CoustomerNameTextBox;
        private System.Windows.Forms.Label QuantityLabel;
        private System.Windows.Forms.Label PaymentType;
        private System.Windows.Forms.ComboBox ItemsComboBox;
        private System.Windows.Forms.ComboBox PaymentComboBox;
        private System.Windows.Forms.Label itemNameLabel;
        private System.Windows.Forms.Button NewOrderButton;
        private System.Windows.Forms.Button PrintPreviewButton;
        private System.Windows.Forms.Button PrintOrderButton;
        private System.Windows.Forms.DataGridView ItemsGridView;
        private System.Windows.Forms.TextBox DiscountTextBox;
        private System.Windows.Forms.Label DiscountLabel;
        private System.Windows.Forms.Label TotalToPayLabel;
        private System.Windows.Forms.TextBox TotalAmountTextBox;
        private System.Windows.Forms.TextBox TotalToPayTextBox;
        private System.Windows.Forms.Label TotalAmountLabel;
        private System.Windows.Forms.Label CgstLabel;
        private System.Windows.Forms.TextBox CgstTextBox;
        private System.Windows.Forms.Label SgstLabel;
        private System.Windows.Forms.TextBox SgstTextBox;
        private System.Windows.Forms.Button CancelOrderButton;
        private System.Windows.Forms.ContextMenuStrip ContextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        private System.Drawing.Printing.PrintDocument PrintDocument;
        private System.Windows.Forms.PrintPreviewDialog PrintPreviewDialog;
        private System.Windows.Forms.DateTimePicker TransactionDate;
        private System.Windows.Forms.ToolStripMenuItem unpaidOrderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Label CompanyLabel;
        private System.Windows.Forms.ComboBox CompanyComboBox;
    }
}

