﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace StockManagementAndBilling
{
    public partial class CreateCompany : Form
    {
        OleDbConnection con;
        OleDbCommand cmd;
        public CreateCompany()
        {
            InitializeComponent();
        }

        private void CreateCompany_Load(object sender, EventArgs e)
        {
            //Database Connection
            con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Application.StartupPath + "\\Database/StockManagement.accdb;Persist Security Info=False");
            con.Open();

            // Check Connection, if not then exit in Application
            if (con.State != ConnectionState.Open)
            {
                DialogResult res = MessageBox.Show("Connection fail", "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (res == DialogResult.OK)
                {
                    Application.Exit();
                }
            }
        }

        private void FirstNameTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // enter first name and last name (only characters)
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122 || e.KeyChar == 8 || e.KeyChar == 13)
            {
                if (e.KeyChar == 13)
                {
                    if (sender == FirstNameTextBox && FirstNameTextBox.Text != "")
                    {
                        LastNameTextBox.Focus();
                    }
                    if (sender == LastNameTextBox && LastNameTextBox.Text != "")
                    {
                        CompanyNameTextBox.Focus();
                    }
                }
                else
                {
                    e.Handled = false;
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void CompanyNameTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // enter company name (character and number and space)
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122 || e.KeyChar == 8 || e.KeyChar == 32 || e.KeyChar == 13 || e.KeyChar >= 48 && e.KeyChar <= 57)
            {
                if (e.KeyChar == 13 && CompanyNameTextBox.Text.Trim() != "")
                {
                    MobileNumberTextbox.Focus();
                }
                else
                {
                    e.Handled = false;
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void MobileNumberTextbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // enter only mobile number
            if (e.KeyChar >= 48 && e.KeyChar <= 57 || e.KeyChar == 8 || e.KeyChar == 13)
            {
                if (e.KeyChar == 13 && MobileNumberTextbox.Text.Trim().Length == 10)
                {
                    EmailIdTextBox.Focus();
                }
                else
                {
                    e.Handled = false;
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void EmailIdTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // enter email (character and number and @)
            if (e.KeyChar >= 97 && e.KeyChar <= 122 || e.KeyChar == 8 || e.KeyChar == 13 || e.KeyChar >= 48 && e.KeyChar <= 57 || e.KeyChar == 46 || e.KeyChar == 64)
            {
                if (e.KeyChar == 13 && EmailIdTextBox.Text.Trim() != "")
                {
                    AddressTextBox.Focus();
                }
                else
                {
                    e.Handled = false;
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void AddressTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // enter address
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122 || e.KeyChar >= 48 && e.KeyChar <= 57 || e.KeyChar == 13 || e.KeyChar == 8 || e.KeyChar == 32 || e.KeyChar == 46 || e.KeyChar == 13 || e.KeyChar == 44)
            {
                if (e.KeyChar == 13 && AddressTextBox.Text.Trim() != "")
                {
                    SaveDataButton.Focus();
                }
                else
                {
                    e.Handled = false;
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void SaveDataButton_Click(object sender, EventArgs e)
        {
            // if validation true then save data
            if(Valition()){
                SaveCompany();
            }
        }

        private bool Valition()
        {
            // textbox validation
            if(CompanyNameTextBox.Text.Trim() == ""){
                MessageBox.Show("Please Enter Company Name","Enter Company Name",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                CompanyNameTextBox.Focus();
                return false;
            }

            if(MobileNumberTextbox.Text.Trim() == "" || MobileNumberTextbox.Text.Length != 10){
                MessageBox.Show("Please Enter Mobile Number", "Enter Mobile Number", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                MobileNumberTextbox.Focus();
                return false;
            }

            if(EmailIdTextBox.Text.Trim() == ""){
                MessageBox.Show("Please Enter Email Id", "Enter Email ID", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                EmailIdTextBox.Focus();
                return false;
            }

            if(AddressTextBox.Text.Trim() == ""){
                MessageBox.Show("Please Enter Company Address","Enter Company Address",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                AddressTextBox.Focus();
                return false;
            }
            return true;
        }

        private void SaveCompany()
        {
            // save data
            String Fname = FirstNameTextBox.Text.Trim();
            String Lname = LastNameTextBox.Text.Trim();
            String Names = Fname + " " + Lname;
            String Name = CompanyNameTextBox.Text.Trim();
            String Email = EmailIdTextBox.Text.Trim();
            String Mobile = MobileNumberTextbox.Text.Trim();
            String Address = AddressTextBox.Text.Trim();
            try
            {
                cmd = new OleDbCommand("insert into CompanyInfo(CompanyName,MobileNumber,Email,CompanyAddress,GSTNumber,CGST,SGST,Discount) values('"+Name+"','"+Mobile+"','"+Email+"','"+Address+"','None','0','0','0')",con);
                cmd.ExecuteNonQuery();
                cmd = new OleDbCommand("insert into Colors(CompanyName,NameBackColor,NameColor,FormBackColor) values('" + Name + "','Black','White','LightSteelBlue')",con);
                cmd.ExecuteNonQuery();
                 
                MessageBox.Show("Company Create Success","Company Create",MessageBoxButtons.OK,MessageBoxIcon.Information);
                CompanyNameTextBox.Text = "";
                MobileNumberTextbox.Text = "";
                EmailIdTextBox.Text = "";
                AddressTextBox.Text = "";
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }
            CreateUser CU = new CreateUser(Names,Mobile,Address);
            this.Hide();
            CU.Show();
        }

        private void CreateCompany_FormClosing(object sender, FormClosingEventArgs e)
        {
            con.Close();
            Application.Exit();
        }

    }
}
