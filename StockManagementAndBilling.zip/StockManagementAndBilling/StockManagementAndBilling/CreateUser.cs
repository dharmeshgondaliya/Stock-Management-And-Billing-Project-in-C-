﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace StockManagementAndBilling
{
    public partial class CreateUser : Form
    {
        String Names,Mobile,Address;
        OleDbConnection con;
        OleDbCommand cmd;
        public CreateUser(String Names,String Mobile,String Address)
        {
            this.Names = Names;
            this.Mobile = Mobile;
            this.Address = Address;
            InitializeComponent();
        }

        private void CreateUser_Load(object sender, EventArgs e)
        {
            //Database Connection
            con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Application.StartupPath + "\\Database/StockManagement.accdb;Persist Security Info=False");
            con.Open();

            // Check Connection, if not then exit in Application
            if (con.State != ConnectionState.Open)
            {
                DialogResult res = MessageBox.Show("Connection fail", "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (res == DialogResult.OK)
                {
                    Application.Exit();
                }
            }
        }

        private void UserIdTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // enter user id
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122 || e.KeyChar == 13 || e.KeyChar >= 48 && e.KeyChar <= 57 || e.KeyChar == 8 || e.KeyChar == 32 || e.KeyChar == 46)
            {
                if (e.KeyChar == 13)
                {
                    PasswordTextBox.Focus();
                }
                else
                {
                    e.Handled = false;
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void PasswordTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // enter password
            if (e.KeyChar == 13 && PasswordTextBox.Text != "")
            {
                SaveUserButton.Focus();   
            }
        }

        private bool Validation()
        {
            // textbox validation
            if(UserIdTextBox.Text.Trim() == ""){
                MessageBox.Show("Please Enter User ID","Enter User ID",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                UserIdTextBox.Focus();
                return false;
            }
            
            if(PasswordTextBox.Text.Trim() == ""){
                MessageBox.Show("Please Enter Paaword","Enter Password",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }

        private void SaveUserButton_Click(object sender, EventArgs e)
        {
            if(Validation()){
                SaveData();
            }
        }

        private void SaveData()
        {
            // save data from user
            String UserId = UserIdTextBox.Text.Trim();
            String Password = PasswordTextBox.Text.Trim();
            try {
                cmd = new OleDbCommand("insert into Login(Name,UserId,Pass,Mobile,Addr,Utype) values('"+Names+"','"+UserId+"','"+Password+"','"+Mobile+"','"+Address+"','Admin')",con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("User Create Success","User Create",MessageBoxButtons.OK,MessageBoxIcon.Information);
                UserIdTextBox.Text = "";
                PasswordTextBox.Text = "";
            }
            catch(Exception exp){
                MessageBox.Show(exp.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }
            LoginForm LF = new LoginForm();
            LF.Show();
            this.Hide();
        }

        private void CreateUser_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
