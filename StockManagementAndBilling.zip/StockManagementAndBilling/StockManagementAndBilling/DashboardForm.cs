﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StockManagementAndBilling
{
    public partial class DashboardForm : Form
    {
        public DashboardForm()
        {
            InitializeComponent();
        }

        private void DashboardForm_Load(object sender, EventArgs e)
        {
            CompanySetting();
            // set button icon
            StockManageButton.Image = Image.FromFile(Application.StartupPath+"/icons/Stock_Manage.png");
            LogoutButton.Image = Image.FromFile(Application.StartupPath + "/icons/Logout.png");
            ExitButton.Image = Image.FromFile(Application.StartupPath + "/icons/Exit.png");
            SettingsButton.Image = Image.FromFile(Application.StartupPath + "/icons/Settings.png");
            UserMangeButton.Image = Image.FromFile(Application.StartupPath + "/icons/User_Manage.png");
            CompareShellButton.Image = Image.FromFile(Application.StartupPath + "/icons/Compare_Shell.png");
            ShellStockButton.Image = Image.FromFile(Application.StartupPath + "/icons/Shell_Stock.png");
            AvailableStockButton.Image = Image.FromFile(Application.StartupPath + "/icons/Available_Stock.png");
            this.WindowState = FormWindowState.Maximized;
        }

        public void CompanySetting() {
            //set Company name, button icons, form color
            //Color color;
               
            CompanyClass Company = new CompanyClass();
            DashboardLabel.Text = Company.CompanyName.ToString();

            //color = System.Drawing.ColorTranslator.FromHtml(Company.NameColor.ToString()); ;
            DashboardLabel.ForeColor = System.Drawing.ColorTranslator.FromHtml(Company.NameColor.ToString());
            DashboardLabel.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.NameBackColor.ToString());
            DashboardRectangle.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.NameBackColor.ToString());
            this.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.FormBackColor.ToString());
        }

        private void StockManageButton_Click(object sender, EventArgs e)
        {
            // show stock manage form
            StockManageForm SMF = new StockManageForm();
            SMF.ShowDialog();
        }

        private void AvailableStockButton_Click(object sender, EventArgs e)
        {
            // show available stock form
            AvailableStockForm ASF = new AvailableStockForm();
            ASF.ShowDialog();
        }

        private void ShellStockButton_Click(object sender, EventArgs e)
        {
            // show sell stock form
            ShellStockForm SSF = new ShellStockForm();
            SSF.ShowDialog();
        }

        private void CompareShellButton_Click(object sender, EventArgs e)
        {
            // show compare stock form
            CompareStock CS = new CompareStock();
            CS.ShowDialog();
        }

        private void UserMangeButton_Click(object sender, EventArgs e)
        {
            // show user manage form
            UserManageForm UMF = new UserManageForm();
            UMF.ShowDialog();
        }

        private void SettingsButton_Click(object sender, EventArgs e)
        {
            // show company setting form
            CompanySettings CSS = new CompanySettings();
            CSS.ShowDialog();
        }

        private void LogoutButton_Click(object sender, EventArgs e)
        {
            // logout of application
            LoginForm LF = new LoginForm();
            LF.Show();
            this.Hide();
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void DashboardForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void DashboardLabel_ClientSizeChanged(object sender, EventArgs e)
        {
            DashboardLabel.Left = (this.ClientSize.Width - DashboardLabel.Size.Width) / 2;
        }

    }
}
