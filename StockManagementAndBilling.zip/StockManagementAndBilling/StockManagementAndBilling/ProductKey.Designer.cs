﻿namespace StockManagementAndBilling
{
    partial class ProductKey
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.FirstTextBox = new System.Windows.Forms.TextBox();
            this.SecondTextBox = new System.Windows.Forms.TextBox();
            this.ThirdTextBox = new System.Windows.Forms.TextBox();
            this.FourthTextBox = new System.Windows.Forms.TextBox();
            this.GenerateButton = new System.Windows.Forms.Button();
            this.SubmitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(130, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(170, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter Product Key";
            // 
            // FirstTextBox
            // 
            this.FirstTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FirstTextBox.Location = new System.Drawing.Point(47, 72);
            this.FirstTextBox.MaxLength = 4;
            this.FirstTextBox.Name = "FirstTextBox";
            this.FirstTextBox.Size = new System.Drawing.Size(72, 30);
            this.FirstTextBox.TabIndex = 1;
            this.FirstTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.FirstTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyDownEvent);
            this.FirstTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPressEvent);
            // 
            // SecondTextBox
            // 
            this.SecondTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SecondTextBox.Location = new System.Drawing.Point(134, 72);
            this.SecondTextBox.MaxLength = 4;
            this.SecondTextBox.Name = "SecondTextBox";
            this.SecondTextBox.Size = new System.Drawing.Size(72, 30);
            this.SecondTextBox.TabIndex = 2;
            this.SecondTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.SecondTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyDownEvent);
            this.SecondTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPressEvent);
            // 
            // ThirdTextBox
            // 
            this.ThirdTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ThirdTextBox.Location = new System.Drawing.Point(224, 72);
            this.ThirdTextBox.MaxLength = 4;
            this.ThirdTextBox.Name = "ThirdTextBox";
            this.ThirdTextBox.Size = new System.Drawing.Size(72, 30);
            this.ThirdTextBox.TabIndex = 3;
            this.ThirdTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.ThirdTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyDownEvent);
            this.ThirdTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPressEvent);
            // 
            // FourthTextBox
            // 
            this.FourthTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FourthTextBox.Location = new System.Drawing.Point(311, 72);
            this.FourthTextBox.MaxLength = 4;
            this.FourthTextBox.Name = "FourthTextBox";
            this.FourthTextBox.Size = new System.Drawing.Size(72, 30);
            this.FourthTextBox.TabIndex = 4;
            this.FourthTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.FourthTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyDownEvent);
            this.FourthTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPressEvent);
            // 
            // GenerateButton
            // 
            this.GenerateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenerateButton.Location = new System.Drawing.Point(47, 118);
            this.GenerateButton.Name = "GenerateButton";
            this.GenerateButton.Size = new System.Drawing.Size(159, 45);
            this.GenerateButton.TabIndex = 0;
            this.GenerateButton.Text = "ClickTo Generate";
            this.GenerateButton.UseVisualStyleBackColor = true;
            this.GenerateButton.Click += new System.EventHandler(this.GenerateButton_Click);
            // 
            // SubmitButton
            // 
            this.SubmitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SubmitButton.Location = new System.Drawing.Point(224, 118);
            this.SubmitButton.Name = "SubmitButton";
            this.SubmitButton.Size = new System.Drawing.Size(159, 45);
            this.SubmitButton.TabIndex = 5;
            this.SubmitButton.Text = "Submit";
            this.SubmitButton.UseVisualStyleBackColor = true;
            this.SubmitButton.Click += new System.EventHandler(this.SubmitButton_Click);
            // 
            // ProductKey
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(430, 175);
            this.Controls.Add(this.SubmitButton);
            this.Controls.Add(this.GenerateButton);
            this.Controls.Add(this.FourthTextBox);
            this.Controls.Add(this.ThirdTextBox);
            this.Controls.Add(this.SecondTextBox);
            this.Controls.Add(this.FirstTextBox);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ProductKey";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Product Key";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ProductKey_FormClosing);
            this.Load += new System.EventHandler(this.ProductKey_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox FirstTextBox;
        private System.Windows.Forms.TextBox SecondTextBox;
        private System.Windows.Forms.TextBox ThirdTextBox;
        private System.Windows.Forms.TextBox FourthTextBox;
        private System.Windows.Forms.Button GenerateButton;
        private System.Windows.Forms.Button SubmitButton;
    }
}