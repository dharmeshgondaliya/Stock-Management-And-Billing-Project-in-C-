﻿namespace StockManagementAndBilling
{
    partial class UserManageForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.UserManagementLabel = new System.Windows.Forms.Label();
            this.UserManageRectangle = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.InsertButton = new System.Windows.Forms.Button();
            this.SelectUserComboBox = new System.Windows.Forms.ComboBox();
            this.SelectUserLabel = new System.Windows.Forms.Label();
            this.AddressTextBox = new System.Windows.Forms.TextBox();
            this.AddressLabel = new System.Windows.Forms.Label();
            this.UpdateUserButton = new System.Windows.Forms.Button();
            this.MobileNumberTextBox = new System.Windows.Forms.TextBox();
            this.UserComboBox = new System.Windows.Forms.ComboBox();
            this.ManageUserGroupBox = new System.Windows.Forms.GroupBox();
            this.CancelButton = new System.Windows.Forms.Button();
            this.MobileNumberLabel = new System.Windows.Forms.Label();
            this.PasswordTextBox = new System.Windows.Forms.TextBox();
            this.PaaswordLabel = new System.Windows.Forms.Label();
            this.UserIdTextBox = new System.Windows.Forms.TextBox();
            this.UserIdLabel = new System.Windows.Forms.Label();
            this.LastNameTextBox = new System.Windows.Forms.TextBox();
            this.LastNameLabel = new System.Windows.Forms.Label();
            this.FirstNameTextBox = new System.Windows.Forms.TextBox();
            this.FirstNameLabel = new System.Windows.Forms.Label();
            this.ManageUsersGroupBox = new System.Windows.Forms.GroupBox();
            this.OkButton = new System.Windows.Forms.Button();
            this.UserNameLabel = new System.Windows.Forms.Label();
            this.DeleteUserButton = new System.Windows.Forms.Button();
            this.AddNewUserButton = new System.Windows.Forms.Button();
            this.StockManageMenu = new System.Windows.Forms.MenuStrip();
            this.stockManageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ManageUserGroupBox.SuspendLayout();
            this.ManageUsersGroupBox.SuspendLayout();
            this.StockManageMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // UserManagementLabel
            // 
            this.UserManagementLabel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.UserManagementLabel.AutoSize = true;
            this.UserManagementLabel.BackColor = System.Drawing.Color.Black;
            this.UserManagementLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserManagementLabel.ForeColor = System.Drawing.Color.White;
            this.UserManagementLabel.Location = new System.Drawing.Point(333, 45);
            this.UserManagementLabel.Name = "UserManagementLabel";
            this.UserManagementLabel.Size = new System.Drawing.Size(493, 46);
            this.UserManagementLabel.TabIndex = 5;
            this.UserManagementLabel.Text = "Stock Management & Billing";
            this.UserManagementLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.UserManagementLabel.ClientSizeChanged += new System.EventHandler(this.UserManagementLabel_ClientSizeChanged);
            // 
            // UserManageRectangle
            // 
            this.UserManageRectangle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.UserManageRectangle.BackColor = System.Drawing.Color.Black;
            this.UserManageRectangle.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.UserManageRectangle.Location = new System.Drawing.Point(-7, 31);
            this.UserManageRectangle.Name = "UserManageRectangle";
            this.UserManageRectangle.Size = new System.Drawing.Size(1175, 72);
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.UserManageRectangle});
            this.shapeContainer1.Size = new System.Drawing.Size(1159, 660);
            this.shapeContainer1.TabIndex = 6;
            this.shapeContainer1.TabStop = false;
            // 
            // InsertButton
            // 
            this.InsertButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.InsertButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InsertButton.Location = new System.Drawing.Point(106, 399);
            this.InsertButton.Name = "InsertButton";
            this.InsertButton.Size = new System.Drawing.Size(151, 37);
            this.InsertButton.TabIndex = 9;
            this.InsertButton.Text = "  Add User";
            this.InsertButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.InsertButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.InsertButton.UseVisualStyleBackColor = true;
            this.InsertButton.Click += new System.EventHandler(this.InsertButton_Click);
            // 
            // SelectUserComboBox
            // 
            this.SelectUserComboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SelectUserComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SelectUserComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectUserComboBox.FormattingEnabled = true;
            this.SelectUserComboBox.Items.AddRange(new object[] {
            "Admin",
            "User"});
            this.SelectUserComboBox.Location = new System.Drawing.Point(231, 344);
            this.SelectUserComboBox.Name = "SelectUserComboBox";
            this.SelectUserComboBox.Size = new System.Drawing.Size(257, 28);
            this.SelectUserComboBox.TabIndex = 8;
            // 
            // SelectUserLabel
            // 
            this.SelectUserLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SelectUserLabel.AutoSize = true;
            this.SelectUserLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectUserLabel.Location = new System.Drawing.Point(102, 347);
            this.SelectUserLabel.Name = "SelectUserLabel";
            this.SelectUserLabel.Size = new System.Drawing.Size(92, 20);
            this.SelectUserLabel.TabIndex = 0;
            this.SelectUserLabel.Text = "Select User";
            // 
            // AddressTextBox
            // 
            this.AddressTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AddressTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddressTextBox.Location = new System.Drawing.Point(231, 259);
            this.AddressTextBox.Multiline = true;
            this.AddressTextBox.Name = "AddressTextBox";
            this.AddressTextBox.Size = new System.Drawing.Size(257, 66);
            this.AddressTextBox.TabIndex = 7;
            this.AddressTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.AddressTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.AddressTextBox_KeyPress);
            // 
            // AddressLabel
            // 
            this.AddressLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AddressLabel.AutoSize = true;
            this.AddressLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddressLabel.Location = new System.Drawing.Point(102, 264);
            this.AddressLabel.Name = "AddressLabel";
            this.AddressLabel.Size = new System.Drawing.Size(68, 20);
            this.AddressLabel.TabIndex = 0;
            this.AddressLabel.Text = "Address";
            // 
            // UpdateUserButton
            // 
            this.UpdateUserButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.UpdateUserButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateUserButton.Location = new System.Drawing.Point(65, 87);
            this.UpdateUserButton.Name = "UpdateUserButton";
            this.UpdateUserButton.Size = new System.Drawing.Size(194, 42);
            this.UpdateUserButton.TabIndex = 0;
            this.UpdateUserButton.Text = "  Update User Info";
            this.UpdateUserButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.UpdateUserButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.UpdateUserButton.UseVisualStyleBackColor = true;
            this.UpdateUserButton.Click += new System.EventHandler(this.UpdateUserButton_Click);
            // 
            // MobileNumberTextBox
            // 
            this.MobileNumberTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.MobileNumberTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MobileNumberTextBox.Location = new System.Drawing.Point(231, 212);
            this.MobileNumberTextBox.MaxLength = 10;
            this.MobileNumberTextBox.Name = "MobileNumberTextBox";
            this.MobileNumberTextBox.Size = new System.Drawing.Size(257, 26);
            this.MobileNumberTextBox.TabIndex = 6;
            this.MobileNumberTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.MobileNumberTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MobileNumberTextBox_KeyPress);
            // 
            // UserComboBox
            // 
            this.UserComboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.UserComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.UserComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserComboBox.FormattingEnabled = true;
            this.UserComboBox.Location = new System.Drawing.Point(65, 313);
            this.UserComboBox.Name = "UserComboBox";
            this.UserComboBox.Size = new System.Drawing.Size(194, 28);
            this.UserComboBox.Sorted = true;
            this.UserComboBox.TabIndex = 2;
            // 
            // ManageUserGroupBox
            // 
            this.ManageUserGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ManageUserGroupBox.Controls.Add(this.CancelButton);
            this.ManageUserGroupBox.Controls.Add(this.InsertButton);
            this.ManageUserGroupBox.Controls.Add(this.SelectUserComboBox);
            this.ManageUserGroupBox.Controls.Add(this.SelectUserLabel);
            this.ManageUserGroupBox.Controls.Add(this.AddressTextBox);
            this.ManageUserGroupBox.Controls.Add(this.AddressLabel);
            this.ManageUserGroupBox.Controls.Add(this.MobileNumberTextBox);
            this.ManageUserGroupBox.Controls.Add(this.MobileNumberLabel);
            this.ManageUserGroupBox.Controls.Add(this.PasswordTextBox);
            this.ManageUserGroupBox.Controls.Add(this.PaaswordLabel);
            this.ManageUserGroupBox.Controls.Add(this.UserIdTextBox);
            this.ManageUserGroupBox.Controls.Add(this.UserIdLabel);
            this.ManageUserGroupBox.Controls.Add(this.LastNameTextBox);
            this.ManageUserGroupBox.Controls.Add(this.LastNameLabel);
            this.ManageUserGroupBox.Controls.Add(this.FirstNameTextBox);
            this.ManageUserGroupBox.Controls.Add(this.FirstNameLabel);
            this.ManageUserGroupBox.Location = new System.Drawing.Point(500, 148);
            this.ManageUserGroupBox.Name = "ManageUserGroupBox";
            this.ManageUserGroupBox.Size = new System.Drawing.Size(603, 467);
            this.ManageUserGroupBox.TabIndex = 9;
            this.ManageUserGroupBox.TabStop = false;
            // 
            // CancelButton
            // 
            this.CancelButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.CancelButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CancelButton.Location = new System.Drawing.Point(337, 399);
            this.CancelButton.Name = "CancelButton";
            this.CancelButton.Size = new System.Drawing.Size(151, 37);
            this.CancelButton.TabIndex = 10;
            this.CancelButton.Text = " Cancle";
            this.CancelButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.CancelButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.CancelButton.UseVisualStyleBackColor = true;
            this.CancelButton.Click += new System.EventHandler(this.CancelButton_Click);
            // 
            // MobileNumberLabel
            // 
            this.MobileNumberLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.MobileNumberLabel.AutoSize = true;
            this.MobileNumberLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MobileNumberLabel.Location = new System.Drawing.Point(102, 215);
            this.MobileNumberLabel.Name = "MobileNumberLabel";
            this.MobileNumberLabel.Size = new System.Drawing.Size(115, 20);
            this.MobileNumberLabel.TabIndex = 0;
            this.MobileNumberLabel.Text = "Mobile Number";
            // 
            // PasswordTextBox
            // 
            this.PasswordTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.PasswordTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PasswordTextBox.Location = new System.Drawing.Point(231, 166);
            this.PasswordTextBox.Name = "PasswordTextBox";
            this.PasswordTextBox.Size = new System.Drawing.Size(257, 26);
            this.PasswordTextBox.TabIndex = 5;
            this.PasswordTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.PasswordTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.PasswordTextBox_KeyPress);
            // 
            // PaaswordLabel
            // 
            this.PaaswordLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.PaaswordLabel.AutoSize = true;
            this.PaaswordLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PaaswordLabel.Location = new System.Drawing.Point(102, 169);
            this.PaaswordLabel.Name = "PaaswordLabel";
            this.PaaswordLabel.Size = new System.Drawing.Size(78, 20);
            this.PaaswordLabel.TabIndex = 0;
            this.PaaswordLabel.Text = "Password";
            // 
            // UserIdTextBox
            // 
            this.UserIdTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.UserIdTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserIdTextBox.Location = new System.Drawing.Point(231, 120);
            this.UserIdTextBox.Name = "UserIdTextBox";
            this.UserIdTextBox.Size = new System.Drawing.Size(257, 26);
            this.UserIdTextBox.TabIndex = 4;
            this.UserIdTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.UserIdTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.UserIdTextBox_KeyPress);
            // 
            // UserIdLabel
            // 
            this.UserIdLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.UserIdLabel.AutoSize = true;
            this.UserIdLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserIdLabel.Location = new System.Drawing.Point(102, 123);
            this.UserIdLabel.Name = "UserIdLabel";
            this.UserIdLabel.Size = new System.Drawing.Size(64, 20);
            this.UserIdLabel.TabIndex = 0;
            this.UserIdLabel.Text = "User ID";
            // 
            // LastNameTextBox
            // 
            this.LastNameTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.LastNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LastNameTextBox.Location = new System.Drawing.Point(231, 74);
            this.LastNameTextBox.Name = "LastNameTextBox";
            this.LastNameTextBox.Size = new System.Drawing.Size(257, 26);
            this.LastNameTextBox.TabIndex = 3;
            this.LastNameTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.LastNameTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NameValidation);
            // 
            // LastNameLabel
            // 
            this.LastNameLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.LastNameLabel.AutoSize = true;
            this.LastNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LastNameLabel.Location = new System.Drawing.Point(102, 77);
            this.LastNameLabel.Name = "LastNameLabel";
            this.LastNameLabel.Size = new System.Drawing.Size(86, 20);
            this.LastNameLabel.TabIndex = 0;
            this.LastNameLabel.Text = "Last Name";
            // 
            // FirstNameTextBox
            // 
            this.FirstNameTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.FirstNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FirstNameTextBox.Location = new System.Drawing.Point(231, 27);
            this.FirstNameTextBox.Name = "FirstNameTextBox";
            this.FirstNameTextBox.Size = new System.Drawing.Size(257, 26);
            this.FirstNameTextBox.TabIndex = 2;
            this.FirstNameTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.FirstNameTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NameValidation);
            // 
            // FirstNameLabel
            // 
            this.FirstNameLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.FirstNameLabel.AutoSize = true;
            this.FirstNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FirstNameLabel.Location = new System.Drawing.Point(102, 30);
            this.FirstNameLabel.Name = "FirstNameLabel";
            this.FirstNameLabel.Size = new System.Drawing.Size(86, 20);
            this.FirstNameLabel.TabIndex = 0;
            this.FirstNameLabel.Text = "First Name";
            // 
            // ManageUsersGroupBox
            // 
            this.ManageUsersGroupBox.Controls.Add(this.OkButton);
            this.ManageUsersGroupBox.Controls.Add(this.UserComboBox);
            this.ManageUsersGroupBox.Controls.Add(this.UserNameLabel);
            this.ManageUsersGroupBox.Controls.Add(this.DeleteUserButton);
            this.ManageUsersGroupBox.Controls.Add(this.UpdateUserButton);
            this.ManageUsersGroupBox.Controls.Add(this.AddNewUserButton);
            this.ManageUsersGroupBox.Location = new System.Drawing.Point(56, 148);
            this.ManageUsersGroupBox.Name = "ManageUsersGroupBox";
            this.ManageUsersGroupBox.Size = new System.Drawing.Size(344, 467);
            this.ManageUsersGroupBox.TabIndex = 8;
            this.ManageUsersGroupBox.TabStop = false;
            // 
            // OkButton
            // 
            this.OkButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.OkButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OkButton.Location = new System.Drawing.Point(65, 361);
            this.OkButton.Name = "OkButton";
            this.OkButton.Size = new System.Drawing.Size(118, 37);
            this.OkButton.TabIndex = 1;
            this.OkButton.Text = " OK";
            this.OkButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.OkButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.OkButton.UseVisualStyleBackColor = true;
            this.OkButton.Click += new System.EventHandler(this.OkButton_Click);
            // 
            // UserNameLabel
            // 
            this.UserNameLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.UserNameLabel.AutoSize = true;
            this.UserNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserNameLabel.Location = new System.Drawing.Point(61, 279);
            this.UserNameLabel.Name = "UserNameLabel";
            this.UserNameLabel.Size = new System.Drawing.Size(89, 20);
            this.UserNameLabel.TabIndex = 1;
            this.UserNameLabel.Text = "User Name";
            // 
            // DeleteUserButton
            // 
            this.DeleteUserButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.DeleteUserButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeleteUserButton.Location = new System.Drawing.Point(65, 146);
            this.DeleteUserButton.Name = "DeleteUserButton";
            this.DeleteUserButton.Size = new System.Drawing.Size(194, 42);
            this.DeleteUserButton.TabIndex = 0;
            this.DeleteUserButton.Text = "  Delete User";
            this.DeleteUserButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.DeleteUserButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.DeleteUserButton.UseVisualStyleBackColor = true;
            this.DeleteUserButton.Click += new System.EventHandler(this.DeleteUserButton_Click);
            // 
            // AddNewUserButton
            // 
            this.AddNewUserButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AddNewUserButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddNewUserButton.Location = new System.Drawing.Point(65, 29);
            this.AddNewUserButton.Name = "AddNewUserButton";
            this.AddNewUserButton.Size = new System.Drawing.Size(194, 42);
            this.AddNewUserButton.TabIndex = 0;
            this.AddNewUserButton.Text = "  Add New User";
            this.AddNewUserButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.AddNewUserButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.AddNewUserButton.UseVisualStyleBackColor = true;
            this.AddNewUserButton.Click += new System.EventHandler(this.AddNewUserButton_Click);
            // 
            // StockManageMenu
            // 
            this.StockManageMenu.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.StockManageMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stockManageToolStripMenuItem,
            this.toolStripMenuItem1,
            this.exitToolStripMenuItem});
            this.StockManageMenu.Location = new System.Drawing.Point(0, 0);
            this.StockManageMenu.Name = "StockManageMenu";
            this.StockManageMenu.Size = new System.Drawing.Size(1159, 29);
            this.StockManageMenu.TabIndex = 11;
            this.StockManageMenu.Text = "menuStrip1";
            // 
            // stockManageToolStripMenuItem
            // 
            this.stockManageToolStripMenuItem.Name = "stockManageToolStripMenuItem";
            this.stockManageToolStripMenuItem.Size = new System.Drawing.Size(54, 25);
            this.stockManageToolStripMenuItem.Text = "&Back";
            this.stockManageToolStripMenuItem.Click += new System.EventHandler(this.stockManageToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Enabled = false;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(26, 25);
            this.toolStripMenuItem1.Text = "|";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(46, 25);
            this.exitToolStripMenuItem.Text = "&Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // UserManageForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(1159, 660);
            this.Controls.Add(this.StockManageMenu);
            this.Controls.Add(this.ManageUserGroupBox);
            this.Controls.Add(this.ManageUsersGroupBox);
            this.Controls.Add(this.UserManagementLabel);
            this.Controls.Add(this.shapeContainer1);
            this.Name = "UserManageForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "User Manage Form";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.UserManageForm_FormClosing);
            this.Load += new System.EventHandler(this.UserManageForm_Load);
            this.ManageUserGroupBox.ResumeLayout(false);
            this.ManageUserGroupBox.PerformLayout();
            this.ManageUsersGroupBox.ResumeLayout(false);
            this.ManageUsersGroupBox.PerformLayout();
            this.StockManageMenu.ResumeLayout(false);
            this.StockManageMenu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label UserManagementLabel;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape UserManageRectangle;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private System.Windows.Forms.Button InsertButton;
        private System.Windows.Forms.ComboBox SelectUserComboBox;
        private System.Windows.Forms.Label SelectUserLabel;
        private System.Windows.Forms.TextBox AddressTextBox;
        private System.Windows.Forms.Label AddressLabel;
        private System.Windows.Forms.Button UpdateUserButton;
        private System.Windows.Forms.TextBox MobileNumberTextBox;
        private System.Windows.Forms.ComboBox UserComboBox;
        private System.Windows.Forms.GroupBox ManageUserGroupBox;
        private System.Windows.Forms.Label MobileNumberLabel;
        private System.Windows.Forms.TextBox PasswordTextBox;
        private System.Windows.Forms.Label PaaswordLabel;
        private System.Windows.Forms.TextBox UserIdTextBox;
        private System.Windows.Forms.Label UserIdLabel;
        private System.Windows.Forms.TextBox LastNameTextBox;
        private System.Windows.Forms.Label LastNameLabel;
        private System.Windows.Forms.TextBox FirstNameTextBox;
        private System.Windows.Forms.Label FirstNameLabel;
        private System.Windows.Forms.GroupBox ManageUsersGroupBox;
        private System.Windows.Forms.Button OkButton;
        private System.Windows.Forms.Label UserNameLabel;
        private System.Windows.Forms.Button DeleteUserButton;
        private System.Windows.Forms.Button AddNewUserButton;
        private System.Windows.Forms.Button CancelButton;
        private System.Windows.Forms.MenuStrip StockManageMenu;
        private System.Windows.Forms.ToolStripMenuItem stockManageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
    }
}