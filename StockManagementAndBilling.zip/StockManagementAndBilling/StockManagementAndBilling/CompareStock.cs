﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Windows.Forms.DataVisualization.Charting;

namespace StockManagementAndBilling
{
    public partial class CompareStock : Form
    {
        OleDbConnection con;
        OleDbCommand cmd;
        OleDbDataReader reader;
        OleDbDataAdapter da;
        public CompareStock()
        {
            InitializeComponent();
        }

        private void CompareStock_Load(object sender, EventArgs e)
        {
            CompanySetting();
            //Database Connection
            con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Application.StartupPath + "\\Database/StockManagement.accdb;Persist Security Info=False");
            con.Open();

            // Check Connection, if not then exit in Application
            if (con.State != ConnectionState.Open)
            {
                DialogResult res = MessageBox.Show("Connection fail", "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (res == DialogResult.OK)
                {
                    Application.Exit();
                }
            }
            this.WindowState = FormWindowState.Maximized;
        }

        private void CompanySetting()
        {
            // set company name and set color
            CompanyClass Company = new CompanyClass();
            LogoLabel.Text = Company.CompanyName.ToString();
            // logo color
            LogoLabel.ForeColor = System.Drawing.ColorTranslator.FromHtml(Company.NameColor.ToString());
            LogoLabel.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.NameBackColor.ToString());
            LogoRectangle.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.NameBackColor.ToString());
            // form back color
            this.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.FormBackColor.ToString());
        }

        private void querydata(String query)
        {
            // show data in chart
            try
            {
                cmd = new OleDbCommand(query, con);
                DataTable dt = new DataTable();
                da = new OleDbDataAdapter(cmd);
                da.Fill(dt);
                DataChart.DataSource = dt;
                DataChart.Series["Series1"].Points.Clear();
                DataChart.Series["Series1"].XValueType = ChartValueType.DateTime;
                DataChart.Series["Series1"].XValueMember = "DateDisp";
                
            //    DataChart.Series["Series1"].YAxis.
                DataChart.Series["Series1"].YValueMembers = "Sale";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            // select dates and fire query
            if (Convert.ToDateTime(StartDate.Text.ToString()) > Convert.ToDateTime(EndDate.Text.ToString()))
            {
                MessageBox.Show("Please Select Proper Date","Select Date",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return;
            }
            querydata("select TransactionDate as [DateDisp],Sum(TotalToPay) AS [Sale] from OrderInfo Group By TransactionDate Having TransactionDate between #" + StartDate.Text + "# AND #" + EndDate.Text + "#");
          //  querydata("select TransactionDate,TotalToPay as [Sale] from orderinfo where TransactionDate between #" + StartDate.Value + "# and #" + EndDate.Value + "#");
        }

        private void CompareStock_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.con.Close();
            this.Hide();
        }

        private void stockManageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.con.Close();
            this.Close();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void LogoLabel_ClientSizeChanged(object sender, EventArgs e)
        {
            LogoLabel.Left = (this.ClientSize.Width - LogoLabel.Size.Width) / 2;
        }
    }
}
