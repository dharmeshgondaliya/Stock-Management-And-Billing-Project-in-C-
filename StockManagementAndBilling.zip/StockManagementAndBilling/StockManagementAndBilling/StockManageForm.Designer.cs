﻿namespace StockManagementAndBilling
{
    partial class StockManageForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AddItemButton = new System.Windows.Forms.Button();
            this.CompanyNameLabel = new System.Windows.Forms.Label();
            this.QuantityTextBox = new System.Windows.Forms.TextBox();
            this.QuantityLabel = new System.Windows.Forms.Label();
            this.PriceTextBox = new System.Windows.Forms.TextBox();
            this.UpdateItemButton = new System.Windows.Forms.Button();
            this.PriceLabel = new System.Windows.Forms.Label();
            this.NameTextBox = new System.Windows.Forms.TextBox();
            this.NameLabel = new System.Windows.Forms.Label();
            this.ItemNameComboBox = new System.Windows.Forms.ComboBox();
            this.DeleteItemButton = new System.Windows.Forms.Button();
            this.ItemNameLabel = new System.Windows.Forms.Label();
            this.StockManageGroupBox = new System.Windows.Forms.GroupBox();
            this.CancleButton = new System.Windows.Forms.Button();
            this.CompanyNameTextBox = new System.Windows.Forms.TextBox();
            this.StocksManageGroupBox = new System.Windows.Forms.GroupBox();
            this.CompaniNameComboBox = new System.Windows.Forms.ComboBox();
            this.OkButton = new System.Windows.Forms.Button();
            this.AddNewItemButton = new System.Windows.Forms.Button();
            this.CompaniNameLabel = new System.Windows.Forms.Label();
            this.StockManagementLable = new System.Windows.Forms.Label();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.LogoRectangle = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.StockManageMenu = new System.Windows.Forms.MenuStrip();
            this.stockManageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.StockManageGroupBox.SuspendLayout();
            this.StocksManageGroupBox.SuspendLayout();
            this.StockManageMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // AddItemButton
            // 
            this.AddItemButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AddItemButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddItemButton.Location = new System.Drawing.Point(59, 238);
            this.AddItemButton.Name = "AddItemButton";
            this.AddItemButton.Size = new System.Drawing.Size(154, 40);
            this.AddItemButton.TabIndex = 7;
            this.AddItemButton.Text = "Add Item";
            this.AddItemButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.AddItemButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.AddItemButton.UseVisualStyleBackColor = true;
            this.AddItemButton.Click += new System.EventHandler(this.AddItemButton_Click);
            // 
            // CompanyNameLabel
            // 
            this.CompanyNameLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.CompanyNameLabel.AutoSize = true;
            this.CompanyNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CompanyNameLabel.Location = new System.Drawing.Point(55, 185);
            this.CompanyNameLabel.Name = "CompanyNameLabel";
            this.CompanyNameLabel.Size = new System.Drawing.Size(122, 20);
            this.CompanyNameLabel.TabIndex = 0;
            this.CompanyNameLabel.Text = "Company Name";
            // 
            // QuantityTextBox
            // 
            this.QuantityTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.QuantityTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QuantityTextBox.Location = new System.Drawing.Point(197, 134);
            this.QuantityTextBox.Name = "QuantityTextBox";
            this.QuantityTextBox.Size = new System.Drawing.Size(271, 26);
            this.QuantityTextBox.TabIndex = 5;
            this.QuantityTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.QuantityTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.QuantityTextBox_KeyPress);
            // 
            // QuantityLabel
            // 
            this.QuantityLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.QuantityLabel.AutoSize = true;
            this.QuantityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QuantityLabel.Location = new System.Drawing.Point(55, 137);
            this.QuantityLabel.Name = "QuantityLabel";
            this.QuantityLabel.Size = new System.Drawing.Size(104, 20);
            this.QuantityLabel.TabIndex = 0;
            this.QuantityLabel.Text = "Item Quantity";
            // 
            // PriceTextBox
            // 
            this.PriceTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.PriceTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PriceTextBox.Location = new System.Drawing.Point(197, 83);
            this.PriceTextBox.Name = "PriceTextBox";
            this.PriceTextBox.Size = new System.Drawing.Size(271, 26);
            this.PriceTextBox.TabIndex = 4;
            this.PriceTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.PriceTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.PriceTextBox_KeyPress);
            // 
            // UpdateItemButton
            // 
            this.UpdateItemButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.UpdateItemButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateItemButton.Location = new System.Drawing.Point(48, 97);
            this.UpdateItemButton.Name = "UpdateItemButton";
            this.UpdateItemButton.Size = new System.Drawing.Size(213, 43);
            this.UpdateItemButton.TabIndex = 0;
            this.UpdateItemButton.Text = "Update Item";
            this.UpdateItemButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.UpdateItemButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.UpdateItemButton.UseVisualStyleBackColor = true;
            this.UpdateItemButton.Click += new System.EventHandler(this.UpdateItemButton_Click);
            // 
            // PriceLabel
            // 
            this.PriceLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.PriceLabel.AutoSize = true;
            this.PriceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PriceLabel.Location = new System.Drawing.Point(55, 86);
            this.PriceLabel.Name = "PriceLabel";
            this.PriceLabel.Size = new System.Drawing.Size(80, 20);
            this.PriceLabel.TabIndex = 0;
            this.PriceLabel.Text = "Item Price";
            // 
            // NameTextBox
            // 
            this.NameTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.NameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameTextBox.Location = new System.Drawing.Point(197, 34);
            this.NameTextBox.Name = "NameTextBox";
            this.NameTextBox.Size = new System.Drawing.Size(271, 26);
            this.NameTextBox.TabIndex = 3;
            this.NameTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NameTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NameTextBox_KeyPress);
            // 
            // NameLabel
            // 
            this.NameLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.NameLabel.AutoSize = true;
            this.NameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameLabel.Location = new System.Drawing.Point(55, 37);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(87, 20);
            this.NameLabel.TabIndex = 0;
            this.NameLabel.Text = "Item Name";
            // 
            // ItemNameComboBox
            // 
            this.ItemNameComboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ItemNameComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ItemNameComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemNameComboBox.FormattingEnabled = true;
            this.ItemNameComboBox.Location = new System.Drawing.Point(48, 263);
            this.ItemNameComboBox.Name = "ItemNameComboBox";
            this.ItemNameComboBox.Size = new System.Drawing.Size(213, 28);
            this.ItemNameComboBox.TabIndex = 1;
            this.ItemNameComboBox.SelectedIndexChanged += new System.EventHandler(this.ItemNameComboBox_SelectedIndexChanged);
            // 
            // DeleteItemButton
            // 
            this.DeleteItemButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.DeleteItemButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeleteItemButton.Location = new System.Drawing.Point(48, 158);
            this.DeleteItemButton.Name = "DeleteItemButton";
            this.DeleteItemButton.Size = new System.Drawing.Size(213, 43);
            this.DeleteItemButton.TabIndex = 0;
            this.DeleteItemButton.Text = "Delete Item";
            this.DeleteItemButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.DeleteItemButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.DeleteItemButton.UseVisualStyleBackColor = true;
            this.DeleteItemButton.Click += new System.EventHandler(this.DeleteItemButton_Click);
            // 
            // ItemNameLabel
            // 
            this.ItemNameLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ItemNameLabel.AutoSize = true;
            this.ItemNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemNameLabel.Location = new System.Drawing.Point(45, 238);
            this.ItemNameLabel.Name = "ItemNameLabel";
            this.ItemNameLabel.Size = new System.Drawing.Size(87, 20);
            this.ItemNameLabel.TabIndex = 0;
            this.ItemNameLabel.Text = "Item Name";
            // 
            // StockManageGroupBox
            // 
            this.StockManageGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.StockManageGroupBox.Controls.Add(this.CancleButton);
            this.StockManageGroupBox.Controls.Add(this.AddItemButton);
            this.StockManageGroupBox.Controls.Add(this.CompanyNameTextBox);
            this.StockManageGroupBox.Controls.Add(this.CompanyNameLabel);
            this.StockManageGroupBox.Controls.Add(this.QuantityTextBox);
            this.StockManageGroupBox.Controls.Add(this.QuantityLabel);
            this.StockManageGroupBox.Controls.Add(this.PriceTextBox);
            this.StockManageGroupBox.Controls.Add(this.PriceLabel);
            this.StockManageGroupBox.Controls.Add(this.NameTextBox);
            this.StockManageGroupBox.Controls.Add(this.NameLabel);
            this.StockManageGroupBox.Location = new System.Drawing.Point(534, 176);
            this.StockManageGroupBox.Name = "StockManageGroupBox";
            this.StockManageGroupBox.Size = new System.Drawing.Size(540, 299);
            this.StockManageGroupBox.TabIndex = 6;
            this.StockManageGroupBox.TabStop = false;
            // 
            // CancleButton
            // 
            this.CancleButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.CancleButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CancleButton.Location = new System.Drawing.Point(314, 238);
            this.CancleButton.Name = "CancleButton";
            this.CancleButton.Size = new System.Drawing.Size(154, 40);
            this.CancleButton.TabIndex = 8;
            this.CancleButton.Text = "Cancle";
            this.CancleButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.CancleButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.CancleButton.UseVisualStyleBackColor = true;
            this.CancleButton.Click += new System.EventHandler(this.CancleButton_Click);
            // 
            // CompanyNameTextBox
            // 
            this.CompanyNameTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.CompanyNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CompanyNameTextBox.Location = new System.Drawing.Point(197, 182);
            this.CompanyNameTextBox.Name = "CompanyNameTextBox";
            this.CompanyNameTextBox.Size = new System.Drawing.Size(271, 26);
            this.CompanyNameTextBox.TabIndex = 6;
            this.CompanyNameTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.CompanyNameTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CompanyNameTextBox_KeyPress);
            // 
            // StocksManageGroupBox
            // 
            this.StocksManageGroupBox.Controls.Add(this.CompaniNameComboBox);
            this.StocksManageGroupBox.Controls.Add(this.UpdateItemButton);
            this.StocksManageGroupBox.Controls.Add(this.OkButton);
            this.StocksManageGroupBox.Controls.Add(this.ItemNameComboBox);
            this.StocksManageGroupBox.Controls.Add(this.DeleteItemButton);
            this.StocksManageGroupBox.Controls.Add(this.AddNewItemButton);
            this.StocksManageGroupBox.Controls.Add(this.CompaniNameLabel);
            this.StocksManageGroupBox.Controls.Add(this.ItemNameLabel);
            this.StocksManageGroupBox.Location = new System.Drawing.Point(91, 176);
            this.StocksManageGroupBox.Name = "StocksManageGroupBox";
            this.StocksManageGroupBox.Size = new System.Drawing.Size(317, 428);
            this.StocksManageGroupBox.TabIndex = 7;
            this.StocksManageGroupBox.TabStop = false;
            // 
            // CompaniNameComboBox
            // 
            this.CompaniNameComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CompaniNameComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CompaniNameComboBox.FormattingEnabled = true;
            this.CompaniNameComboBox.Location = new System.Drawing.Point(49, 319);
            this.CompaniNameComboBox.Name = "CompaniNameComboBox";
            this.CompaniNameComboBox.Size = new System.Drawing.Size(212, 28);
            this.CompaniNameComboBox.TabIndex = 3;
            // 
            // OkButton
            // 
            this.OkButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.OkButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OkButton.Location = new System.Drawing.Point(48, 359);
            this.OkButton.Name = "OkButton";
            this.OkButton.Size = new System.Drawing.Size(136, 39);
            this.OkButton.TabIndex = 2;
            this.OkButton.Text = " OK";
            this.OkButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.OkButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.OkButton.UseVisualStyleBackColor = true;
            this.OkButton.Click += new System.EventHandler(this.OkButton_Click);
            // 
            // AddNewItemButton
            // 
            this.AddNewItemButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AddNewItemButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddNewItemButton.Location = new System.Drawing.Point(48, 37);
            this.AddNewItemButton.Name = "AddNewItemButton";
            this.AddNewItemButton.Size = new System.Drawing.Size(213, 43);
            this.AddNewItemButton.TabIndex = 0;
            this.AddNewItemButton.Text = "Add New Item";
            this.AddNewItemButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.AddNewItemButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.AddNewItemButton.UseVisualStyleBackColor = true;
            this.AddNewItemButton.Click += new System.EventHandler(this.AddNewItemButton_Click);
            // 
            // CompaniNameLabel
            // 
            this.CompaniNameLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.CompaniNameLabel.AutoSize = true;
            this.CompaniNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CompaniNameLabel.Location = new System.Drawing.Point(45, 295);
            this.CompaniNameLabel.Name = "CompaniNameLabel";
            this.CompaniNameLabel.Size = new System.Drawing.Size(122, 20);
            this.CompaniNameLabel.TabIndex = 0;
            this.CompaniNameLabel.Text = "Company Name";
            // 
            // StockManagementLable
            // 
            this.StockManagementLable.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.StockManagementLable.AutoSize = true;
            this.StockManagementLable.BackColor = System.Drawing.Color.Black;
            this.StockManagementLable.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StockManagementLable.ForeColor = System.Drawing.Color.White;
            this.StockManagementLable.Location = new System.Drawing.Point(336, 35);
            this.StockManagementLable.Name = "StockManagementLable";
            this.StockManagementLable.Size = new System.Drawing.Size(493, 46);
            this.StockManagementLable.TabIndex = 8;
            this.StockManagementLable.Text = "Stock Management & Billing";
            this.StockManagementLable.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.StockManagementLable.ClientSizeChanged += new System.EventHandler(this.StockManagementLable_ClientSizeChanged);
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.LogoRectangle});
            this.shapeContainer1.Size = new System.Drawing.Size(1165, 649);
            this.shapeContainer1.TabIndex = 9;
            this.shapeContainer1.TabStop = false;
            // 
            // LogoRectangle
            // 
            this.LogoRectangle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LogoRectangle.BackColor = System.Drawing.Color.Black;
            this.LogoRectangle.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.LogoRectangle.BorderColor = System.Drawing.Color.White;
            this.LogoRectangle.Location = new System.Drawing.Point(-8, 23);
            this.LogoRectangle.Name = "LogoRectangle";
            this.LogoRectangle.Size = new System.Drawing.Size(1183, 70);
            // 
            // StockManageMenu
            // 
            this.StockManageMenu.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.StockManageMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stockManageToolStripMenuItem,
            this.toolStripMenuItem1,
            this.exitToolStripMenuItem});
            this.StockManageMenu.Location = new System.Drawing.Point(0, 0);
            this.StockManageMenu.Name = "StockManageMenu";
            this.StockManageMenu.Size = new System.Drawing.Size(1165, 29);
            this.StockManageMenu.TabIndex = 10;
            this.StockManageMenu.Text = "menuStrip1";
            // 
            // stockManageToolStripMenuItem
            // 
            this.stockManageToolStripMenuItem.Name = "stockManageToolStripMenuItem";
            this.stockManageToolStripMenuItem.Size = new System.Drawing.Size(54, 25);
            this.stockManageToolStripMenuItem.Text = "&Back";
            this.stockManageToolStripMenuItem.Click += new System.EventHandler(this.stockManageToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Enabled = false;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(26, 25);
            this.toolStripMenuItem1.Text = "|";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(46, 25);
            this.exitToolStripMenuItem.Text = "&Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // StockManageForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(1165, 649);
            this.Controls.Add(this.StockManageGroupBox);
            this.Controls.Add(this.StocksManageGroupBox);
            this.Controls.Add(this.StockManagementLable);
            this.Controls.Add(this.StockManageMenu);
            this.Controls.Add(this.shapeContainer1);
            this.Name = "StockManageForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Stock Manage";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.StockManageForm_FormClosing);
            this.Load += new System.EventHandler(this.StockManageForm_Load);
            this.StockManageGroupBox.ResumeLayout(false);
            this.StockManageGroupBox.PerformLayout();
            this.StocksManageGroupBox.ResumeLayout(false);
            this.StocksManageGroupBox.PerformLayout();
            this.StockManageMenu.ResumeLayout(false);
            this.StockManageMenu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button AddItemButton;
        private System.Windows.Forms.Label CompanyNameLabel;
        private System.Windows.Forms.TextBox QuantityTextBox;
        private System.Windows.Forms.Label QuantityLabel;
        private System.Windows.Forms.TextBox PriceTextBox;
        private System.Windows.Forms.Button UpdateItemButton;
        private System.Windows.Forms.Label PriceLabel;
        private System.Windows.Forms.TextBox NameTextBox;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.ComboBox ItemNameComboBox;
        private System.Windows.Forms.Button DeleteItemButton;
        private System.Windows.Forms.Label ItemNameLabel;
        private System.Windows.Forms.GroupBox StockManageGroupBox;
        private System.Windows.Forms.TextBox CompanyNameTextBox;
        private System.Windows.Forms.GroupBox StocksManageGroupBox;
        private System.Windows.Forms.Button OkButton;
        private System.Windows.Forms.Button AddNewItemButton;
        private System.Windows.Forms.Label StockManagementLable;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape LogoRectangle;
        private System.Windows.Forms.Button CancleButton;
        private System.Windows.Forms.MenuStrip StockManageMenu;
        private System.Windows.Forms.ToolStripMenuItem stockManageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ComboBox CompaniNameComboBox;
        private System.Windows.Forms.Label CompaniNameLabel;
    }
}