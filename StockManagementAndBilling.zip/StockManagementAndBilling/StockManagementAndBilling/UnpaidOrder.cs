﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace StockManagementAndBilling
{
    public partial class UnpaidOrder : Form
    {
        OleDbConnection con;
        OleDbCommand cmd;
        OleDbDataReader reader;
        private int itemNumber = 0;
        private int printItem = 0;
        private int no = 1;
        private String Order;
        public UnpaidOrder()
        {
            InitializeComponent();
        }

        private void UnpaidOrder_Load(object sender, EventArgs e)
        {
            CompanySetting();
            // set Icons
            SearchButton.Image = Image.FromFile(Application.StartupPath + "/icons/Search.png");
            PaymentButton.Image = Image.FromFile(Application.StartupPath + "/icons/Payment.png");
            CancleButton.Image = Image.FromFile(Application.StartupPath + "/icons/Cancel.png");
            CoustomerName.Text = "";
            TransactionDate.Text = "";
            TotalAmount.Text = "";
            PaymentButton.Enabled = false;
            CancleButton.Enabled = false;

            //Database Connection
            con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Application.StartupPath + "\\Database/StockManagement.accdb;Persist Security Info=False");
            con.Open();

            // Check Connection, if not then exit in Application
            if (con.State != ConnectionState.Open)
            {
                DialogResult res = MessageBox.Show("Connection fail", "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (res == DialogResult.OK)
                {
                    Application.Exit();
                }
            }
        }

        private void CompanySetting()
        {
            CompanyClass Company = new CompanyClass();
            UnpaidOrderLabel.Text = Company.CompanyName.ToString();
            // logo color
            UnpaidOrderLabel.ForeColor = System.Drawing.ColorTranslator.FromHtml(Company.NameColor.ToString());
            UnpaidOrderLabel.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.NameBackColor.ToString());
            LogoRectangle.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.NameBackColor.ToString());
            // form color
            this.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.FormBackColor.ToString());
        }

        private void PaymentButton_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are You Sure To Payment Now?","Payment",MessageBoxButtons.YesNo,MessageBoxIcon.Information);
            if (dr.ToString() == "Yes" && Order == BillNumberTextBox.Text.Trim())
            {
                try
                {
                    cmd = new OleDbCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "update OrderInfo set PaymentType = 'Paid' where OrderNumber = '" + BillNumberTextBox.Text.Trim() + "'";
                    cmd.ExecuteNonQuery();
                    UnpaidOrderPrintDocument.Print();
                    MessageBox.Show("Order Pay Successfull","Success",MessageBoxButtons.OK,MessageBoxIcon.Information);
                    CoustomerName.Text = "";
                    TransactionDate.Text = "";
                    TotalAmount.Text = "";
                    BillNumberTextBox.Text = "";
                    PaymentButton.Enabled = false;
                    CancleButton.Enabled = false;
                }
                catch(Exception ep){
                    MessageBox.Show(ep.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                    return;
                }
            }
        }

        private void CancleButton_Click(object sender, EventArgs e)
        {
            CoustomerName.Text = "";
            TransactionDate.Text = "";
            TotalAmount.Text = "";
            BillNumberTextBox.Text = "";
            PaymentButton.Enabled = false;
            CancleButton.Enabled = false;
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            SetValue();
        }

        private void BillNumberTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == 13){
                SetValue();    
            }
        }
        private void SetValue()
        {
            if (BillNumberTextBox.Text.Trim() != "")
            {
                try
                {
                    cmd = new OleDbCommand("select CoustomerName,TransactionDate,TotalToPay from OrderInfo where OrderNumber = '" + BillNumberTextBox.Text.Trim() + "' AND PaymentType = 'Unpaid'", con);
                    reader = cmd.ExecuteReader();
                    if (reader.FieldCount == 0)
                    {
                        MessageBox.Show("Item Not Found", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        CoustomerName.Text = "";
                        TransactionDate.Text = "";
                        TotalAmount.Text = "";
                        BillNumberTextBox.Text = "";
                        PaymentButton.Enabled = false;
                        CancleButton.Enabled = false;
                        return;
                    }
                    if (reader.Read())
                    {
                        Order = BillNumberTextBox.Text.Trim();
                        CoustomerName.Text = reader["CoustomerName"].ToString();
                        TransactionDate.Text = reader["TransactionDate"].ToString();
                        TotalAmount.Text = reader["TotalToPay"].ToString();
                        PaymentButton.Enabled = true;
                        CancleButton.Enabled = true;
                    }
                    else {
                        MessageBox.Show("Item Not Found", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        CoustomerName.Text = "";
                        TransactionDate.Text = "";
                        TotalAmount.Text = "";
                        BillNumberTextBox.Text = "";
                        PaymentButton.Enabled = false;
                        CancleButton.Enabled = false;
                        return;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }
            else
            {
                MessageBox.Show("Please Enter Bill Number in Textbox", "Enter Bill Number", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                CoustomerName.Text = "";
                TransactionDate.Text = "";
                TotalAmount.Text = "";
                PaymentButton.Enabled = true;
                CancleButton.Enabled = true;
                return;
            }
        }

        private void UnpaidOrder_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.con.Close();
        }

        private void stockManageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.con.Close();
            this.Hide();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void UnpaidOrderPrintDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            decimal Price = 0;
            int Quantity = 0;
            try
            {
                cmd = new OleDbCommand("select CoustomerName,OrderNumber from OrderInfo where OrderNumber = '"+Order+"'",con);
                reader = cmd.ExecuteReader();
                reader.Read();
            }
            catch(Exception exp){
                MessageBox.Show(exp.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }
            CompanyClass CC = new CompanyClass();
            StringFormat sformat = new StringFormat();
            sformat.Alignment = StringAlignment.Center;
            // Company Name
            e.Graphics.DrawString(CC.CompanyName.ToString(), new Font("Arial", 35, FontStyle.Bold), Brushes.Black, new Point(400, 10), sformat);
            //Company Address
            e.Graphics.DrawString("Address: " + CC.CAddress.ToString(), new Font("Arial", 15, FontStyle.Italic), Brushes.Black, new Point(400, 65), sformat);
            //Company Mobile
            e.Graphics.DrawString("Mobile: " + CC.CMobile, new Font("Arial", 15, FontStyle.Italic), Brushes.Black, new Point(400, 85), sformat);
            //Company Email
            e.Graphics.DrawString("Email: " + CC.CEmail, new Font("Arial", 15, FontStyle.Italic), Brushes.Black, new Point(400, 105), sformat);
            //GST Number
            e.Graphics.DrawString("GST Number: " + CC.GSTNUMBER, new Font("Arial", 15, FontStyle.Italic), Brushes.Black, new Point(400, 125), sformat);
            // Date
            e.Graphics.DrawString("Date: " + DateTime.Now.ToShortDateString(), new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(25, 160));
            // Sales By Name
            e.Graphics.DrawString("Sales By: " + UserClass.UserName.ToString(), new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(405, 160));
            // Client Name
            e.Graphics.DrawString("Client Name: " + reader["CoustomerName"].ToString(), new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(25, 190));
            // ------
            e.Graphics.DrawString("------------------------------------------------------------------------------------------------------------------", new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(25, 235));
            // Item Header
            e.Graphics.DrawString("Sr", new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(30, 255));
            e.Graphics.DrawString("Item Name", new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(70, 255));
            e.Graphics.DrawString("Quantity:", new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(405, 255));
            e.Graphics.DrawString("Unit Price:", new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(535, 255));
            e.Graphics.DrawString("Total Price", new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(680, 255));
            try {
                cmd = new OleDbCommand("select ItemName,Quantity,UnitPrice,TotalPrice from OrderItems where OrderNumbers = '"+Order+"'",con);
                reader = cmd.ExecuteReader();
            }
            catch(Exception expe){
                MessageBox.Show(expe.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }
            // ------
            e.Graphics.DrawString("------------------------------------------------------------------------------------------------------------------", new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(25, 270));
            int pos = 295;
            int i = printItem;
            while(reader.Read())
            {
                itemNumber++;
                if (itemNumber <= 20)
                {
                    printItem++;
                    if (printItem <= reader.FieldCount)
                    {
                        e.Graphics.DrawString(no.ToString(), new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(30, pos));
                        e.Graphics.DrawString(reader["ItemName"].ToString(), new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(70, pos));
                        e.Graphics.DrawString(reader["Quantity"].ToString(), new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(420, pos));
                        e.Graphics.DrawString(reader["UnitPrice"].ToString(), new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(545, pos));
                        e.Graphics.DrawString(reader["TotalPrice"].ToString(), new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(680, pos));

                        Quantity += Convert.ToInt16(reader["Quantity"].ToString());
                        Price += Convert.ToDecimal(reader["TotalPrice"].ToString());

                        pos += 30;
                        no++;
                    }
                    else
                    {
                        e.HasMorePages = false;
                    }
                }
                else
                {
                    e.Graphics.DrawString("------------------------------------------------------------------------------------------------------------------", new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(25, pos));
                    pos += 30;

                    itemNumber = 0;
                    e.HasMorePages = true;
                    return;
                }
                i++;
            }
            pos -= 5;
            // ------
            e.Graphics.DrawString("------------------------------------------------------------------------------------------------------------------", new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(25, pos));
            pos += 25;
            e.Graphics.DrawString("Total", new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(70, pos));
            e.Graphics.DrawString(Quantity.ToString(), new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(420, pos));
            e.Graphics.DrawString(Price.ToString(), new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(680, pos));
            pos += 20;
            e.Graphics.DrawString("------------------------------------------------------------------------------------------------------------------", new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(25, pos));

            try {
                cmd = new OleDbCommand("select CGST,SGST,Discount from OrderInfo where OrderNumber = '"+Order+"'",con);
                reader = cmd.ExecuteReader();
                reader.Read();
            }
            catch(Exception expn){
                MessageBox.Show(expn.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }
            int cgst = Convert.ToInt16(reader["CGST"].ToString());
            int sgst = Convert.ToInt16(reader["SGST"].ToString());
            decimal CGST = (Price * cgst) / 100;
            decimal SGST = (Price * sgst) / 100;
            pos += 30;
            e.Graphics.DrawString("CGST " + cgst.ToString() + "%", new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(405, pos));
            e.Graphics.DrawString(CGST.ToString(), new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(680, pos));
            pos += 30;
            e.Graphics.DrawString("SGST " + sgst.ToString() + "%", new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(405, pos));
            e.Graphics.DrawString(SGST.ToString(), new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(680, pos));
            pos += 30;
            e.Graphics.DrawString("Total", new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(405, pos));
            e.Graphics.DrawString((Price + CGST + SGST).ToString(), new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(680, pos));

            pos += 35;
            int discount = Convert.ToInt16(reader["Discount"].ToString());
            decimal DISCOUNT = ((Price + CGST + SGST) * discount) / 100;
            e.Graphics.DrawString("Discount " + discount.ToString() + "%", new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(405, pos));
            e.Graphics.DrawString(DISCOUNT.ToString(), new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(680, pos));
            pos += 30;
            e.Graphics.DrawString("Total To Pay", new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(405, pos));
            e.Graphics.DrawString(((Price + CGST + SGST) - DISCOUNT).ToString(), new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(680, pos));
            itemNumber = 0;
            printItem = 0;
            no = 1;
        }

        private void UnpaidOrderLabel_ClientSizeChanged(object sender, EventArgs e)
        {
            UnpaidOrderLabel.Left = (this.ClientSize.Width - UnpaidOrderLabel.Size.Width) / 2;
        }
    }
}
