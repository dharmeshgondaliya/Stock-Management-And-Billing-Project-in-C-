﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace StockManagementAndBilling
{
    public partial class CompanySettings : Form
    {
        OleDbConnection con;
        OleDbCommand cmd;
        OleDbDataReader reader;
        String CNM;
        public CompanySettings()
        {
            InitializeComponent();
        }

        private void CompanySettings_Load(object sender, EventArgs e)
        {
            CompanySetting();
            //Database Connection
            con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Application.StartupPath + "\\Database/StockManagement.accdb;Persist Security Info=False");
            con.Open();

            // Check Connection, if not then exit in Application
            if (con.State != ConnectionState.Open)
            {
                DialogResult res = MessageBox.Show("Connection fail", "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (res == DialogResult.OK)
                {
                    Application.Exit();
                }
            }

            SetData();
            EditeButton.Image = Image.FromFile(Application.StartupPath + "/icons/Edit.png");
            enabletf(false);
            SaveCompanySetting.Enabled = false;
            SaveCompanySetting.Image = Image.FromFile(Application.StartupPath+"/icons/Save.png");
            this.WindowState = FormWindowState.Maximized;
        }

        private void CompanySetting()
        {
            //set Company name, button icons, form color
            CompanyClass Company = new CompanyClass();
            AvailabelStockLabel.Text = Company.CompanyName.ToString();
            AvailabelStockLabel.ForeColor = System.Drawing.ColorTranslator.FromHtml(Company.NameColor.ToString());
            AvailabelStockLabel.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.NameBackColor.ToString());
            LogoRectangle.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.NameBackColor.ToString());
            this.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.FormBackColor.ToString());  
        }

        private void SetData()
        {
            // set data in textbox
            try
            {
                cmd = new OleDbCommand("select * from CompanyInfo", con);
                reader = cmd.ExecuteReader();
                reader.Read();
                CNM = reader["CompanyName"].ToString();
                CompanyNameTextBox.Text = reader["CompanyName"].ToString();
                MobileNumberTextBox.Text = reader["MobileNumber"].ToString();
                EmailIdTextBox.Text = reader["Email"].ToString();
                AddressTextBox.Text = reader["CompanyAddress"].ToString();
                GstNumberTextBox.Text = reader["GSTNumber"].ToString();
                CgstTextBox.Text = reader["CGST"].ToString();
                SgstTextBox.Text = reader["SGST"].ToString();
                DiscountTextBox.Text = reader["Discount"].ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void enabletf(Boolean tf) {
            // enable true / false
            CompanyNameTextBox.Enabled = tf;
            MobileNumberTextBox.Enabled = tf;
            EmailIdTextBox.Enabled = tf;
            AddressTextBox.Enabled = tf;
            GstNumberTextBox.Enabled = tf;
            CgstTextBox.Enabled = tf;
            SgstTextBox.Enabled = tf;
            DiscountTextBox.Enabled = tf;
        }

        private void CompanyNameTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // company name
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122 || e.KeyChar == 8 || e.KeyChar == 32 || e.KeyChar == 13 || e.KeyChar >= 48 && e.KeyChar <= 57)
            {
                if (e.KeyChar == 13)
                {
                    MobileNumberTextBox.Focus();
                }
                else
                {
                    e.Handled = false;
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void MobileNumberTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // enter only mobile number
            if (e.KeyChar >= 48 && e.KeyChar <= 57 || e.KeyChar == 8 || e.KeyChar == 13)
            {
                if (e.KeyChar == 13)
                {
                    EmailIdTextBox.Focus();
                }
                else
                {
                    e.Handled = false;
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void EmailIdTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // enter email
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122 || e.KeyChar == 8 || e.KeyChar == 32 || e.KeyChar == 13 || e.KeyChar >= 48 && e.KeyChar <= 57 || e.KeyChar ==  46 || e.KeyChar == 64 )
            {
                if (e.KeyChar == 13)
                {
                    AddressTextBox.Focus();
                }
                else
                {
                    e.Handled = false;
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void AddressTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // enter address
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122 || e.KeyChar >= 48 && e.KeyChar <= 57 || e.KeyChar == 13 || e.KeyChar == 8 || e.KeyChar == 32 || e.KeyChar == 46 || e.KeyChar == 13 || e.KeyChar == 44)
            {
                if (e.KeyChar == 13)
                {
                    GstNumberTextBox.Focus();
                }
                else
                {
                    e.Handled = false;
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void GstNumberTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // enter gst number
            if (e.KeyChar == 13)
            {
                CgstTextBox.Focus();
            }
            else
            {
                e.Handled = false;
            }
        }

        private void GST_Keypress(object sender, KeyPressEventArgs e)
        {
            // enter cgst & sgst
            if (e.KeyChar >= 48 && e.KeyChar <= 57 || e.KeyChar == 8 || e.KeyChar == 13 || e.KeyChar == 46)
            {
                if (e.KeyChar == 13)
                {
                    if(sender == CgstTextBox){
                        SgstTextBox.Focus();
                    }
                    else
                    {
                        DiscountTextBox.Focus();
                    }
                }
                else
                {
                    e.Handled = false;
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void DiscountTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // enter discount
            if (e.KeyChar >= 48 && e.KeyChar <= 57 || e.KeyChar == 8 || e.KeyChar == 13 || e.KeyChar == 46)
            {
                if (e.KeyChar == 13)
                {
                    SaveCompanySetting.Focus();
                }
                else
                {
                    e.Handled = false;
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private bool Validation()
        {
            //TextBox Validation
            if (CompanyNameTextBox.Text.Trim() == "")
            {
                MessageBox.Show("Please Enter Company Name", "Enter Company Name", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                CompanyNameTextBox.Focus();
                return false;
            }

            if (MobileNumberTextBox.Text.Trim() == "" || MobileNumberTextBox.Text.Trim().Length != 10)
            {
                MessageBox.Show("Please Enter Mobile Number", "Enter Mobile Number", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                MobileNumberTextBox.Focus();
                return false;
            }

            if (EmailIdTextBox.Text.Trim() == "")
            {
                MessageBox.Show("Please Enter Email ID", "Enter Email ID", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                EmailIdTextBox.Focus();
                return false;
            }

            if (AddressTextBox.Text.Trim() == "")
            {
                MessageBox.Show("Please Enter Company Address", "Enter Company Address", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                AddressTextBox.Focus();
                return false;
            }

            if (GstNumberTextBox.Text.Trim() == "")
            {
                MessageBox.Show("Please Enter GST Number", "Enter GST Number", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                GstNumberTextBox.Focus();
                return false;
            }

            if (CgstTextBox.Text.Trim() == "")
            {
                MessageBox.Show("Please Enter CGST", "Enter CGST", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                CgstTextBox.Focus();
                return false;
            }

            if (SgstTextBox.Text.Trim() == "")
            {
                MessageBox.Show("Please Enter SGST", "Enter SGST", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                SgstTextBox.Focus();
                return false;
            }

            if (DiscountTextBox.Text.Trim() == "")
            {
                MessageBox.Show("Please Enter Discount", "Enter Discount", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                DiscountTextBox.Focus();
                return false;
            }

            if (Convert.ToDecimal(CgstTextBox.Text) >= 100)
            {
                MessageBox.Show("Please Enter Proper CGST", "Enter CGST", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                CgstTextBox.Focus();
                return false;
            }

            if (Convert.ToDecimal(SgstTextBox.Text) >= 100)
            {
                MessageBox.Show("Please Enter Proper SGST", "Enter SGST", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                SgstTextBox.Focus();
                return false;
            }

            if ((Convert.ToDecimal(SgstTextBox.Text) + Convert.ToDecimal(CgstTextBox.Text)) >= 100)
            {
                MessageBox.Show("Please Enter CGST & SGST Under 100", "Enter CSGT & SGST", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                CgstTextBox.Focus();
                return false;
            }

            if (Convert.ToDecimal(DiscountTextBox.Text) > 100)
            {
                MessageBox.Show("Please Enter Discount under 100", "Enter Discount", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                DiscountTextBox.Focus();
                return false;
            }
            return true;
        }

        private void SaveCompanySetting_Click(object sender, EventArgs e)
        {
            // if validation true then save data
            if(Validation()){
                SaveCompanyData();
            }
        }

        private void SaveCompanyData()
        {
            // update company data 
            String CName = CompanyNameTextBox.Text.Trim();
            String Mobile = MobileNumberTextBox.Text.Trim();
            String Email = EmailIdTextBox.Text.Trim();
            String Address = AddressTextBox.Text.Trim();
            String GSTNO = GstNumberTextBox.Text.Trim();
            String CSGT = CgstTextBox.Text.Trim();
            String SGST = SgstTextBox.Text.Trim();
            String Discount = DiscountTextBox.Text.Trim();

            try {
                cmd = new OleDbCommand("update CompanyInfo set CompanyName = '"+CName+"',MobileNumber = '"+Mobile+"',Email = '"+Email+"',CompanyAddress = '"+Address+"', GSTNumber = '"+GSTNO+"', CGST = '"+CSGT+"', SGST = '"+SGST+"', Discount = '"+Discount+"'  where CompanyName = '"+CNM+"'",con);
                cmd.ExecuteNonQuery();
                if(CName != CNM){
                    cmd = new OleDbCommand("update Colors set CompanyName = '"+CName+"' where CompanyName = '"+CNM+"'",con);
                    cmd.ExecuteNonQuery();
                    CNM = CName;
                }
            }
            catch(Exception exp){
                MessageBox.Show(exp.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }
            MessageBox.Show("Data Update Success","Data Update",MessageBoxButtons.OK,MessageBoxIcon.Information);
            CompanySetting();
            SaveCompanySetting.Enabled = false;
            EditeButton.Text = "Edit";
            EditeButton.Image = Image.FromFile(Application.StartupPath + "/icons/Edit.png");
            enabletf(false);
        }

        private void ChangeComBackColor_Click(object sender, EventArgs e)
        {
            SetColor("NameBackColor");
        }

        private void ChangeComNameColor_Click(object sender, EventArgs e)
        {
            SetColor("NameColor");
        }

        private void ChangeFormBackColor_Click(object sender, EventArgs e)
        {
            SetColor("FormBackColor");
        }

        private void SetColor(String Color)
        {
            // change / update colors
            int i = 0;
            ColorDialog cd = new ColorDialog();
            DialogResult dr = cd.ShowDialog();
            if (dr.ToString() == "OK")
            {
                String Name = cd.Color.Name.ToString();
                Char c = Name.ToCharArray().ElementAt(0);
                if (!Char.IsUpper(c))
                {
                    Name = "#" + Name;    
                }                
                try
                {
                    cmd = new OleDbCommand("update Colors set " + Color + " = '" + Name + "' where CompanyName = '" + CNM + "'", con);
                    cmd.ExecuteNonQuery();
                    i = 1;
                }
                catch (Exception Expn)
                {
                    MessageBox.Show(Expn.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                MessageBox.Show("Color Change Success", "Color Change", MessageBoxButtons.OK, MessageBoxIcon.Information);
                CompanySetting();
            }
        }

        private void CompanySettings_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.con.Close();
            this.Hide();
        }

        private void EditeButton_Click(object sender, EventArgs e)
        {
            // click edit button and textbox enabled true / false
            if (EditeButton.Text == "Edit")
            {
                enabletf(true);
                SaveCompanySetting.Enabled = true;
                EditeButton.Text = "Cancle";
                EditeButton.Image = Image.FromFile(Application.StartupPath+"/icons/Cancel.png");
            }
            else {
                enabletf(false);
                SaveCompanySetting.Enabled = false;
                EditeButton.Text = "Edit";
                EditeButton.Image = Image.FromFile(Application.StartupPath+"/icons/Edit.png");
                SetData();
            }
            CNM = CompanyNameTextBox.Text;
        }

        private void stockManageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.con.Close();
            this.Close();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void AvailabelStockLabel_ClientSizeChanged(object sender, EventArgs e)
        {
            AvailabelStockLabel.Left = (this.ClientSize.Width - AvailabelStockLabel.Size.Width) / 2;
        }
    }
}
