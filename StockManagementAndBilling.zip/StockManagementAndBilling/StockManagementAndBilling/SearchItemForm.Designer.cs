﻿namespace StockManagementAndBilling
{
    partial class SearchItemForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.LogoRectangle = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.SearchItemLabel = new System.Windows.Forms.Label();
            this.ItemNotFoundGroupBox = new System.Windows.Forms.GroupBox();
            this.ItemNotFoundLabel = new System.Windows.Forms.Label();
            this.SearchGroupBox = new System.Windows.Forms.GroupBox();
            this.CompanyNameLabel = new System.Windows.Forms.Label();
            this.CompanyName = new System.Windows.Forms.Label();
            this.ItemPriceLabel = new System.Windows.Forms.Label();
            this.ItemQuantityLabel = new System.Windows.Forms.Label();
            this.itemprice = new System.Windows.Forms.Label();
            this.itemquantity = new System.Windows.Forms.Label();
            this.ItemNameLabel = new System.Windows.Forms.Label();
            this.itemname = new System.Windows.Forms.Label();
            this.SearchButton = new System.Windows.Forms.Button();
            this.SearchComboBox = new System.Windows.Forms.ComboBox();
            this.SearchLabel = new System.Windows.Forms.Label();
            this.SearchItemMenu = new System.Windows.Forms.MenuStrip();
            this.stockManageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ItemNotFoundGroupBox.SuspendLayout();
            this.SearchGroupBox.SuspendLayout();
            this.SearchItemMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.LogoRectangle});
            this.shapeContainer1.Size = new System.Drawing.Size(636, 530);
            this.shapeContainer1.TabIndex = 0;
            this.shapeContainer1.TabStop = false;
            // 
            // LogoRectangle
            // 
            this.LogoRectangle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LogoRectangle.BackColor = System.Drawing.Color.Black;
            this.LogoRectangle.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.LogoRectangle.Location = new System.Drawing.Point(-8, 37);
            this.LogoRectangle.Name = "LogoRectangle";
            this.LogoRectangle.Size = new System.Drawing.Size(649, 62);
            // 
            // SearchItemLabel
            // 
            this.SearchItemLabel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.SearchItemLabel.AutoSize = true;
            this.SearchItemLabel.BackColor = System.Drawing.Color.Black;
            this.SearchItemLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchItemLabel.ForeColor = System.Drawing.Color.White;
            this.SearchItemLabel.Location = new System.Drawing.Point(108, 49);
            this.SearchItemLabel.Name = "SearchItemLabel";
            this.SearchItemLabel.Size = new System.Drawing.Size(420, 39);
            this.SearchItemLabel.TabIndex = 7;
            this.SearchItemLabel.Text = "Stock Management & Billing";
            this.SearchItemLabel.ClientSizeChanged += new System.EventHandler(this.SearchItemLabel_ClientSizeChanged);
            // 
            // ItemNotFoundGroupBox
            // 
            this.ItemNotFoundGroupBox.Controls.Add(this.ItemNotFoundLabel);
            this.ItemNotFoundGroupBox.Location = new System.Drawing.Point(78, 402);
            this.ItemNotFoundGroupBox.Name = "ItemNotFoundGroupBox";
            this.ItemNotFoundGroupBox.Size = new System.Drawing.Size(484, 94);
            this.ItemNotFoundGroupBox.TabIndex = 12;
            this.ItemNotFoundGroupBox.TabStop = false;
            this.ItemNotFoundGroupBox.Visible = false;
            // 
            // ItemNotFoundLabel
            // 
            this.ItemNotFoundLabel.AutoSize = true;
            this.ItemNotFoundLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemNotFoundLabel.ForeColor = System.Drawing.Color.Red;
            this.ItemNotFoundLabel.Location = new System.Drawing.Point(90, 26);
            this.ItemNotFoundLabel.Name = "ItemNotFoundLabel";
            this.ItemNotFoundLabel.Size = new System.Drawing.Size(294, 46);
            this.ItemNotFoundLabel.TabIndex = 0;
            this.ItemNotFoundLabel.Text = "Item Not Found";
            // 
            // SearchGroupBox
            // 
            this.SearchGroupBox.Controls.Add(this.CompanyNameLabel);
            this.SearchGroupBox.Controls.Add(this.CompanyName);
            this.SearchGroupBox.Controls.Add(this.ItemPriceLabel);
            this.SearchGroupBox.Controls.Add(this.ItemQuantityLabel);
            this.SearchGroupBox.Controls.Add(this.itemprice);
            this.SearchGroupBox.Controls.Add(this.itemquantity);
            this.SearchGroupBox.Controls.Add(this.ItemNameLabel);
            this.SearchGroupBox.Controls.Add(this.itemname);
            this.SearchGroupBox.Location = new System.Drawing.Point(78, 179);
            this.SearchGroupBox.Name = "SearchGroupBox";
            this.SearchGroupBox.Size = new System.Drawing.Size(484, 216);
            this.SearchGroupBox.TabIndex = 11;
            this.SearchGroupBox.TabStop = false;
            // 
            // CompanyNameLabel
            // 
            this.CompanyNameLabel.AutoSize = true;
            this.CompanyNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CompanyNameLabel.Location = new System.Drawing.Point(198, 168);
            this.CompanyNameLabel.Name = "CompanyNameLabel";
            this.CompanyNameLabel.Size = new System.Drawing.Size(154, 25);
            this.CompanyNameLabel.TabIndex = 1;
            this.CompanyNameLabel.Text = "Company Name";
            // 
            // CompanyName
            // 
            this.CompanyName.AutoSize = true;
            this.CompanyName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CompanyName.Location = new System.Drawing.Point(23, 168);
            this.CompanyName.Name = "CompanyName";
            this.CompanyName.Size = new System.Drawing.Size(115, 25);
            this.CompanyName.TabIndex = 2;
            this.CompanyName.Text = "Company :-";
            // 
            // ItemPriceLabel
            // 
            this.ItemPriceLabel.AutoSize = true;
            this.ItemPriceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemPriceLabel.Location = new System.Drawing.Point(198, 124);
            this.ItemPriceLabel.Name = "ItemPriceLabel";
            this.ItemPriceLabel.Size = new System.Drawing.Size(119, 25);
            this.ItemPriceLabel.TabIndex = 0;
            this.ItemPriceLabel.Text = "Price of Item";
            // 
            // ItemQuantityLabel
            // 
            this.ItemQuantityLabel.AutoSize = true;
            this.ItemQuantityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemQuantityLabel.Location = new System.Drawing.Point(198, 78);
            this.ItemQuantityLabel.Name = "ItemQuantityLabel";
            this.ItemQuantityLabel.Size = new System.Drawing.Size(148, 25);
            this.ItemQuantityLabel.TabIndex = 0;
            this.ItemQuantityLabel.Text = "Quantity of Item";
            // 
            // itemprice
            // 
            this.itemprice.AutoSize = true;
            this.itemprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemprice.Location = new System.Drawing.Point(23, 124);
            this.itemprice.Name = "itemprice";
            this.itemprice.Size = new System.Drawing.Size(116, 25);
            this.itemprice.TabIndex = 0;
            this.itemprice.Text = "Item Price :-";
            // 
            // itemquantity
            // 
            this.itemquantity.AutoSize = true;
            this.itemquantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemquantity.Location = new System.Drawing.Point(23, 78);
            this.itemquantity.Name = "itemquantity";
            this.itemquantity.Size = new System.Drawing.Size(145, 25);
            this.itemquantity.TabIndex = 0;
            this.itemquantity.Text = "Item Quantity :-";
            // 
            // ItemNameLabel
            // 
            this.ItemNameLabel.AutoSize = true;
            this.ItemNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemNameLabel.Location = new System.Drawing.Point(198, 32);
            this.ItemNameLabel.Name = "ItemNameLabel";
            this.ItemNameLabel.Size = new System.Drawing.Size(127, 25);
            this.ItemNameLabel.TabIndex = 0;
            this.ItemNameLabel.Text = "Name of Item";
            // 
            // itemname
            // 
            this.itemname.AutoSize = true;
            this.itemname.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemname.Location = new System.Drawing.Point(23, 32);
            this.itemname.Name = "itemname";
            this.itemname.Size = new System.Drawing.Size(124, 25);
            this.itemname.TabIndex = 0;
            this.itemname.Text = "Item Name :-";
            // 
            // SearchButton
            // 
            this.SearchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchButton.Location = new System.Drawing.Point(445, 129);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(117, 35);
            this.SearchButton.TabIndex = 1;
            this.SearchButton.Text = "  Search";
            this.SearchButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.SearchButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.SearchButton.UseVisualStyleBackColor = true;
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // SearchComboBox
            // 
            this.SearchComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SearchComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchComboBox.FormattingEnabled = true;
            this.SearchComboBox.Location = new System.Drawing.Point(176, 131);
            this.SearchComboBox.Name = "SearchComboBox";
            this.SearchComboBox.Size = new System.Drawing.Size(248, 28);
            this.SearchComboBox.Sorted = true;
            this.SearchComboBox.TabIndex = 0;
            this.SearchComboBox.SelectedIndexChanged += new System.EventHandler(this.SearchComboBox_SelectedIndexChanged);
            // 
            // SearchLabel
            // 
            this.SearchLabel.AutoSize = true;
            this.SearchLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchLabel.Location = new System.Drawing.Point(74, 134);
            this.SearchLabel.Name = "SearchLabel";
            this.SearchLabel.Size = new System.Drawing.Size(90, 20);
            this.SearchLabel.TabIndex = 8;
            this.SearchLabel.Text = "Select Item";
            // 
            // SearchItemMenu
            // 
            this.SearchItemMenu.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.SearchItemMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stockManageToolStripMenuItem,
            this.toolStripMenuItem1,
            this.exitToolStripMenuItem});
            this.SearchItemMenu.Location = new System.Drawing.Point(0, 0);
            this.SearchItemMenu.Name = "SearchItemMenu";
            this.SearchItemMenu.Size = new System.Drawing.Size(636, 29);
            this.SearchItemMenu.TabIndex = 13;
            this.SearchItemMenu.Text = "menuStrip1";
            // 
            // stockManageToolStripMenuItem
            // 
            this.stockManageToolStripMenuItem.Name = "stockManageToolStripMenuItem";
            this.stockManageToolStripMenuItem.Size = new System.Drawing.Size(54, 25);
            this.stockManageToolStripMenuItem.Text = "&Back";
            this.stockManageToolStripMenuItem.Click += new System.EventHandler(this.stockManageToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Enabled = false;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(26, 25);
            this.toolStripMenuItem1.Text = "|";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(46, 25);
            this.exitToolStripMenuItem.Text = "&Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // SearchItemForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(636, 530);
            this.Controls.Add(this.SearchItemMenu);
            this.Controls.Add(this.ItemNotFoundGroupBox);
            this.Controls.Add(this.SearchGroupBox);
            this.Controls.Add(this.SearchButton);
            this.Controls.Add(this.SearchComboBox);
            this.Controls.Add(this.SearchLabel);
            this.Controls.Add(this.SearchItemLabel);
            this.Controls.Add(this.shapeContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SearchItemForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Search Item";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SearchItemForm_FormClosing);
            this.Load += new System.EventHandler(this.SearchItemForm_Load);
            this.ItemNotFoundGroupBox.ResumeLayout(false);
            this.ItemNotFoundGroupBox.PerformLayout();
            this.SearchGroupBox.ResumeLayout(false);
            this.SearchGroupBox.PerformLayout();
            this.SearchItemMenu.ResumeLayout(false);
            this.SearchItemMenu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape LogoRectangle;
        private System.Windows.Forms.Label SearchItemLabel;
        private System.Windows.Forms.GroupBox ItemNotFoundGroupBox;
        private System.Windows.Forms.Label ItemNotFoundLabel;
        private System.Windows.Forms.GroupBox SearchGroupBox;
        private System.Windows.Forms.Label ItemPriceLabel;
        private System.Windows.Forms.Label ItemQuantityLabel;
        private System.Windows.Forms.Label itemprice;
        private System.Windows.Forms.Label itemquantity;
        private System.Windows.Forms.Label ItemNameLabel;
        private System.Windows.Forms.Label itemname;
        private System.Windows.Forms.Button SearchButton;
        private System.Windows.Forms.ComboBox SearchComboBox;
        private System.Windows.Forms.Label SearchLabel;
        private System.Windows.Forms.Label CompanyNameLabel;
        private System.Windows.Forms.Label CompanyName;
        private System.Windows.Forms.MenuStrip SearchItemMenu;
        private System.Windows.Forms.ToolStripMenuItem stockManageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
    }
}