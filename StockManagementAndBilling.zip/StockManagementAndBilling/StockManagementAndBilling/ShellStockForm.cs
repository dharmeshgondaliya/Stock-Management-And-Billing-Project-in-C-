﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace StockManagementAndBilling
{
    public partial class ShellStockForm : Form
    {
        OleDbConnection con;
        OleDbCommand cmd;
        OleDbDataReader reader;
        OleDbDataAdapter da;
        String query = "";
        public ShellStockForm()
        {
            InitializeComponent();
        }

        private void ShellStockForm_Load(object sender, EventArgs e)
        {
            CompanySettings();
            SearchButton.Image = Image.FromFile(Application.StartupPath+"/icons/Search.png");
            //Database Connection
            con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Application.StartupPath + "\\Database/StockManagement.accdb;Persist Security Info=False");
            con.Open();

            // Check Connection, if not then exit in Application
            if (con.State != ConnectionState.Open)
            {
                DialogResult res = MessageBox.Show("Connection fail", "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (res == DialogResult.OK)
                {
                    Application.Exit();
                }
            }
            //DateTime.Now.ToShortDateString();
            setdata();
            SelectItemComboBox.SelectedItem = "All";
            SelectCompanyComboBox.SelectedItem = "All";
            PaymentTypeComboBox.SelectedItem = "All";
            SelectDate.Text = "1/1/2000";
            this.WindowState = FormWindowState.Maximized;
        }

        private void CompanySettings()
        {
            // set company name and set color
            CompanyClass Company = new CompanyClass();
            ShellStockLabel.Text = Company.CompanyName.ToString();
            // logo color
            ShellStockLabel.ForeColor = System.Drawing.ColorTranslator.FromHtml(Company.NameColor.ToString());
            ShellStockLabel.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.NameBackColor.ToString());
            LogoRectangle.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.NameBackColor.ToString());
            // form back color
            this.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.FormBackColor.ToString());
        }

        private void setdata()
        { 
           // set data in combobox
            SelectItemComboBox.Items.Clear();
            SelectCompanyComboBox.Items.Clear();
            SelectItemComboBox.Items.Add("All");
            SelectCompanyComboBox.Items.Add("All");
            try{
                cmd = new OleDbCommand("select Distinct iName from Stock",con);
                reader = cmd.ExecuteReader();
                // set item name
                while(reader.Read()){
                    SelectItemComboBox.Items.Add(reader["iName"].ToString());
                }
                cmd = new OleDbCommand("select Distinct cName from Stock", con);
                reader = cmd.ExecuteReader();
                // set company name
                while(reader.Read()){
                    SelectCompanyComboBox.Items.Add(reader["cName"].ToString());
                }
            }
            catch(Exception ex){
               MessageBox.Show(ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
               return;
            }
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            try
            {
                //
                if ((SelectItemComboBox.SelectedIndex == -1 || SelectItemComboBox.SelectedItem.ToString() == "All") && (SelectCompanyComboBox.SelectedIndex == -1 || SelectCompanyComboBox.SelectedItem.ToString() == "All") && (PaymentTypeComboBox.SelectedIndex == -1 || PaymentTypeComboBox.SelectedItem.ToString() == "All") && (CoustomerNameTextBox.Text.Trim() == "") && (SelectDate.Text == "1/1/2000"))
                {
                    // Non - Select
                    query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo";
                    ShowOrderInfoGridView(query);
                    return;
                }
                //
                if ((SelectItemComboBox.SelectedIndex != -1 || SelectItemComboBox.SelectedItem.ToString() != "All") && (SelectCompanyComboBox.SelectedIndex == -1 || SelectCompanyComboBox.SelectedItem.ToString() == "All") && (PaymentTypeComboBox.SelectedIndex == -1 || PaymentTypeComboBox.SelectedItem.ToString() == "All") && (CoustomerNameTextBox.Text.Trim() == "") && (SelectDate.Text == "1/1/2000"))
                {
                    // Select Item
                    if (SelectItemComboBox.SelectedItem.ToString() == "All")
                    {
                        query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo";
                    }
                    else
                    {
                        query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo,OrderItems where OrderInfo.OrderNumber = OrderItems.OrderNumbers AND OrderItems.ItemName='" + SelectItemComboBox.SelectedItem.ToString() + "'";
                    }
                    ShowOrderInfoGridView(query);
                    return;
                }
                //
                if ((SelectItemComboBox.SelectedIndex == -1 || SelectItemComboBox.SelectedItem.ToString() == "All") && (SelectCompanyComboBox.SelectedIndex == -1 || SelectCompanyComboBox.SelectedItem.ToString() == "All") && (PaymentTypeComboBox.SelectedIndex == -1 || PaymentTypeComboBox.SelectedItem.ToString() == "All") && (CoustomerNameTextBox.Text.Trim() == "") && (SelectDate.Text != "1/1/2000"))
                {
                    // Select Date
                    query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo where TransactionDate = #" + SelectDate.Text + "#";
                    ShowOrderInfoGridView(query);
                    return;
                }
                //
                if ((SelectItemComboBox.SelectedIndex == -1 || SelectItemComboBox.SelectedItem.ToString() == "All") && (SelectCompanyComboBox.SelectedIndex == -1 || SelectCompanyComboBox.SelectedItem.ToString() == "All") && (PaymentTypeComboBox.SelectedIndex == -1 || PaymentTypeComboBox.SelectedItem.ToString() == "All") && (CoustomerNameTextBox.Text.Trim() != "") && (SelectDate.Text != "1/1/2000"))
                {
                    // Select Coustomer & Date
                    query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo where CoustomerName = '" + CoustomerNameTextBox.Text.Trim() + "' AND TransactionDate = #" + SelectDate.Text + "#";
                    ShowOrderInfoGridView(query);
                    return;
                }
                //
                if ((SelectItemComboBox.SelectedIndex == -1 || SelectItemComboBox.SelectedItem.ToString() == "All") && (SelectCompanyComboBox.SelectedIndex == -1 || SelectCompanyComboBox.SelectedItem.ToString() == "All") && (PaymentTypeComboBox.SelectedIndex == -1 || PaymentTypeComboBox.SelectedItem.ToString() == "All") && (CoustomerNameTextBox.Text.Trim() != "") && (SelectDate.Text == "1/1/2000"))
                {
                    if ((SelectItemComboBox.SelectedIndex == -1 || SelectItemComboBox.SelectedItem.ToString() == "All") && (SelectCompanyComboBox.SelectedIndex == -1 || SelectCompanyComboBox.SelectedItem.ToString() == "All") && (PaymentTypeComboBox.SelectedIndex != -1 || PaymentTypeComboBox.SelectedItem.ToString() != "All") && (CoustomerNameTextBox.Text.Trim() == "") && (SelectDate.Text == "1/1/2000"))
                    {
                        // Select Payment
                        if (PaymentTypeComboBox.SelectedItem.ToString() == "All")
                        {
                            query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo";
                        }
                        else
                        {
                            query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo where PaymentType = '" + PaymentTypeComboBox.SelectedItem.ToString() + "'";
                        }
                        ShowOrderInfoGridView(query);
                        return;
                    }
                    //
                    if ((SelectItemComboBox.SelectedIndex == -1 || SelectItemComboBox.SelectedItem.ToString() == "All") && (SelectCompanyComboBox.SelectedIndex == -1 || SelectCompanyComboBox.SelectedItem.ToString() == "All") && (PaymentTypeComboBox.SelectedIndex != -1 || PaymentTypeComboBox.SelectedItem.ToString() != "All") && (CoustomerNameTextBox.Text.Trim() == "") && (SelectDate.Text != "1/1/2000"))
                    {
                        // Select Payment & Date
                        query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo where PaymentType = '" + PaymentTypeComboBox.SelectedItem.ToString() + "' AND TransactionDate = #" + SelectDate.Text + "#";
                        ShowOrderInfoGridView(query);
                        return;
                    }
                    //
                    if ((SelectItemComboBox.SelectedIndex == -1 || SelectItemComboBox.SelectedItem.ToString() == "All") && (SelectCompanyComboBox.SelectedIndex == -1 || SelectCompanyComboBox.SelectedItem.ToString() == "All") && (PaymentTypeComboBox.SelectedIndex != -1 || PaymentTypeComboBox.SelectedItem.ToString() != "All") && (CoustomerNameTextBox.Text.Trim() != "") && (SelectDate.Text == "1/1/2000"))
                    {
                        // Select Payment & Coustomer
                        query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo where PaymentType = '" + PaymentTypeComboBox.SelectedItem.ToString() + "' And CoustomerName = '" + CoustomerNameTextBox.Text.Trim() + "'";
                        ShowOrderInfoGridView(query);
                        return;
                    }
                    //
                    if ((SelectItemComboBox.SelectedIndex == -1 || SelectItemComboBox.SelectedItem.ToString() == "All") && (SelectCompanyComboBox.SelectedIndex == -1 || SelectCompanyComboBox.SelectedItem.ToString() == "All") && (PaymentTypeComboBox.SelectedIndex != -1 || PaymentTypeComboBox.SelectedItem.ToString() != "All") && (CoustomerNameTextBox.Text.Trim() != "") && (SelectDate.Text != "1/1/2000"))
                    {
                        // Select Payment & Coustomer & Date
                        query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo where PaymentType = '" + PaymentTypeComboBox.SelectedItem.ToString() + "' AND CoustomerName = '" + CoustomerNameTextBox.Text.Trim() + "' AND TransactionDate = #" + SelectDate.Text + "#";
                        ShowOrderInfoGridView(query);
                        return;
                    }
                    //
                    query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo where CoustomerName = '" + CoustomerNameTextBox.Text.Trim() + "'";
                    ShowOrderInfoGridView(query);
                    return;
                }
                //
                if ((SelectItemComboBox.SelectedIndex == -1 || SelectItemComboBox.SelectedItem.ToString() == "All") && (SelectCompanyComboBox.SelectedIndex != -1 || SelectCompanyComboBox.SelectedItem.ToString() != "All") && (PaymentTypeComboBox.SelectedIndex == -1 || PaymentTypeComboBox.SelectedItem.ToString() == "All") && (CoustomerNameTextBox.Text.Trim() == "") && (SelectDate.Text == "1/1/2000"))
                {
                    // Select Company
                    if (SelectCompanyComboBox.SelectedItem.ToString() == "All")
                    {
                        query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo";
                    }
                    else
                    {
                        query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo,OrderItems where OrderInfo.OrderNumber = OrderItems.OrderNumbers AND OrderItems.Company ='" + SelectCompanyComboBox.SelectedItem.ToString() + "'";
                    }
                    ShowOrderInfoGridView(query);
                    return;
                }
                //
                if ((SelectItemComboBox.SelectedIndex == -1 || SelectItemComboBox.SelectedItem.ToString() == "All") && (SelectCompanyComboBox.SelectedIndex != -1 || SelectCompanyComboBox.SelectedItem.ToString() != "All") && (PaymentTypeComboBox.SelectedIndex != -1 || PaymentTypeComboBox.SelectedItem.ToString() != "All") && (CoustomerNameTextBox.Text.Trim() == "") && (SelectDate.Text == "1/1/2000"))
                {
                    // Select Company & Payment
                    query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo,OrderItems where OrderInfo.OrderNumber = OrderItems.OrderNumbers AND OrderItems.Company ='" + SelectCompanyComboBox.SelectedItem.ToString() + "' AND OrderInfo.PaymentType = '" + PaymentTypeComboBox.SelectedItem.ToString() + "'";
                    ShowOrderInfoGridView(query);
                    return;
                }
                //
                if ((SelectItemComboBox.SelectedIndex == -1 || SelectItemComboBox.SelectedItem.ToString() == "All") && (SelectCompanyComboBox.SelectedIndex != -1 || SelectCompanyComboBox.SelectedItem.ToString() != "All") && (PaymentTypeComboBox.SelectedIndex == -1 || PaymentTypeComboBox.SelectedItem.ToString() == "All") && (CoustomerNameTextBox.Text.Trim() == "") && (SelectDate.Text != "1/1/2000"))
                {
                    // Select Company & Date
                    query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay]  from OrderInfo,OrderItems where OrderInfo.OrderNumber = OrderItems.OrderNumbers AND OrderItems.Company ='" + SelectCompanyComboBox.SelectedItem.ToString() + "' AND OrderInfo.TransactionDate = #" + SelectDate.Text + "#";
                    ShowOrderInfoGridView(query);
                    return;
                }
                //
                if ((SelectItemComboBox.SelectedIndex == -1 || SelectItemComboBox.SelectedItem.ToString() == "All") && (SelectCompanyComboBox.SelectedIndex != -1 || SelectCompanyComboBox.SelectedItem.ToString() != "All") && (PaymentTypeComboBox.SelectedIndex == -1 || PaymentTypeComboBox.SelectedItem.ToString() == "All") && (CoustomerNameTextBox.Text.Trim() != "") && (SelectDate.Text == "1/1/2000"))
                {
                    // Select Company & Coustomer
                    query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo,OrderItems where OrderInfo.OrderNumber = OrderItems.OrderNumbers AND OrderItems.Company ='" + SelectCompanyComboBox.SelectedItem.ToString() + "' AND OrderInfo.CoustomerName = '" + CoustomerNameTextBox.Text.Trim() + "'";
                    ShowOrderInfoGridView(query);
                    return;
                }
                //

                if ((SelectItemComboBox.SelectedIndex == -1 || SelectItemComboBox.SelectedItem.ToString() == "All") && (SelectCompanyComboBox.SelectedIndex != -1 || SelectCompanyComboBox.SelectedItem.ToString() != "All") && (PaymentTypeComboBox.SelectedIndex != -1 || PaymentTypeComboBox.SelectedItem.ToString() != "All") && (CoustomerNameTextBox.Text.Trim() != "") && (SelectDate.Text == "1/1/2000"))
                {
                    // Select Company & Payment & Coustomer
                    query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo,OrderItems where OrderInfo.OrderNumber = OrderItems.OrderNumbers AND OrderItems.Company ='" + SelectCompanyComboBox.SelectedItem.ToString() + "' AND OrderInfo.PaymentType = '" + PaymentTypeComboBox.SelectedItem.ToString() + "' AND OrderInfo.CoustomerName = '" + CoustomerNameTextBox.Text.Trim() + "'";
                    ShowOrderInfoGridView(query);
                    return;
                }
                //
                if ((SelectItemComboBox.SelectedIndex == -1 || SelectItemComboBox.SelectedItem.ToString() == "All") && (SelectCompanyComboBox.SelectedIndex != -1 || SelectCompanyComboBox.SelectedItem.ToString() != "All") && (PaymentTypeComboBox.SelectedIndex != -1 || PaymentTypeComboBox.SelectedItem.ToString() != "All") && (CoustomerNameTextBox.Text.Trim() == "") && (SelectDate.Text != "1/1/2000"))
                {
                    // Select Company & Payment & Date
                    query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo,OrderItems where OrderInfo.OrderNumber = OrderItems.OrderNumbers AND OrderItems.Company ='" + SelectCompanyComboBox.SelectedItem.ToString() + "' AND OrderInfo.PaymentType = '" + PaymentTypeComboBox.SelectedItem.ToString() + "' AND OrderInfo.TransactionDate = #" + SelectDate.Text + "#";
                    ShowOrderInfoGridView(query);
                    return;
                }
                //
                if ((SelectItemComboBox.SelectedIndex == -1 || SelectItemComboBox.SelectedItem.ToString() == "All") && (SelectCompanyComboBox.SelectedIndex != -1 || SelectCompanyComboBox.SelectedItem.ToString() != "All") && (PaymentTypeComboBox.SelectedIndex == -1 || PaymentTypeComboBox.SelectedItem.ToString() == "All") && (CoustomerNameTextBox.Text.Trim() != "") && (SelectDate.Text != "1/1/2000"))
                {
                    // Select Company & Coustomer & Date
                    query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo,OrderItems where OrderInfo.OrderNumber = OrderItems.OrderNumbers AND OrderItems.Company ='" + SelectCompanyComboBox.SelectedItem.ToString() + "' AND OrderInfo.CoustomerName = '" + CoustomerNameTextBox.Text.Trim() + "' AND OrderInfo.TransactionDate = #" + SelectDate.Text + "#";
                    ShowOrderInfoGridView(query);
                    return;
                }
                //
                if ((SelectItemComboBox.SelectedIndex == -1 || SelectItemComboBox.SelectedItem.ToString() == "All") && (SelectCompanyComboBox.SelectedIndex != -1 || SelectCompanyComboBox.SelectedItem.ToString() != "All") && (PaymentTypeComboBox.SelectedIndex != -1 || PaymentTypeComboBox.SelectedItem.ToString() != "All") && (CoustomerNameTextBox.Text.Trim() != "") && (SelectDate.Text != "1/1/2000"))
                {
                    // Select Company & Payment & Coustomer & Date
                    query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo,OrderItems where OrderInfo.OrderNumber = OrderItems.OrderNumbers AND OrderItems.Company ='" + SelectCompanyComboBox.SelectedItem.ToString() + "' AND OrderInfo.PaymentType = '" + PaymentTypeComboBox.SelectedItem.ToString() + "' AND OrderInfo.CoustomerName = '" + CoustomerNameTextBox.Text.Trim() + "' AND OrderInfo.TransactionDate = #" + SelectDate.Text + "#";
                    ShowOrderInfoGridView(query);
                    return;
                }
                //
                if ((SelectItemComboBox.SelectedIndex != -1 || SelectItemComboBox.SelectedItem.ToString() != "All") && (SelectCompanyComboBox.SelectedIndex != -1 || SelectCompanyComboBox.SelectedItem.ToString() != "All") && (PaymentTypeComboBox.SelectedIndex == -1 || PaymentTypeComboBox.SelectedItem.ToString() == "All") && (CoustomerNameTextBox.Text.Trim() == "") && (SelectDate.Text == "1/1/2000"))
                {
                    // Select Item & Company
                    query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo,OrderItems where OrderInfo.OrderNumber = OrderItems.OrderNumbers AND OrderItems.ItemName='" + SelectItemComboBox.SelectedItem.ToString() + "' AND OrderItems.Company = '" + SelectCompanyComboBox.SelectedItem.ToString() + "'";
                    ShowOrderInfoGridView(query);
                    return;
                }
                //
                if ((SelectItemComboBox.SelectedIndex != -1 || SelectItemComboBox.SelectedItem.ToString() != "All") && (SelectCompanyComboBox.SelectedIndex == -1 || SelectCompanyComboBox.SelectedItem.ToString() == "All") && (PaymentTypeComboBox.SelectedIndex != -1 || PaymentTypeComboBox.SelectedItem.ToString() != "All") && (CoustomerNameTextBox.Text.Trim() == "") && (SelectDate.Text == "1/1/2000"))
                {
                    // Select Item & PaymentType
                    query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo,OrderItems where OrderInfo.OrderNumber = OrderItems.OrderNumbers AND OrderItems.ItemName='" + SelectItemComboBox.SelectedItem.ToString() + "' AND OrderInfo.PaymentType = '" + PaymentTypeComboBox.SelectedItem.ToString() + "'";
                    ShowOrderInfoGridView(query);
                    return;
                }
                //
                if ((SelectItemComboBox.SelectedIndex != -1 || SelectItemComboBox.SelectedItem.ToString() != "All") && (SelectCompanyComboBox.SelectedIndex == -1 || SelectCompanyComboBox.SelectedItem.ToString() == "All") && (PaymentTypeComboBox.SelectedIndex == -1 || PaymentTypeComboBox.SelectedItem.ToString() == "All") && (CoustomerNameTextBox.Text.Trim() == "") && (SelectDate.Text != "1/1/2000"))
                {
                    // Select  Item & Date
                    query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo,OrderItems where OrderInfo.OrderNumber = OrderItems.OrderNumbers AND OrderItems.ItemName='" + SelectItemComboBox.SelectedItem.ToString() + "' AND OrderInfo.TransactionDate = #" + SelectDate.Text + "#";
                    ShowOrderInfoGridView(query);
                    return;
                }
                //
                if ((SelectItemComboBox.SelectedIndex != -1 || SelectItemComboBox.SelectedItem.ToString() != "All") && (SelectCompanyComboBox.SelectedIndex == -1 || SelectCompanyComboBox.SelectedItem.ToString() == "All") && (PaymentTypeComboBox.SelectedIndex == -1 || PaymentTypeComboBox.SelectedItem.ToString() == "All") && (CoustomerNameTextBox.Text.Trim() != "") && (SelectDate.Text == "1/1/2000"))
                {
                    // Select Item & Coustomer Name
                    query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo,OrderItems where OrderInfo.OrderNumber = OrderItems.OrderNumbers AND OrderItems.ItemName='" + SelectItemComboBox.SelectedItem.ToString() + "' AND OrderInfo.CoustomerName = '" + CoustomerNameTextBox.Text.Trim() + "'";
                    ShowOrderInfoGridView(query);
                    return;
                }
                //
                if ((SelectItemComboBox.SelectedIndex != -1 || SelectItemComboBox.SelectedItem.ToString() != "All") && (SelectCompanyComboBox.SelectedIndex != -1 || SelectCompanyComboBox.SelectedItem.ToString() != "All") && (PaymentTypeComboBox.SelectedIndex != -1 || PaymentTypeComboBox.SelectedItem.ToString() != "All") && (CoustomerNameTextBox.Text.Trim() == "") && (SelectDate.Text == "1/1/2000"))
                {
                    // Select Item & Company & Payment
                    query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo,OrderItems where OrderInfo.OrderNumber = OrderItems.OrderNumbers AND OrderItems.ItemName='" + SelectItemComboBox.SelectedItem.ToString() + "' AND OrderItems.Company = '" + SelectCompanyComboBox.SelectedItem.ToString() + "' AND OrderInfo.PaymentType = '" + PaymentTypeComboBox.SelectedItem.ToString() + "'";
                    ShowOrderInfoGridView(query);
                    return;
                }
                if ((SelectItemComboBox.SelectedIndex != -1 || SelectItemComboBox.SelectedItem.ToString() != "All") && (SelectCompanyComboBox.SelectedIndex != -1 || SelectCompanyComboBox.SelectedItem.ToString() != "All") && (PaymentTypeComboBox.SelectedIndex == -1 || PaymentTypeComboBox.SelectedItem.ToString() == "All") && (CoustomerNameTextBox.Text.Trim() == "") && (SelectDate.Text != "1/1/2000"))
                {
                    // Select Item & Company & Date
                    query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo,OrderItems where OrderInfo.OrderNumber = OrderItems.OrderNumbers AND OrderItems.ItemName='" + SelectItemComboBox.SelectedItem.ToString() + "' AND OrderItems.Company = '" + SelectCompanyComboBox.SelectedItem.ToString() + "' AND OrderInfo.TransactionDate = #" + SelectDate.Text + "#";
                    ShowOrderInfoGridView(query);
                    return;
                }
                //
                if ((SelectItemComboBox.SelectedIndex != -1 || SelectItemComboBox.SelectedItem.ToString() != "All") && (SelectCompanyComboBox.SelectedIndex != -1 || SelectCompanyComboBox.SelectedItem.ToString() != "All") && (PaymentTypeComboBox.SelectedIndex == -1 || PaymentTypeComboBox.SelectedItem.ToString() == "All") && (CoustomerNameTextBox.Text.Trim() != "") && (SelectDate.Text == "1/1/2000"))
                {
                    // Select Item & Company & Coustomer
                    query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo,OrderItems where OrderInfo.OrderNumber = OrderItems.OrderNumbers AND OrderItems.ItemName='" + SelectItemComboBox.SelectedItem.ToString() + "' AND OrderItems.Company = '" + SelectCompanyComboBox.SelectedItem.ToString() + "' AND OrderInfo.CoustomerName = '" + CoustomerNameTextBox.Text.Trim() + "'";
                    ShowOrderInfoGridView(query);
                    return;
                }
                //
                if ((SelectItemComboBox.SelectedIndex != -1 || SelectItemComboBox.SelectedItem.ToString() != "All") && (SelectCompanyComboBox.SelectedIndex == -1 || SelectCompanyComboBox.SelectedItem.ToString() == "All") && (PaymentTypeComboBox.SelectedIndex != -1 || PaymentTypeComboBox.SelectedItem.ToString() != "All") && (CoustomerNameTextBox.Text.Trim() == "") && (SelectDate.Text != "1/1/2000"))
                {
                    // Select Item & Payment & Date
                    query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo,OrderItems where OrderInfo.OrderNumber = OrderItems.OrderNumbers AND OrderItems.ItemName='" + SelectItemComboBox.SelectedItem.ToString() + "'AND OrderInfo.PaymentType = '" + PaymentTypeComboBox.SelectedItem.ToString() + "' AND OrderInfo.TransactionDate = #" + SelectDate.Text + "#";
                    ShowOrderInfoGridView(query);
                    return;
                }
                //
                if ((SelectItemComboBox.SelectedIndex != -1 || SelectItemComboBox.SelectedItem.ToString() != "All") && (SelectCompanyComboBox.SelectedIndex == -1 || SelectCompanyComboBox.SelectedItem.ToString() == "All") && (PaymentTypeComboBox.SelectedIndex != -1 || PaymentTypeComboBox.SelectedItem.ToString() != "All") && (CoustomerNameTextBox.Text.Trim() != "") && (SelectDate.Text == "1/1/2000"))
                {
                    // Select Item & Payment & Coustomer
                    query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo,OrderItems where OrderInfo.OrderNumber = OrderItems.OrderNumbers AND OrderItems.ItemName='" + SelectItemComboBox.SelectedItem.ToString() + "' AND OrderInfo.PaymentType = '" + PaymentTypeComboBox.SelectedItem.ToString() + "' AND OrderInfo.CoustomerName = '" + CoustomerNameTextBox.Text.Trim() + "'";
                    ShowOrderInfoGridView(query);
                    return;
                }
                if ((SelectItemComboBox.SelectedIndex != -1 || SelectItemComboBox.SelectedItem.ToString() != "All") && (SelectCompanyComboBox.SelectedIndex == -1 || SelectCompanyComboBox.SelectedItem.ToString() == "All") && (PaymentTypeComboBox.SelectedIndex == -1 || PaymentTypeComboBox.SelectedItem.ToString() == "All") && (CoustomerNameTextBox.Text.Trim() != "") && (SelectDate.Text != "1/1/2000"))
                {
                    // Select Item & Coustomer & Date
                    query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo,OrderItems where OrderInfo.OrderNumber = OrderItems.OrderNumbers AND OrderItems.ItemName='" + SelectItemComboBox.SelectedItem.ToString() + "'AND OrderInfo.CoustomerName = '" + CoustomerNameTextBox.Text.Trim() + "' AND OrderInfo.TransactionDate = #" + SelectDate.Text + "#";
                    ShowOrderInfoGridView(query);
                    return;
                }
                //
                if ((SelectItemComboBox.SelectedIndex != -1 || SelectItemComboBox.SelectedItem.ToString() != "All") && (SelectCompanyComboBox.SelectedIndex != -1 || SelectCompanyComboBox.SelectedItem.ToString() != "All") && (PaymentTypeComboBox.SelectedIndex != -1 || PaymentTypeComboBox.SelectedItem.ToString() != "All") && (CoustomerNameTextBox.Text.Trim() == "") && (SelectDate.Text != "1/1/2000"))
                {
                    // Select Item & Company & Payment & Date
                    query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo,OrderItems where OrderInfo.OrderNumber = OrderItems.OrderNumbers AND OrderItems.ItemName='" + SelectItemComboBox.SelectedItem.ToString() + "' AND OrderItems.Company = '" + SelectCompanyComboBox.SelectedItem.ToString() + "' AND OrderInfo.PaymentType = '" + PaymentTypeComboBox.SelectedItem.ToString() + "' AND OrderInfo.TransactionDate = #" + SelectDate.Text + "#";
                    ShowOrderInfoGridView(query);
                    return;
                }
                //
                if ((SelectItemComboBox.SelectedIndex != -1 || SelectItemComboBox.SelectedItem.ToString() != "All") && (SelectCompanyComboBox.SelectedIndex != -1 || SelectCompanyComboBox.SelectedItem.ToString() != "All") && (PaymentTypeComboBox.SelectedIndex != -1 || PaymentTypeComboBox.SelectedItem.ToString() != "All") && (CoustomerNameTextBox.Text.Trim() != "") && (SelectDate.Text == "1/1/2000"))
                {
                    // Select Item & Company & Payment & Coustomer
                    query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo,OrderItems where OrderInfo.OrderNumber = OrderItems.OrderNumbers AND OrderItems.ItemName='" + SelectItemComboBox.SelectedItem.ToString() + "' AND OrderItems.Company = '" + SelectCompanyComboBox.SelectedItem.ToString() + "' AND OrderInfo.PaymentType = '" + PaymentTypeComboBox.SelectedItem.ToString() + "' AND OrderInfo.CoustomerName = '" + CoustomerNameTextBox.Text.Trim() + "'";
                    ShowOrderInfoGridView(query);
                    return;
                }
                //
                if ((SelectItemComboBox.SelectedIndex != -1 || SelectItemComboBox.SelectedItem.ToString() != "All") && (SelectCompanyComboBox.SelectedIndex != -1 || SelectCompanyComboBox.SelectedItem.ToString() != "All") && (PaymentTypeComboBox.SelectedIndex == -1 || PaymentTypeComboBox.SelectedItem.ToString() == "All") && (CoustomerNameTextBox.Text.Trim() != "") && (SelectDate.Text != "1/1/2000"))
                {
                    // Select Item & Company & Coustomer & Date
                    query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo,OrderItems where OrderInfo.OrderNumber = OrderItems.OrderNumbers AND OrderItems.ItemName='" + SelectItemComboBox.SelectedItem.ToString() + "' AND OrderItems.Company = '" + SelectCompanyComboBox.SelectedItem.ToString() + "' AND OrderInfo.CoustomerName = '" + CoustomerNameTextBox.Text.Trim() + "' AND OrderInfo.TransactionDate = #" + SelectDate.Text + "#";
                    ShowOrderInfoGridView(query);
                    return;
                }
                //
                if ((SelectItemComboBox.SelectedIndex != -1 || SelectItemComboBox.SelectedItem.ToString() != "All") && (SelectCompanyComboBox.SelectedIndex == -1 || SelectCompanyComboBox.SelectedItem.ToString() == "All") && (PaymentTypeComboBox.SelectedIndex != -1 || PaymentTypeComboBox.SelectedItem.ToString() != "All") && (CoustomerNameTextBox.Text.Trim() != "") && (SelectDate.Text != "1/1/2000"))
                {
                    // Select Item & Payment & Coustomer & Date
                    query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo,OrderItems where OrderInfo.OrderNumber = OrderItems.OrderNumbers AND OrderItems.ItemName='" + SelectItemComboBox.SelectedItem.ToString() + "' AND OrderInfo.PaymentType = '" + PaymentTypeComboBox.SelectedItem.ToString() + "' AND OrderInfo.CoustomerName = '" + CoustomerNameTextBox.Text.Trim() + "' AND OrderInfo.TransactionDate = #" + SelectDate.Text + "#";
                    ShowOrderInfoGridView(query);
                    return;
                }
                //
                if ((SelectItemComboBox.SelectedIndex != -1 || SelectItemComboBox.SelectedItem.ToString() != "All") && (SelectCompanyComboBox.SelectedIndex != -1 || SelectCompanyComboBox.SelectedItem.ToString() != "All") && (PaymentTypeComboBox.SelectedIndex != -1 || PaymentTypeComboBox.SelectedItem.ToString() != "All") && (CoustomerNameTextBox.Text.Trim() != "") && (SelectDate.Text != "1/1/2000"))
                {
                    // Select Item & Company & Payment & Coustomer & Date
                    query = "select OrderNumber AS [Order Number],CoustomerName AS [Customer Name],TransactionDate AS [Transaction Date],PaymentType AS [Payment Type],CGST,SGST,Discount,TotalAmount AS [Total Amount],TotalGst AS [Total GST],TotalToPay AS [Total To Pay] from OrderInfo,OrderItems where OrderInfo.OrderNumber = OrderItems.OrderNumbers AND OrderItems.ItemName='" + SelectItemComboBox.SelectedItem.ToString() + "' AND OrderItems.Company = '" + SelectCompanyComboBox.SelectedItem.ToString() + "' AND OrderInfo.PaymentType = '" + PaymentTypeComboBox.SelectedItem.ToString() + "' AND OrderInfo.CoustomerName = '" + CoustomerNameTextBox.Text.Trim() + "' AND OrderInfo.TransactionDate = #" + SelectDate.Text + "#";
                    ShowOrderInfoGridView(query);
                    return;
                }
                //                
            }
            catch (Exception excp)
            {
                MessageBox.Show(excp.ToString());
                return;
            }
        }

        private void ShowOrderInfoGridView(String query)
        {
            // show order data in datagridview
            CoustomerItemGridView.DataSource = null;
            try
            {
                cmd = con.CreateCommand();
                cmd.CommandText = query;
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                da = new OleDbDataAdapter(cmd);
                da.Fill(dt);
                CoustomerDataGridView.DataSource = dt;
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void CoustomerDataGridView_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            // click datagridview row and show items datagridview data
            try {
                Convert.ToInt16(CoustomerDataGridView.CurrentCell.RowIndex);
            }
            catch(Exception epn){
                return;
            }
            int index = Convert.ToInt16(CoustomerDataGridView.CurrentCell.RowIndex);
            String OrderNumber = CoustomerDataGridView.Rows[index].Cells[0].Value.ToString();
            try{
                cmd = con.CreateCommand();
                cmd.CommandText = "select OrderNumbers AS [Order Number],ItemName AS [Item Name],Quantity,UnitPrice AS [Unit Price],TotalPrice AS [Total Price],Company from OrderItems where OrderNumbers = '" + OrderNumber + "'";
                cmd.ExecuteNonQuery();
                DataTable dtbl = new DataTable();
                da = new OleDbDataAdapter(cmd);
                da.Fill(dtbl);
                CoustomerItemGridView.DataSource = dtbl;
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void CoustomerDataGridView_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            CoustomerItemGridView.DataSource = null;
        }
        private void DeleteMenuData()
        {
            // delete data for order when click delete toolstrip menu
            CoustomerItemGridView.DataSource = null;
            // select row
            int index = CoustomerDataGridView.CurrentCell.RowIndex;
            String Name = CoustomerDataGridView.Rows[index].Cells[0].Value.ToString();
            try {
                cmd = new OleDbCommand("delete from OrderInfo where OrderInfo.OrderNumber = '"+Name+"'",con);
                cmd.ExecuteNonQuery();
                cmd = new OleDbCommand("delete from OrderItems where OrderNumbers = '"+Name+"'",con);
                cmd.ExecuteNonQuery();
                ShowOrderInfoGridView(query);
            }
            catch(Exception exp){
                MessageBox.Show(exp.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }
        }

        private void CoustomerDataGridView_MouseDown(object sender, MouseEventArgs e)
        {
            // mouse down row select == true
            try
            {
                if (CoustomerDataGridView.RowCount != 0)
                {
                    if (e.Button == System.Windows.Forms.MouseButtons.Right)
                    {
                        var ht = CoustomerDataGridView.HitTest(e.X, e.Y);
                        CoustomerDataGridView.Rows[ht.RowIndex].Selected = true;
                        ContextMenuStrip.Show(CoustomerDataGridView, e.X, e.Y);
                    }
                }
            }
            catch(Exception ex){
                MessageBox.Show("Select Proper Row","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void ShellStockForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.con.Close();
            this.Hide();
        }

        private void stockManageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.con.Close();
            this.Close();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ShellStockLabel_ClientSizeChanged(object sender, EventArgs e)
        {
            ShellStockLabel.Left = (this.ClientSize.Width - ShellStockLabel.Size.Width) / 2;
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteMenuData();
        }
    }
}
