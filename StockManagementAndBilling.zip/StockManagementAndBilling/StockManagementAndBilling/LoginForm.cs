﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace StockManagementAndBilling
{
    public partial class LoginForm : Form
    {
        OleDbConnection con;
        OleDbCommand cmd;
        OleDbDataReader reader;
        public LoginForm()
        {
            InitializeComponent();
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
            CompanyClass Company = new CompanyClass();
            LoginLogoLabel.Text = Company.CompanyName.ToString();
            LoginLogoLabel.ForeColor = System.Drawing.ColorTranslator.FromHtml(Company.NameColor.ToString());
            LoginLogoLabel.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.FormBackColor.ToString());
            this.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.FormBackColor.ToString());
            // Database Connection
            con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Application.StartupPath + "\\Database/StockManagement.accdb;Persist Security Info=False");
            con.Open();

            // Check Connection, if not then exit in Application
            if (con.State != ConnectionState.Open)
            {
                DialogResult res = MessageBox.Show("Connection fail", "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (res == DialogResult.OK)
                {
                    Application.Exit();
                }
            }

            // Set Icons
            UserIdPictureBox.Image = Image.FromFile(Application.StartupPath+"/icons/UserId.png");
            PasswordPictureBox.Image = Image.FromFile(Application.StartupPath+"/icons/Password.png");
            LoginButton.Image = Image.FromFile(Application.StartupPath+"/icons/Login.png");
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            // validation of login form
            if(UserIdTextBox.Text.Trim() == ""){
                MessageBox.Show("Please Enter User Id");
                return;
            }
            if(PasswordTextbox.Text.Trim() == ""){
                MessageBox.Show("Please Enter Password");
                return;
            }
            if(UserComboBox.SelectedIndex == -1){
                MessageBox.Show("Please Select User Type");
                return;
            }
            CheckLogin();
        }

        private void CheckLogin()
        {
            // check user and redirect proper form
            String uid = UserIdTextBox.Text.Trim();
            String ps = PasswordTextbox.Text.Trim();
            String ut = UserComboBox.SelectedItem.ToString();

            try {
                cmd = new OleDbCommand("select Name,UserId,Pass,Utype from Login where UserId='"+uid+"'",con);
                reader = cmd.ExecuteReader();
                reader.Read();

                String Name = reader["Name"].ToString();
                String ruid = reader["UserId"].ToString();
                String rps = reader["Pass"].ToString();
                String rut = reader["Utype"].ToString();
                if (uid == ruid && ps == rps)
                {
                    if(ut == "Admin" && rut == "Admin"){
                        UserClass.UserName = Name;
                        DashboardForm DF = new DashboardForm();
                        this.Hide();
                        DF.Show();
                    }
                    if (ut == "User" && rut == "User")
                    {
                        UserClass.UserName = Name;
                        OrderForm OF = new OrderForm();
                        OF.Show();
                        this.Hide();
                    }
                    if(ut == "User" && rut == "Admin"){
                        UserClass.UserName = Name;
                        OrderForm OF = new OrderForm();
                        OF.Show();
                        this.Hide();
                    }
                    if(ut == "Admin" && rut == "User"){
                        MessageBox.Show("Please Select Proper User Type","Select User Type",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                    }
                }
                else {
                    MessageBox.Show("Login Fail");
                    UserIdTextBox.Text = "";
                    PasswordTextbox.Text = "";
                    UserComboBox.SelectedIndex = -1;
                    UserIdTextBox.Focus();
                }
            }
            catch(Exception ex){
                MessageBox.Show(ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }
        }

        private void UserIdTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == 13 && UserIdTextBox.Text.Trim() != ""){
                PasswordTextbox.Focus();
            }
        }

        private void PasswordTextbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == 13 && PasswordTextbox.Text.Trim() != ""){
                UserComboBox.Focus();
            }
        }

        private void UserComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoginButton.Focus();
        }

        private void LoginForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void LoginLogoLabel_ClientSizeChanged(object sender, EventArgs e)
        {
            LoginLogoLabel.Left = (this.ClientSize.Width - LoginLogoLabel.Size.Width) / 2;
        }
    }
}
