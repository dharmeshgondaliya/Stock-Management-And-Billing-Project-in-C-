﻿namespace StockManagementAndBilling
{
    partial class AvailableStockForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.AvailabelStockLabel = new System.Windows.Forms.Label();
            this.StockDataGridView = new System.Windows.Forms.DataGridView();
            this.StockFilterGroupBox = new System.Windows.Forms.GroupBox();
            this.SearchButton = new System.Windows.Forms.Button();
            this.SelectCompanyComboBox = new System.Windows.Forms.ComboBox();
            this.SelectCompanyLabel = new System.Windows.Forms.Label();
            this.SelectItemComboBox = new System.Windows.Forms.ComboBox();
            this.SelectItemLabel = new System.Windows.Forms.Label();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.LogoRectangle = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.AvailableStockMenu = new System.Windows.Forms.MenuStrip();
            this.stockManageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.StockDataGridView)).BeginInit();
            this.StockFilterGroupBox.SuspendLayout();
            this.AvailableStockMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // AvailabelStockLabel
            // 
            this.AvailabelStockLabel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.AvailabelStockLabel.AutoSize = true;
            this.AvailabelStockLabel.BackColor = System.Drawing.Color.Black;
            this.AvailabelStockLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AvailabelStockLabel.ForeColor = System.Drawing.Color.White;
            this.AvailabelStockLabel.Location = new System.Drawing.Point(394, 47);
            this.AvailabelStockLabel.Name = "AvailabelStockLabel";
            this.AvailabelStockLabel.Size = new System.Drawing.Size(471, 46);
            this.AvailabelStockLabel.TabIndex = 4;
            this.AvailabelStockLabel.Text = "Stock Management & Billig";
            this.AvailabelStockLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.AvailabelStockLabel.ClientSizeChanged += new System.EventHandler(this.AvailabelStockLabel_ClientSizeChanged);
            // 
            // StockDataGridView
            // 
            this.StockDataGridView.AllowUserToAddRows = false;
            this.StockDataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.StockDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.StockDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.StockDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.StockDataGridView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.StockDataGridView.Location = new System.Drawing.Point(43, 232);
            this.StockDataGridView.MultiSelect = false;
            this.StockDataGridView.Name = "StockDataGridView";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.StockDataGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.StockDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.StockDataGridView.Size = new System.Drawing.Size(1175, 296);
            this.StockDataGridView.TabIndex = 5;
            // 
            // StockFilterGroupBox
            // 
            this.StockFilterGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.StockFilterGroupBox.Controls.Add(this.SearchButton);
            this.StockFilterGroupBox.Controls.Add(this.SelectCompanyComboBox);
            this.StockFilterGroupBox.Controls.Add(this.SelectCompanyLabel);
            this.StockFilterGroupBox.Controls.Add(this.SelectItemComboBox);
            this.StockFilterGroupBox.Controls.Add(this.SelectItemLabel);
            this.StockFilterGroupBox.Location = new System.Drawing.Point(43, 125);
            this.StockFilterGroupBox.Name = "StockFilterGroupBox";
            this.StockFilterGroupBox.Size = new System.Drawing.Size(1175, 80);
            this.StockFilterGroupBox.TabIndex = 6;
            this.StockFilterGroupBox.TabStop = false;
            // 
            // SearchButton
            // 
            this.SearchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchButton.Location = new System.Drawing.Point(909, 24);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(140, 37);
            this.SearchButton.TabIndex = 2;
            this.SearchButton.Text = "  Search";
            this.SearchButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.SearchButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.SearchButton.UseVisualStyleBackColor = true;
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // SelectCompanyComboBox
            // 
            this.SelectCompanyComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SelectCompanyComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectCompanyComboBox.FormattingEnabled = true;
            this.SelectCompanyComboBox.Location = new System.Drawing.Point(629, 29);
            this.SelectCompanyComboBox.Name = "SelectCompanyComboBox";
            this.SelectCompanyComboBox.Size = new System.Drawing.Size(210, 28);
            this.SelectCompanyComboBox.Sorted = true;
            this.SelectCompanyComboBox.TabIndex = 1;
            // 
            // SelectCompanyLabel
            // 
            this.SelectCompanyLabel.AutoSize = true;
            this.SelectCompanyLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectCompanyLabel.Location = new System.Drawing.Point(485, 32);
            this.SelectCompanyLabel.Name = "SelectCompanyLabel";
            this.SelectCompanyLabel.Size = new System.Drawing.Size(125, 20);
            this.SelectCompanyLabel.TabIndex = 0;
            this.SelectCompanyLabel.Text = "Select Company";
            // 
            // SelectItemComboBox
            // 
            this.SelectItemComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SelectItemComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectItemComboBox.FormattingEnabled = true;
            this.SelectItemComboBox.Location = new System.Drawing.Point(221, 29);
            this.SelectItemComboBox.Name = "SelectItemComboBox";
            this.SelectItemComboBox.Size = new System.Drawing.Size(210, 28);
            this.SelectItemComboBox.Sorted = true;
            this.SelectItemComboBox.TabIndex = 1;
            // 
            // SelectItemLabel
            // 
            this.SelectItemLabel.AutoSize = true;
            this.SelectItemLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectItemLabel.Location = new System.Drawing.Point(104, 32);
            this.SelectItemLabel.Name = "SelectItemLabel";
            this.SelectItemLabel.Size = new System.Drawing.Size(90, 20);
            this.SelectItemLabel.TabIndex = 0;
            this.SelectItemLabel.Text = "Select Item";
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.LogoRectangle});
            this.shapeContainer1.Size = new System.Drawing.Size(1259, 551);
            this.shapeContainer1.TabIndex = 0;
            this.shapeContainer1.TabStop = false;
            // 
            // LogoRectangle
            // 
            this.LogoRectangle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LogoRectangle.BackColor = System.Drawing.Color.Black;
            this.LogoRectangle.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.LogoRectangle.Location = new System.Drawing.Point(-9, 29);
            this.LogoRectangle.Name = "LogoRectangle";
            this.LogoRectangle.Size = new System.Drawing.Size(1278, 72);
            // 
            // AvailableStockMenu
            // 
            this.AvailableStockMenu.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.AvailableStockMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stockManageToolStripMenuItem,
            this.toolStripMenuItem1,
            this.exitToolStripMenuItem});
            this.AvailableStockMenu.Location = new System.Drawing.Point(0, 0);
            this.AvailableStockMenu.Name = "AvailableStockMenu";
            this.AvailableStockMenu.Size = new System.Drawing.Size(1259, 29);
            this.AvailableStockMenu.TabIndex = 11;
            this.AvailableStockMenu.Text = "menuStrip1";
            // 
            // stockManageToolStripMenuItem
            // 
            this.stockManageToolStripMenuItem.Name = "stockManageToolStripMenuItem";
            this.stockManageToolStripMenuItem.Size = new System.Drawing.Size(54, 25);
            this.stockManageToolStripMenuItem.Text = "&Back";
            this.stockManageToolStripMenuItem.Click += new System.EventHandler(this.stockManageToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Enabled = false;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(26, 25);
            this.toolStripMenuItem1.Text = "|";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(46, 25);
            this.exitToolStripMenuItem.Text = "&Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // AvailableStockForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(1259, 551);
            this.Controls.Add(this.AvailableStockMenu);
            this.Controls.Add(this.StockFilterGroupBox);
            this.Controls.Add(this.StockDataGridView);
            this.Controls.Add(this.AvailabelStockLabel);
            this.Controls.Add(this.shapeContainer1);
            this.Name = "AvailableStockForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Available Stock";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AvailableStockForm_FormClosing);
            this.Load += new System.EventHandler(this.AvailableStockForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.StockDataGridView)).EndInit();
            this.StockFilterGroupBox.ResumeLayout(false);
            this.StockFilterGroupBox.PerformLayout();
            this.AvailableStockMenu.ResumeLayout(false);
            this.AvailableStockMenu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label AvailabelStockLabel;
        private System.Windows.Forms.DataGridView StockDataGridView;
        private System.Windows.Forms.GroupBox StockFilterGroupBox;
        private System.Windows.Forms.Button SearchButton;
        private System.Windows.Forms.ComboBox SelectCompanyComboBox;
        private System.Windows.Forms.Label SelectCompanyLabel;
        private System.Windows.Forms.ComboBox SelectItemComboBox;
        private System.Windows.Forms.Label SelectItemLabel;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape LogoRectangle;
        private System.Windows.Forms.MenuStrip AvailableStockMenu;
        private System.Windows.Forms.ToolStripMenuItem stockManageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
    }
}