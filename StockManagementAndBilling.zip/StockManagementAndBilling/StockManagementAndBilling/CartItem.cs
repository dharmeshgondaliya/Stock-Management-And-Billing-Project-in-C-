﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockManagementAndBilling
{
    class CartItem
    {
        [System.ComponentModel.DisplayName("Item Name")]
        public String ItemName { get; set; }
        [System.ComponentModel.DisplayName("Company Name")]
        public String Company { get; set; }
        [System.ComponentModel.DisplayName("Unit Price")]
        public decimal UnitPrice { get; set; }
        public int Quantity { get; set; }
        [System.ComponentModel.DisplayName("Total Price")]
        public decimal TotalPrice { get; set; }
    }
}
