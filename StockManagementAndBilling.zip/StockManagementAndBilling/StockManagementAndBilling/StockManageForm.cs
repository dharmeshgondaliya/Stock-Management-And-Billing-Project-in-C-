﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace StockManagementAndBilling
{
    public partial class StockManageForm : Form
    {
        int btn = 0;
        OleDbConnection con;
        OleDbCommand cmd;
        OleDbDataReader reader;
        String name = "";
        String cmpn = "";
        String itemname = "";
        String companyname = "";
        public StockManageForm()
        {
            InitializeComponent();
        }

        private void StockManageForm_Load(object sender, EventArgs e)
        {
            CompanySetting();
            //Database Connection
            con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Application.StartupPath + "\\Database/StockManagement.accdb;Persist Security Info=False");
            con.Open();

            // Check Connection, if not then exit in Application
            if (con.State != ConnectionState.Open)
            {
                DialogResult res = MessageBox.Show("Connection fail", "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (res == DialogResult.OK)
                {
                    Application.Exit();
                }
            }

            //Set Icon From Buttons and Set Enabled False from Textbox
            AddItemButton.Image = Image.FromFile(Application.StartupPath + "/icons/Add New.png");
            AddNewItemButton.Image = Image.FromFile(Application.StartupPath + "/icons/Add New.png");
            UpdateItemButton.Image = Image.FromFile(Application.StartupPath + "/icons/Update.png");
            DeleteItemButton.Image = Image.FromFile(Application.StartupPath + "/icons/Delete.png");
            OkButton.Image = Image.FromFile(Application.StartupPath+"/icons/OK.png");
            CancleButton.Image = Image.FromFile(Application.StartupPath + "/icons/Cancel.png");
            AddItemButton.Text = "  Add Item";
            enabledtf(false);
            ItemNameComboBox.Enabled = false;
            CompaniNameComboBox.Enabled = false;
            OkButton.Enabled = false;
            AddNewItemButton.Focus();
            this.WindowState = FormWindowState.Maximized;
        }

        private void CompanySetting() {
            CompanyClass Company = new CompanyClass();
            // company name
            StockManagementLable.Text = Company.CompanyName.ToString();
            // logp color
            StockManagementLable.ForeColor = System.Drawing.ColorTranslator.FromHtml(Company.NameColor.ToString());
            StockManagementLable.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.NameBackColor.ToString());
            LogoRectangle.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.NameBackColor.ToString());
            // form back color
            this.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.FormBackColor.ToString());
        }

        private void AddNewItemButton_Click(object sender, EventArgs e)
        {
            // add item button click then button enabled false
            btn = 1;
            AddItemButton.Text = "  Add Item";
            enabledtf(true);
            UpdateItemButton.Enabled = false;
            DeleteItemButton.Enabled = false;
            ItemNameComboBox.Enabled = false;
            CompaniNameComboBox.Enabled = false;
            OkButton.Enabled = false;
            AddItemButton.Image = Image.FromFile(Application.StartupPath+"/icons/Add New.png");
            NameTextBox.Focus();
        }

        private void UpdateItemButton_Click(object sender, EventArgs e)
        {
            // delete item button click then button enabled false
            btn = 2;
            AddItemButton.Text = "  Update Item";
            enabledtf(false);
            AddNewItemButton.Enabled = false;
            DeleteItemButton.Enabled = false;
            ItemNameComboBox.Enabled = true;
            CompaniNameComboBox.Enabled = true;
            OkButton.Enabled = true;
            AddItemButton.Image = Image.FromFile(Application.StartupPath + "/icons/Update.png");
            ComboBoxValue();
        }

        private void DeleteItemButton_Click(object sender, EventArgs e)
        {
            // update item button click then button enabled false
            btn = 3;
            AddItemButton.Text = "  Delete Item";
            enabledtf(false);
            AddNewItemButton.Enabled = false;
            UpdateItemButton.Enabled = false;
            ItemNameComboBox.Enabled = true;
            CompaniNameComboBox.Enabled = true;
            OkButton.Enabled = true;
            AddItemButton.Image = Image.FromFile(Application.StartupPath + "/icons/Delete.png");
            ComboBoxValue();
        }
        private void enabledtf(Boolean tf)
        {
            // button enabled true / false
            NameTextBox.Enabled = tf;
            PriceTextBox.Enabled = tf;
            QuantityTextBox.Enabled = tf;
            CompanyNameTextBox.Enabled = tf;
            AddItemButton.Enabled = tf;
            CancleButton.Enabled = tf;
        }

        private void TextboxEmpty()
        {
            // emplty all textbox
            NameTextBox.Text = "";
            PriceTextBox.Text = "";
            QuantityTextBox.Text = "";
            CompanyNameTextBox.Text = "";
        }

        private Boolean TextboxValidation()
        {
            // Textbox Validation
            if (NameTextBox.Text.Trim() == "")
            {
                MessageBox.Show("Please Enter Item Name","Enter Name",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return false;
            }
            if (PriceTextBox.Text.Trim() == "")
            {
                MessageBox.Show("Please Enter Price","Enter Price",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return false;
            }
            if (QuantityTextBox.Text.Trim() == "")
            {
                MessageBox.Show("Please Enter Item Quantity","Enter Quantity",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return false;
            }
            if (CompanyNameTextBox.Text.Trim() == "")
            {
                MessageBox.Show("Please Enter Company Name","Enter Company Name",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }
            return true;
        }

        private void mainbutton(Boolean tf)
        {
            // Buttons Enabled true/false
            AddNewItemButton.Enabled = tf;
            UpdateItemButton.Enabled = tf;
            DeleteItemButton.Enabled = tf;
        }

        private void AddItemButton_Click(object sender, EventArgs e)
        {
            // Select method from insert, update and delete data.
            if (TextboxValidation())
            {
                if (AddItemButton.Text == "  Add Item" && btn == 1)
                {
                    insertdata();
                    return;
                }
                if (AddItemButton.Text == "  Update Item" && btn == 2)
                {
                    updatedata();
                    return;
                }
                if (AddItemButton.Text == "  Delete Item" && btn == 3)
                {
                    deletedata();
                    return;
                }
                if (btn != 0)
                {
                    btn = 0;
                }
            }
        }

        private void ComboBoxValue()
        {
            // Add Items(item Name) in Combobox
            ItemNameComboBox.Items.Clear();
            try
            {
                cmd = new OleDbCommand("select iName from Stock", con);
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                     ItemNameComboBox.Items.Add(reader["iName"].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return;
            }
        }

        private void deletedata()
        {
            // Delete Data
            cmd = new OleDbCommand("delete from Stock where iName='" + name + "' AND cName = '"+cmpn+"'", con);
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }
            MessageBox.Show("Record Delete Successful","Record Delete",MessageBoxButtons.OK,MessageBoxIcon.Information);
            enabledtf(false);
            TextboxEmpty();
            mainbutton(true);
            ItemNameComboBox.SelectedIndex = -1;
            CompaniNameComboBox.SelectedIndex = -1;
            ItemNameComboBox.Enabled = false;
            CompaniNameComboBox.Enabled = false;
            OkButton.Enabled = false;
        }

        private void updatedata()
        {
            // update data from database
            String pname = NameTextBox.Text.Trim();
            String pprice = PriceTextBox.Text.Trim();
            String pquentity = QuantityTextBox.Text.Trim();
            String cname = CompanyNameTextBox.Text.Trim();

            try
            {
                if (itemname != pname && companyname != cname)
                {
                    cmd = new OleDbCommand("select iName,cName from Stock", con);
                    reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        if (pname == reader["iName"].ToString() && companyname == reader["cName"].ToString())
                        {
                            MessageBox.Show(pname+" AND "+companyname+"" + " Is Already Available, Please Enter Another item Name","Enter Another Item Name",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                            NameTextBox.Text = "";
                            NameTextBox.Focus();
                            return;
                        }
                    }
                }
                cmd = new OleDbCommand();
                cmd.Connection = con;
                cmd.CommandText = "update Stock set iName = '"+pname+"',iPrice = '"+pprice+"', iQuentity = '"+pquentity+"',cName = '"+cname+"' where iName = '"+name+"' AND cName = '"+cmpn+"'";
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }
            MessageBox.Show("Record Update Successful","Record Update",MessageBoxButtons.OK,MessageBoxIcon.Information);
            enabledtf(false);
            TextboxEmpty();
            mainbutton(true);
            ItemNameComboBox.SelectedIndex = -1;
            CompaniNameComboBox.SelectedIndex = -1;
            ItemNameComboBox.Enabled = false;
            CompaniNameComboBox.Enabled = false;
            OkButton.Enabled = false;
        }

        private void insertdata()
        {
            // insert data from database
            String iname = NameTextBox.Text.Trim();
            String iprice = PriceTextBox.Text.Trim();
            String iquentity = QuantityTextBox.Text.Trim();
            String cname = CompanyNameTextBox.Text.Trim();

            try {
                cmd = new OleDbCommand("select iName,cName from Stock", con);
                reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    if (iname == reader["iName"].ToString() && cname == reader["cName"].ToString())
                    {
                        MessageBox.Show(iname+" Is Already Available, Please insert Another Item","Insert another Item Name",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                        NameTextBox.Text = "";
                        NameTextBox.Focus();
                        return;
                    }
                }

                String query = "insert into Stock(iName,iPrice,iQuentity,cName) values('"+iname+"','"+iprice+"','"+iquentity+"','"+cname+"')";
                cmd = new OleDbCommand(query,con);
                cmd.ExecuteNonQuery();
            }
            catch(Exception ex){
                MessageBox.Show(ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }
            MessageBox.Show("Record Insert Success","Record Insert",MessageBoxButtons.OK,MessageBoxIcon.Information);
            enabledtf(false);
            mainbutton(true);
            TextboxEmpty();
            CancleButton.Enabled = false;
            AddItemButton.Enabled = false;
        }

        private void CancleButton_Click(object sender, EventArgs e)
        {
            // Buttons And Textbox Enabled true/false
            NameTextBox.Text = "";
            PriceTextBox.Text = "";
            QuantityTextBox.Text = "";
            CompanyNameTextBox.Text = "";
            enabledtf(false);
            mainbutton(true);
            AddItemButton.Enabled = false;
            ItemNameComboBox.SelectedIndex = -1;
            ItemNameComboBox.Enabled = false;
            CompaniNameComboBox.Enabled = false;
            OkButton.Enabled = false;
            AddItemButton.Text = "  Add Item";
            AddItemButton.Image = Image.FromFile(Application.StartupPath + "/icons/Add New.png");
        }
        
        private void OkButton_Click(object sender, EventArgs e)
        {
            if(ItemNameComboBox.SelectedIndex == -1){
                MessageBox.Show("Please Select Item Name","Select Item",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }
            else{
                name = ItemNameComboBox.SelectedItem.ToString();
                cmpn = CompaniNameComboBox.SelectedItem.ToString();
                setdata();
            }
        }

        private void setdata()
        {
            // Set Data in Textbox
            try
            {
                cmd = new OleDbCommand("select * from Stock where iName = '" + name + "' AND cName = '"+CompaniNameComboBox.SelectedItem.ToString()+"'", con);
                reader = cmd.ExecuteReader();
                reader.Read();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }
            itemname = reader["iName"].ToString();
            companyname = reader["cName"].ToString();

            NameTextBox.Text = reader["iName"].ToString();
            PriceTextBox.Text = reader["iPrice"].ToString();
            QuantityTextBox.Text = reader["iQuentity"].ToString();
            CompanyNameTextBox.Text = reader["cName"].ToString();
            enabledtf(true);
        }

        private void NameTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // enter name
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122 || e.KeyChar == 13 || e.KeyChar >= 48 && e.KeyChar <= 57 || e.KeyChar == 8 || e.KeyChar == 32 || e.KeyChar == 46)
            {
                if (e.KeyChar == 13 && NameTextBox.Text != "")
                {
                    PriceTextBox.Focus();
                }
                else
                {
                    e.Handled = false;
                }
            }
            else
            {
                e.Handled = true;    
            }
        }

        private void PriceTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // enter only price
            if (e.KeyChar >= 48 && e.KeyChar <= 57 || e.KeyChar == 13 || e.KeyChar == 46 || e.KeyChar == 8)
            {
                if(e.KeyChar == 13 && PriceTextBox.Text != ""){
                    QuantityTextBox.Focus();
                }
                else{
                    e.Handled = false;
                }
            }
            else{
                e.Handled = true;
            }
        }

        private void QuantityTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // enter only quentity
            if (e.KeyChar >= 48 && e.KeyChar <= 57 || e.KeyChar == 13 || e.KeyChar == 8)
            {
                if (e.KeyChar == 13 && QuantityTextBox.Text != "")
                {
                    CompanyNameTextBox.Focus();
                }
                else
                {
                    e.Handled = false;
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void CompanyNameTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // enter company name
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122 || e.KeyChar == 13 || e.KeyChar >= 48 && e.KeyChar <= 57 || e.KeyChar == 8 || e.KeyChar == 32 || e.KeyChar == 46)
            {
                if (e.KeyChar == 13 && CompanyNameTextBox.Text != "")
                {
                    AddItemButton.Focus();
                }
                else
                {
                    e.Handled = false;
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void StockManageForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.con.Close();
            this.Hide();
        }

        private void stockManageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.con.Close();
            this.Close();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void StockManagementLable_ClientSizeChanged(object sender, EventArgs e)
        {
            StockManagementLable.Left = (this.ClientSize.Width - StockManagementLable.Size.Width) / 2;
        }

        private void ItemNameComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            CompaniNameComboBox.Items.Clear();
            if(ItemNameComboBox.SelectedIndex != -1){
                try {
                    cmd = new OleDbCommand("select cName from Stock where iName = '"+ItemNameComboBox.SelectedItem.ToString()+"'",con);
                    reader = cmd.ExecuteReader();
                    while(reader.Read()){
                        CompaniNameComboBox.Items.Add(reader["cName"].ToString());
                    }
                }
                catch(Exception expn){
                    MessageBox.Show(expn.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                    return;
                }
                CompaniNameComboBox.SelectedIndex = 0;
            }
        }

    }
}
