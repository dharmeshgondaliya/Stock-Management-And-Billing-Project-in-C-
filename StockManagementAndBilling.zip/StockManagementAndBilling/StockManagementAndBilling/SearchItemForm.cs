﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace StockManagementAndBilling
{
    public partial class SearchItemForm : Form
    {
        OleDbConnection con;
        OleDbCommand cmd;
        OleDbDataReader reader;
        public SearchItemForm()
        {
            InitializeComponent();
        }

        private void SearchItemForm_Load(object sender, EventArgs e)
        {
            CompanySetting();
            SearchButton.Image = Image.FromFile(Application.StartupPath+"/icons/Search.png");
            //Database Connection
            con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Application.StartupPath + "\\Database/StockManagement.accdb;Persist Security Info=False");
            con.Open();

            // Check Connection, if not then exit in Application
            if (con.State != ConnectionState.Open)
            {
                DialogResult res = MessageBox.Show("Connection fail", "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (res == DialogResult.OK)
                {
                    Application.Exit();
                }
            }
            setdata();
            ItemNameLabel.Text = "";
            ItemPriceLabel.Text = "";
            ItemQuantityLabel.Text = "";
            CompanyNameLabel.Text = "";
        }

        private void CompanySetting()
        {
            CompanyClass Company = new CompanyClass();
            SearchItemLabel.Text = Company.CompanyName.ToString();
            // logo color
            SearchItemLabel.ForeColor = System.Drawing.ColorTranslator.FromHtml(Company.NameColor.ToString());
            SearchItemLabel.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.NameBackColor.ToString());
            LogoRectangle.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.NameBackColor.ToString());
            // form color
            this.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.FormBackColor.ToString());
        }

        private void setdata()
        {
            try
            {
                cmd = new OleDbCommand("select Distinct iName from Stock",con);
                reader = cmd.ExecuteReader();
                while(reader.Read()){
                    SearchComboBox.Items.Add(reader["iName"].ToString());                    
                }
            }
            catch(Exception ex){
                MessageBox.Show(ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            bool ck = true;
            if(SearchComboBox.SelectedIndex == -1){
                // if item not select then messagebox show
                MessageBox.Show("Please Select Item","Select Item",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return;
            }
            // select selected item data
            cmd = new OleDbCommand("select * from Stock where iName = '"+SearchComboBox.SelectedItem.ToString()+"'",con);
            reader = cmd.ExecuteReader();
            reader.Read();
            // if quantity empty then show lable 
            if (reader["iQuentity"].ToString() == "0")
            {
                ItemNotFoundGroupBox.Visible = true;
            }
            // show item data
            ItemNameLabel.Text = reader["iName"].ToString();
            ItemPriceLabel.Text = reader["iPrice"].ToString();
            ItemQuantityLabel.Text = reader["iQuentity"].ToString();
            CompanyNameLabel.Text = reader["cName"].ToString();
            while(ck){
                if(reader.Read()){
                    ItemQuantityLabel.Text += ", "+reader["iQuentity"].ToString();
                    ItemPriceLabel.Text += ", " + reader["iPrice"].ToString();
                    CompanyNameLabel.Text += ", "+reader["cName"].ToString();
                }
                else{
                    ck = false;
                }
            }
            
        }

        private void SearchComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            ItemNotFoundGroupBox.Visible = false;
        }

        private void SearchItemForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.con.Close();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void stockManageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.con.Close();
            this.Hide();
        }

        private void SearchItemLabel_ClientSizeChanged(object sender, EventArgs e)
        {
            SearchItemLabel.Left = (this.ClientSize.Width - SearchItemLabel.Size.Width) / 2;
        }
    }
}
