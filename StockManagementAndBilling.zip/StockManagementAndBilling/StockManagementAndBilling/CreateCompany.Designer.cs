﻿namespace StockManagementAndBilling
{
    partial class CreateCompany
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CreateCompanyLabel = new System.Windows.Forms.Label();
            this.CompanyNameTextBox = new System.Windows.Forms.TextBox();
            this.MobileNumberTextbox = new System.Windows.Forms.TextBox();
            this.EmailIdTextBox = new System.Windows.Forms.TextBox();
            this.AddressTextBox = new System.Windows.Forms.TextBox();
            this.SaveDataButton = new System.Windows.Forms.Button();
            this.CompanyLabel = new System.Windows.Forms.Label();
            this.FirstNameTextBox = new System.Windows.Forms.TextBox();
            this.LastNameTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // CreateCompanyLabel
            // 
            this.CreateCompanyLabel.AutoSize = true;
            this.CreateCompanyLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CreateCompanyLabel.Location = new System.Drawing.Point(217, 20);
            this.CreateCompanyLabel.Name = "CreateCompanyLabel";
            this.CreateCompanyLabel.Size = new System.Drawing.Size(219, 31);
            this.CreateCompanyLabel.TabIndex = 0;
            this.CreateCompanyLabel.Text = "Create Company";
            this.CreateCompanyLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // CompanyNameTextBox
            // 
            this.CompanyNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CompanyNameTextBox.Location = new System.Drawing.Point(223, 218);
            this.CompanyNameTextBox.Name = "CompanyNameTextBox";
            this.CompanyNameTextBox.Size = new System.Drawing.Size(277, 26);
            this.CompanyNameTextBox.TabIndex = 0;
            this.CompanyNameTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.CompanyNameTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CompanyNameTextBox_KeyPress);
            // 
            // MobileNumberTextbox
            // 
            this.MobileNumberTextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MobileNumberTextbox.Location = new System.Drawing.Point(223, 275);
            this.MobileNumberTextbox.MaxLength = 10;
            this.MobileNumberTextbox.Name = "MobileNumberTextbox";
            this.MobileNumberTextbox.Size = new System.Drawing.Size(277, 26);
            this.MobileNumberTextbox.TabIndex = 1;
            this.MobileNumberTextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.MobileNumberTextbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MobileNumberTextbox_KeyPress);
            // 
            // EmailIdTextBox
            // 
            this.EmailIdTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmailIdTextBox.Location = new System.Drawing.Point(223, 333);
            this.EmailIdTextBox.Name = "EmailIdTextBox";
            this.EmailIdTextBox.Size = new System.Drawing.Size(277, 26);
            this.EmailIdTextBox.TabIndex = 2;
            this.EmailIdTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.EmailIdTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.EmailIdTextBox_KeyPress);
            // 
            // AddressTextBox
            // 
            this.AddressTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddressTextBox.Location = new System.Drawing.Point(223, 390);
            this.AddressTextBox.Multiline = true;
            this.AddressTextBox.Name = "AddressTextBox";
            this.AddressTextBox.Size = new System.Drawing.Size(277, 54);
            this.AddressTextBox.TabIndex = 3;
            this.AddressTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.AddressTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.AddressTextBox_KeyPress);
            // 
            // SaveDataButton
            // 
            this.SaveDataButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaveDataButton.Location = new System.Drawing.Point(223, 474);
            this.SaveDataButton.Name = "SaveDataButton";
            this.SaveDataButton.Size = new System.Drawing.Size(141, 38);
            this.SaveDataButton.TabIndex = 4;
            this.SaveDataButton.Text = "Create";
            this.SaveDataButton.UseVisualStyleBackColor = true;
            this.SaveDataButton.Click += new System.EventHandler(this.SaveDataButton_Click);
            // 
            // CompanyLabel
            // 
            this.CompanyLabel.AutoSize = true;
            this.CompanyLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CompanyLabel.Location = new System.Drawing.Point(51, 101);
            this.CompanyLabel.Name = "CompanyLabel";
            this.CompanyLabel.Size = new System.Drawing.Size(139, 320);
            this.CompanyLabel.TabIndex = 4;
            this.CompanyLabel.Text = "First Name\r\n\r\n\r\nLast Name\r\n\r\n\r\nCompany Name\r\n\r\n\r\nMobile Number\r\n\r\n\r\nEmail ID\r\n\r\n\r" +
    "\nCompany Address";
            // 
            // FirstNameTextBox
            // 
            this.FirstNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FirstNameTextBox.Location = new System.Drawing.Point(223, 101);
            this.FirstNameTextBox.Name = "FirstNameTextBox";
            this.FirstNameTextBox.Size = new System.Drawing.Size(277, 26);
            this.FirstNameTextBox.TabIndex = 0;
            this.FirstNameTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.FirstNameTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.FirstNameTextBox_KeyPress);
            // 
            // LastNameTextBox
            // 
            this.LastNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LastNameTextBox.Location = new System.Drawing.Point(223, 158);
            this.LastNameTextBox.MaxLength = 10;
            this.LastNameTextBox.Name = "LastNameTextBox";
            this.LastNameTextBox.Size = new System.Drawing.Size(277, 26);
            this.LastNameTextBox.TabIndex = 1;
            this.LastNameTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.LastNameTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.FirstNameTextBox_KeyPress);
            // 
            // CreateCompany
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(566, 540);
            this.Controls.Add(this.CompanyLabel);
            this.Controls.Add(this.SaveDataButton);
            this.Controls.Add(this.AddressTextBox);
            this.Controls.Add(this.EmailIdTextBox);
            this.Controls.Add(this.LastNameTextBox);
            this.Controls.Add(this.MobileNumberTextbox);
            this.Controls.Add(this.FirstNameTextBox);
            this.Controls.Add(this.CompanyNameTextBox);
            this.Controls.Add(this.CreateCompanyLabel);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CreateCompany";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CreateCompany";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CreateCompany_FormClosing);
            this.Load += new System.EventHandler(this.CreateCompany_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label CreateCompanyLabel;
        private System.Windows.Forms.TextBox CompanyNameTextBox;
        private System.Windows.Forms.TextBox MobileNumberTextbox;
        private System.Windows.Forms.TextBox EmailIdTextBox;
        private System.Windows.Forms.TextBox AddressTextBox;
        private System.Windows.Forms.Button SaveDataButton;
        private System.Windows.Forms.Label CompanyLabel;
        private System.Windows.Forms.TextBox FirstNameTextBox;
        private System.Windows.Forms.TextBox LastNameTextBox;
    }
}