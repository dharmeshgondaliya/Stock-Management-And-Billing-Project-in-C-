﻿namespace StockManagementAndBilling
{
    partial class ShellStockForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.LogoRectangle = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.SelectDateLabel = new System.Windows.Forms.Label();
            this.SelectItemLabel = new System.Windows.Forms.Label();
            this.CoustomerDataGridView = new System.Windows.Forms.DataGridView();
            this.FilterGroupBox = new System.Windows.Forms.GroupBox();
            this.SearchButton = new System.Windows.Forms.Button();
            this.SelectDate = new System.Windows.Forms.DateTimePicker();
            this.CoustomerNameTextBox = new System.Windows.Forms.TextBox();
            this.PaymentTypeComboBox = new System.Windows.Forms.ComboBox();
            this.CoustomerNameLabel = new System.Windows.Forms.Label();
            this.PaymentTypeLabe = new System.Windows.Forms.Label();
            this.SelectCompanyComboBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SelectItemComboBox = new System.Windows.Forms.ComboBox();
            this.SelectCompanyLabel = new System.Windows.Forms.Label();
            this.CoustomerItemGridView = new System.Windows.Forms.DataGridView();
            this.OrderInfoLabel = new System.Windows.Forms.Label();
            this.OrderItemInfoLabel = new System.Windows.Forms.Label();
            this.ShellStockMenu = new System.Windows.Forms.MenuStrip();
            this.stockManageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ShellStockLabel = new System.Windows.Forms.Label();
            this.ContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.CoustomerDataGridView)).BeginInit();
            this.FilterGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CoustomerItemGridView)).BeginInit();
            this.ShellStockMenu.SuspendLayout();
            this.ContextMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.LogoRectangle});
            this.shapeContainer1.Size = new System.Drawing.Size(1203, 683);
            this.shapeContainer1.TabIndex = 0;
            this.shapeContainer1.TabStop = false;
            // 
            // LogoRectangle
            // 
            this.LogoRectangle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LogoRectangle.BackColor = System.Drawing.Color.Black;
            this.LogoRectangle.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.LogoRectangle.BorderColor = System.Drawing.Color.White;
            this.LogoRectangle.Location = new System.Drawing.Point(-3, 29);
            this.LogoRectangle.Name = "LogoRectangle";
            this.LogoRectangle.Size = new System.Drawing.Size(1215, 70);
            // 
            // SelectDateLabel
            // 
            this.SelectDateLabel.AutoSize = true;
            this.SelectDateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectDateLabel.Location = new System.Drawing.Point(35, 94);
            this.SelectDateLabel.Name = "SelectDateLabel";
            this.SelectDateLabel.Size = new System.Drawing.Size(93, 20);
            this.SelectDateLabel.TabIndex = 0;
            this.SelectDateLabel.Text = "Select Date";
            // 
            // SelectItemLabel
            // 
            this.SelectItemLabel.AutoSize = true;
            this.SelectItemLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectItemLabel.Location = new System.Drawing.Point(35, 34);
            this.SelectItemLabel.Name = "SelectItemLabel";
            this.SelectItemLabel.Size = new System.Drawing.Size(90, 20);
            this.SelectItemLabel.TabIndex = 0;
            this.SelectItemLabel.Text = "Select Item";
            // 
            // CoustomerDataGridView
            // 
            this.CoustomerDataGridView.AllowUserToAddRows = false;
            this.CoustomerDataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CoustomerDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.CoustomerDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.CoustomerDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CoustomerDataGridView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.CoustomerDataGridView.Location = new System.Drawing.Point(60, 294);
            this.CoustomerDataGridView.MultiSelect = false;
            this.CoustomerDataGridView.Name = "CoustomerDataGridView";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.CoustomerDataGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.CoustomerDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.CoustomerDataGridView.Size = new System.Drawing.Size(1078, 204);
            this.CoustomerDataGridView.TabIndex = 6;
            this.CoustomerDataGridView.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.CoustomerDataGridView_CellMouseClick);
            this.CoustomerDataGridView.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.CoustomerDataGridView_ColumnHeaderMouseClick);
            this.CoustomerDataGridView.MouseDown += new System.Windows.Forms.MouseEventHandler(this.CoustomerDataGridView_MouseDown);
            // 
            // FilterGroupBox
            // 
            this.FilterGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.FilterGroupBox.Controls.Add(this.SearchButton);
            this.FilterGroupBox.Controls.Add(this.SelectDate);
            this.FilterGroupBox.Controls.Add(this.SelectDateLabel);
            this.FilterGroupBox.Controls.Add(this.CoustomerNameTextBox);
            this.FilterGroupBox.Controls.Add(this.PaymentTypeComboBox);
            this.FilterGroupBox.Controls.Add(this.CoustomerNameLabel);
            this.FilterGroupBox.Controls.Add(this.PaymentTypeLabe);
            this.FilterGroupBox.Controls.Add(this.SelectCompanyComboBox);
            this.FilterGroupBox.Controls.Add(this.label1);
            this.FilterGroupBox.Controls.Add(this.SelectItemComboBox);
            this.FilterGroupBox.Controls.Add(this.SelectCompanyLabel);
            this.FilterGroupBox.Controls.Add(this.SelectItemLabel);
            this.FilterGroupBox.Location = new System.Drawing.Point(60, 114);
            this.FilterGroupBox.Name = "FilterGroupBox";
            this.FilterGroupBox.Size = new System.Drawing.Size(1078, 148);
            this.FilterGroupBox.TabIndex = 5;
            this.FilterGroupBox.TabStop = false;
            // 
            // SearchButton
            // 
            this.SearchButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.SearchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchButton.Location = new System.Drawing.Point(858, 82);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(185, 45);
            this.SearchButton.TabIndex = 5;
            this.SearchButton.Text = "  Search";
            this.SearchButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.SearchButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.SearchButton.UseVisualStyleBackColor = true;
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // SelectDate
            // 
            this.SelectDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.SelectDate.Location = new System.Drawing.Point(142, 88);
            this.SelectDate.Name = "SelectDate";
            this.SelectDate.Size = new System.Drawing.Size(241, 26);
            this.SelectDate.TabIndex = 3;
            // 
            // CoustomerNameTextBox
            // 
            this.CoustomerNameTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CoustomerNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CoustomerNameTextBox.Location = new System.Drawing.Point(563, 90);
            this.CoustomerNameTextBox.Name = "CoustomerNameTextBox";
            this.CoustomerNameTextBox.Size = new System.Drawing.Size(216, 26);
            this.CoustomerNameTextBox.TabIndex = 4;
            this.CoustomerNameTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // PaymentTypeComboBox
            // 
            this.PaymentTypeComboBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.PaymentTypeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PaymentTypeComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PaymentTypeComboBox.FormattingEnabled = true;
            this.PaymentTypeComboBox.Items.AddRange(new object[] {
            "All",
            "Paid",
            "Unpaid"});
            this.PaymentTypeComboBox.Location = new System.Drawing.Point(901, 31);
            this.PaymentTypeComboBox.Name = "PaymentTypeComboBox";
            this.PaymentTypeComboBox.Size = new System.Drawing.Size(142, 28);
            this.PaymentTypeComboBox.TabIndex = 2;
            // 
            // CoustomerNameLabel
            // 
            this.CoustomerNameLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CoustomerNameLabel.AutoSize = true;
            this.CoustomerNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CoustomerNameLabel.Location = new System.Drawing.Point(410, 93);
            this.CoustomerNameLabel.Name = "CoustomerNameLabel";
            this.CoustomerNameLabel.Size = new System.Drawing.Size(133, 20);
            this.CoustomerNameLabel.TabIndex = 0;
            this.CoustomerNameLabel.Text = "Coustomer Name";
            // 
            // PaymentTypeLabe
            // 
            this.PaymentTypeLabe.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.PaymentTypeLabe.AutoSize = true;
            this.PaymentTypeLabe.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PaymentTypeLabe.Location = new System.Drawing.Point(807, 34);
            this.PaymentTypeLabe.Name = "PaymentTypeLabe";
            this.PaymentTypeLabe.Size = new System.Drawing.Size(71, 20);
            this.PaymentTypeLabe.TabIndex = 0;
            this.PaymentTypeLabe.Text = "Payment";
            // 
            // SelectCompanyComboBox
            // 
            this.SelectCompanyComboBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.SelectCompanyComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SelectCompanyComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectCompanyComboBox.FormattingEnabled = true;
            this.SelectCompanyComboBox.Location = new System.Drawing.Point(563, 34);
            this.SelectCompanyComboBox.Name = "SelectCompanyComboBox";
            this.SelectCompanyComboBox.Size = new System.Drawing.Size(216, 28);
            this.SelectCompanyComboBox.Sorted = true;
            this.SelectCompanyComboBox.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(569, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select Company";
            // 
            // SelectItemComboBox
            // 
            this.SelectItemComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SelectItemComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectItemComboBox.FormattingEnabled = true;
            this.SelectItemComboBox.Location = new System.Drawing.Point(142, 31);
            this.SelectItemComboBox.Name = "SelectItemComboBox";
            this.SelectItemComboBox.Size = new System.Drawing.Size(241, 28);
            this.SelectItemComboBox.Sorted = true;
            this.SelectItemComboBox.TabIndex = 0;
            // 
            // SelectCompanyLabel
            // 
            this.SelectCompanyLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.SelectCompanyLabel.AutoSize = true;
            this.SelectCompanyLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectCompanyLabel.Location = new System.Drawing.Point(410, 34);
            this.SelectCompanyLabel.Name = "SelectCompanyLabel";
            this.SelectCompanyLabel.Size = new System.Drawing.Size(125, 20);
            this.SelectCompanyLabel.TabIndex = 0;
            this.SelectCompanyLabel.Text = "Select Company";
            // 
            // CoustomerItemGridView
            // 
            this.CoustomerItemGridView.AllowUserToAddRows = false;
            this.CoustomerItemGridView.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CoustomerItemGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.CoustomerItemGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.CoustomerItemGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CoustomerItemGridView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.CoustomerItemGridView.Location = new System.Drawing.Point(60, 524);
            this.CoustomerItemGridView.MultiSelect = false;
            this.CoustomerItemGridView.Name = "CoustomerItemGridView";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.CoustomerItemGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.CoustomerItemGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.CoustomerItemGridView.Size = new System.Drawing.Size(1078, 144);
            this.CoustomerItemGridView.TabIndex = 7;
            // 
            // OrderInfoLabel
            // 
            this.OrderInfoLabel.AutoSize = true;
            this.OrderInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OrderInfoLabel.Location = new System.Drawing.Point(75, 269);
            this.OrderInfoLabel.Name = "OrderInfoLabel";
            this.OrderInfoLabel.Size = new System.Drawing.Size(134, 20);
            this.OrderInfoLabel.TabIndex = 8;
            this.OrderInfoLabel.Text = "Order Information";
            // 
            // OrderItemInfoLabel
            // 
            this.OrderItemInfoLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.OrderItemInfoLabel.AutoSize = true;
            this.OrderItemInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OrderItemInfoLabel.Location = new System.Drawing.Point(75, 501);
            this.OrderItemInfoLabel.Name = "OrderItemInfoLabel";
            this.OrderItemInfoLabel.Size = new System.Drawing.Size(178, 20);
            this.OrderItemInfoLabel.TabIndex = 8;
            this.OrderItemInfoLabel.Text = "Order Items Information";
            // 
            // ShellStockMenu
            // 
            this.ShellStockMenu.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.ShellStockMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stockManageToolStripMenuItem,
            this.toolStripMenuItem1,
            this.exitToolStripMenuItem});
            this.ShellStockMenu.Location = new System.Drawing.Point(0, 0);
            this.ShellStockMenu.Name = "ShellStockMenu";
            this.ShellStockMenu.Size = new System.Drawing.Size(1203, 29);
            this.ShellStockMenu.TabIndex = 11;
            this.ShellStockMenu.Text = "menuStrip1";
            // 
            // stockManageToolStripMenuItem
            // 
            this.stockManageToolStripMenuItem.Name = "stockManageToolStripMenuItem";
            this.stockManageToolStripMenuItem.Size = new System.Drawing.Size(54, 25);
            this.stockManageToolStripMenuItem.Text = "&Back";
            this.stockManageToolStripMenuItem.Click += new System.EventHandler(this.stockManageToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Enabled = false;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(26, 25);
            this.toolStripMenuItem1.Text = "|";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(46, 25);
            this.exitToolStripMenuItem.Text = "&Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // ShellStockLabel
            // 
            this.ShellStockLabel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.ShellStockLabel.AutoSize = true;
            this.ShellStockLabel.BackColor = System.Drawing.Color.Black;
            this.ShellStockLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShellStockLabel.ForeColor = System.Drawing.Color.White;
            this.ShellStockLabel.Location = new System.Drawing.Point(357, 41);
            this.ShellStockLabel.Name = "ShellStockLabel";
            this.ShellStockLabel.Size = new System.Drawing.Size(493, 46);
            this.ShellStockLabel.TabIndex = 12;
            this.ShellStockLabel.Text = "Stock Management & Billing";
            this.ShellStockLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.ShellStockLabel.ClientSizeChanged += new System.EventHandler(this.ShellStockLabel_ClientSizeChanged);
            // 
            // ContextMenuStrip
            // 
            this.ContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteToolStripMenuItem});
            this.ContextMenuStrip.Name = "ContextMenuStrip";
            this.ContextMenuStrip.Size = new System.Drawing.Size(108, 26);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // ShellStockForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(1203, 683);
            this.Controls.Add(this.ShellStockLabel);
            this.Controls.Add(this.ShellStockMenu);
            this.Controls.Add(this.OrderItemInfoLabel);
            this.Controls.Add(this.OrderInfoLabel);
            this.Controls.Add(this.CoustomerItemGridView);
            this.Controls.Add(this.CoustomerDataGridView);
            this.Controls.Add(this.FilterGroupBox);
            this.Controls.Add(this.shapeContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "ShellStockForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Shell Stock";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ShellStockForm_FormClosing);
            this.Load += new System.EventHandler(this.ShellStockForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.CoustomerDataGridView)).EndInit();
            this.FilterGroupBox.ResumeLayout(false);
            this.FilterGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CoustomerItemGridView)).EndInit();
            this.ShellStockMenu.ResumeLayout(false);
            this.ShellStockMenu.PerformLayout();
            this.ContextMenuStrip.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape LogoRectangle;
        private System.Windows.Forms.Label SelectDateLabel;
        private System.Windows.Forms.Label SelectItemLabel;
        private System.Windows.Forms.DataGridView CoustomerDataGridView;
        private System.Windows.Forms.GroupBox FilterGroupBox;
        private System.Windows.Forms.Button SearchButton;
        private System.Windows.Forms.DateTimePicker SelectDate;
        private System.Windows.Forms.TextBox CoustomerNameTextBox;
        private System.Windows.Forms.ComboBox PaymentTypeComboBox;
        private System.Windows.Forms.Label CoustomerNameLabel;
        private System.Windows.Forms.Label PaymentTypeLabe;
        private System.Windows.Forms.ComboBox SelectCompanyComboBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox SelectItemComboBox;
        private System.Windows.Forms.Label SelectCompanyLabel;
        private System.Windows.Forms.DataGridView CoustomerItemGridView;
        private System.Windows.Forms.Label OrderInfoLabel;
        private System.Windows.Forms.Label OrderItemInfoLabel;
        private System.Windows.Forms.MenuStrip ShellStockMenu;
        private System.Windows.Forms.ToolStripMenuItem stockManageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Label ShellStockLabel;
        private System.Windows.Forms.ContextMenuStrip ContextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
    }
}