﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace StockManagementAndBilling
{
    public partial class OrderForm : Form
    {
        OleDbConnection con;
        OleDbCommand cmd;
        OleDbDataReader reader;
        CompanyClass Company;
        private List<CartItem> shopping = new List<CartItem>();
        private int itemNumber = 0;
        private int printItem = 0;
        private int no = 1;
        public OrderForm()
        {
            InitializeComponent();
        }

        private void OrderForm_Load(object sender, EventArgs e)
        {
            CompanySetting();
            //Database Connection
            con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Application.StartupPath + "\\Database/StockManagement.accdb;Persist Security Info=False");
            con.Open();

            // Check Connection, if not then exit in Application
            if (con.State != ConnectionState.Open)
            {
                DialogResult res = MessageBox.Show("Connection fail", "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (res == DialogResult.OK)
                {
                    Application.Exit();
                }
            }
            setdata();
            settex();
            // Set Icon From Buttons
            AddToCartButton.Image = Image.FromFile(Application.StartupPath+"/icons/AddToCart.png");
            NewOrderButton.Image = Image.FromFile(Application.StartupPath + "/icons/Add.png");
            PrintPreviewButton.Image = Image.FromFile(Application.StartupPath + "/icons/Print.png");
            PrintOrderButton.Image = Image.FromFile(Application.StartupPath + "/icons/Print.png");
            CancelOrderButton.Image = Image.FromFile(Application.StartupPath + "/icons/Cancel.png");
            
            //Buttons Enabled True/false
            TransactionDate.Text = DateTime.Now.ToShortDateString();
            enabledtf(false);
            PrintOrderButton.Enabled = false;
            PrintPreviewButton.Enabled = false;
            CancelOrderButton.Enabled = false;
            TotalAmountTextBox.Text = "0";
            TotalToPayTextBox.Text = "0";
            this.WindowState = FormWindowState.Maximized;
        }

        private void settex()
        {
            // set text value in textbox
            try
            {
                cmd = new OleDbCommand("select CGST,SGST,Discount from CompanyInfo where CompanyName = '" + Company.CompanyName.ToString() + "'",con);
                reader = cmd.ExecuteReader();
                reader.Read();
                CgstTextBox.Text = reader["CGST"].ToString();
                SgstTextBox.Text = reader["SGST"].ToString();
                DiscountTextBox.Text = reader["Discount"].ToString();
            }
            catch(Exception expn){
                MessageBox.Show(expn.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }
        }

        private void CompanySetting()
        {
            Company = new CompanyClass();
            LogoLabel.Text = Company.CompanyName.ToString();
            // logo color
            LogoLabel.ForeColor = System.Drawing.ColorTranslator.FromHtml(Company.NameColor.ToString());
            LogoLabel.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.NameBackColor.ToString());
            LogoRectangle.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.NameBackColor.ToString());
            // form color
            this.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.FormBackColor.ToString());
        }

        private void QuantityTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // enter quantity
            if (e.KeyChar >= 48 && e.KeyChar <= 57 || e.KeyChar == 8 || e.KeyChar == 13)
            {
                if(e.KeyChar == 13){
                    AddToCartButton.Focus();
                }
                else{
                    e.Handled = false;
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void CoustomerNameTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // enter coustomer name
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122 || e.KeyChar == 32 || e.KeyChar == 8 || e.KeyChar == 46 || e.KeyChar == 13)
            {
                if(e.KeyChar == 13){
                    ItemsComboBox.Focus();
                }
                else{
                    e.Handled = false;
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void AddToCartButton_Click(object sender, EventArgs e)
        {
            // click addtocart and update data and show data from datagridview and store list<>
            CoustomerNameTextBox.Focus();
            if (Validation())
            {
                try {
                    cmd = new OleDbCommand("select cName from Stock where iName = '"+ItemsComboBox.SelectedItem.ToString()+"' AND cName = '"+ CompanyComboBox.SelectedItem.ToString() +"'",con);
                    reader = cmd.ExecuteReader();
                    reader.Read();
                }
                catch(Exception exc){
                    MessageBox.Show(exc.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                    return;
                }
                CartItem item = new CartItem()
                {
                    ItemName = ItemsComboBox.SelectedItem.ToString(),
                    Company = reader["cName"].ToString(),
                    UnitPrice = Convert.ToDecimal(PriceTextBox.Text.Trim()),
                    Quantity = Convert.ToInt16(QuantityTextBox.Text.Trim()),
                    TotalPrice = Convert.ToDecimal(PriceTextBox.Text.Trim()) * Convert.ToInt16(QuantityTextBox.Text.Trim())
                };
                shopping.Add(item);
                setgridview();
                AddData(item.ItemName.ToString(),item.Quantity.ToString(),true);
            }
            else {
                return;
            }
            ItemsComboBox.SelectedIndex = -1;
            CompanyComboBox.Items.Clear();
            QuantityTextBox.Text = "";
            ItemsComboBox.Focus();
            PriceTextBox.Text = "";
            CurrentStockTextBox.Text = "";
            setdata();
            CompanyComboBox.SelectedIndexChanged -= new EventHandler(CompanyComboBox_SelectedIndexChanged);
            CompanyComboBox.SelectedIndex = -1;
            CompanyComboBox.SelectedIndexChanged += new EventHandler(CompanyComboBox_SelectedIndexChanged);
        }

        private void AddData(String Name,String Qtity,Boolean tf) {
            // update data from database
            // when cancel order, application close, delete item

            try
            {
                cmd = new OleDbCommand("select iQuentity from Stock where iName = '"+Name+"'",con);
                reader = cmd.ExecuteReader();
                reader.Read();
                int qty = Convert.ToInt16(reader["iQuentity"].ToString());
                int quty = Convert.ToInt16(Qtity);
                int qt;
                if (tf)
                {
                    qt = qty - quty;
                }
                else
                {
                    qt = qty + quty;
                }
                cmd = new OleDbCommand();
                cmd.Connection = con;
                cmd.CommandText = "update Stock set iQuentity = '"+qt+"' where iName = '"+Name+"'";
                cmd.ExecuteNonQuery();
            }
            catch(Exception ex){
                MessageBox.Show(ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }    
        }

        private void setgridview() {
            ItemsGridView.DataSource = null;
            ItemsGridView.DataSource = shopping;

            decimal TotalAmount = shopping.Sum(x => x.TotalPrice);
            int sgst = Convert.ToInt16(SgstTextBox.Text.Trim());
            int cgst = Convert.ToInt16(CgstTextBox.Text.Trim());
            int gst = sgst + cgst;
            TotalAmountTextBox.Text = TotalAmount.ToString();
            decimal gstamount = ((TotalAmount * gst) / 100) + TotalAmount;

            if (DiscountTextBox.Text.Trim() != "0")
            {
                TotalToPayTextBox.Text = Convert.ToString(gstamount - ((Convert.ToInt16(DiscountTextBox.Text.Trim()) * gstamount) / 100));
            }
            else
            {
                TotalToPayTextBox.Text = gstamount.ToString();
            }
        }

        private bool Validation()
        {
            // textbox validation
            if(CoustomerNameTextBox.Text.Trim() == ""){
                MessageBox.Show("Enter Coustomer Name","Enter Name",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                CoustomerNameTextBox.Focus();
                return false;
            }
            if(ItemsComboBox.SelectedIndex == -1){
                MessageBox.Show("Select Item  Name", "Select Item", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ItemsComboBox.Focus();
                return false;
            }
            if (QuantityTextBox.Text.Trim() == "")
            {
                MessageBox.Show("Enter Item Quantity", "Enter Quantity", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                QuantityTextBox.Focus();
                return false;
            }
            else {
                decimal ts = Convert.ToInt16(QuantityTextBox.Text.Trim());
                decimal cs = Convert.ToInt16(CurrentStockTextBox.Text.Trim());
                if(ts > cs){
                    MessageBox.Show("Enter Item Quantity Less then Current Stock","Enter Quantity",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                    return false;
                }
            }
            return true;
        }

        private void enabledtf(Boolean tf) {
            //TextBox enabled true / false
            CoustomerNameTextBox.Enabled = tf;
            ItemsComboBox.Enabled = tf;
            QuantityTextBox.Enabled = tf;
            PaymentComboBox.Enabled = tf;
            AddToCartButton.Enabled = tf;
            CompanyComboBox.Enabled = tf;
        }

        private void NewOrderButton_Click(object sender, EventArgs e)
        {
            // enabeld true / false
            enabledtf(true);
            CancelOrderButton.Enabled = true;
            NewOrderButton.Enabled = false;
            PrintPreviewButton.Enabled = true;
            PrintOrderButton.Enabled = true;
            CoustomerNameTextBox.Focus();
            OrderNumber();
        }

        
        private void CancelOrderButton_Click(object sender, EventArgs e)
        {
            // click on cancle order and button and textbox enable true / false and update data from database on adddata method
            foreach (DataGridViewRow ro in ItemsGridView.Rows)
            {
                AddData(ro.Cells[0].Value.ToString(), ro.Cells[3].Value.ToString(), false);
            }
            ItemsGridView.DataSource = null;
            shopping.Clear();
            enabledtf(false);
            CoustomerNameTextBox.Text = "";
            OrderNumberTextBox.Text = "";
            PaymentComboBox.SelectedIndex = -1;
            PaymentComboBox.Enabled = false;
            ItemsComboBox.SelectedIndex = -1;
            CompanyComboBox.SelectedIndex = -1;
            CompanyComboBox.Items.Clear();
            ItemsComboBox.Enabled = false;
            QuantityTextBox.Text = "";
            CurrentStockTextBox.Text = "";
            TotalAmountTextBox.Text = "0";
            TotalToPayTextBox.Text = "0";
            CancelOrderButton.Enabled = false;
            NewOrderButton.Enabled = true;
            PrintOrderButton.Enabled = false;
            PrintPreviewButton.Enabled = false;
            PriceTextBox.Text = "";
            
        }

        private void ItemsComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            // select item and set price and quantity
            if (ItemsComboBox.SelectedIndex != -1)
            {
                CurrentStockTextBox.Text = "";
                PriceTextBox.Text = "";
                CompanyComboBox.Items.Clear();
                try {
                    cmd = new OleDbCommand("select cName from Stock where iName = '"+ItemsComboBox.SelectedItem.ToString()+"'",con);
                    reader = cmd.ExecuteReader();
                    while(reader.Read()){
                        CompanyComboBox.Items.Add(reader["cName"].ToString());
                    }
                }
                catch(Exception expn){
                    MessageBox.Show(expn.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                    return;
                }
                CompanyComboBox.SelectedIndex = 0;
            }
        }

        private void CompanyComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
            cmd = new OleDbCommand("select * from Stock where iName = '"+ ItemsComboBox.SelectedItem.ToString() +"' AND cName = '"+ CompanyComboBox.SelectedItem.ToString() +"'", con);
                reader = cmd.ExecuteReader();

                reader.Read();

                PriceTextBox.Text = reader["iPrice"].ToString();
                CurrentStockTextBox.Text = reader["iQuentity"].ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            QuantityTextBox.Focus();
        }

        private void OrderNumber() {
            // call function of check order number exist or not
            String ON;
            bool IsExist = true;
            while(IsExist){
                ON = GenerateNumber();
                IsExist = CheckNumber(ON);
                OrderNumberTextBox.Text = ON;
            }
        }
        private String GenerateNumber() {
            // generate order number and return order number
            Random r = new Random();
            long Number1 = r.Next(10000, 99999);
            long Number2 = r.Next(10000, 99999);
            Char ch1 = (Char)r.Next('A', 'Z');
            Char ch2 = (Char)r.Next('A', 'Z');

            return ch1 + "" + ch2 + "-" + Number1 + "-" + Number2;
        }
        private bool CheckNumber( String ON) {
            // check order number in database exist or not
            bool IsExist = false;
            try
            {
                cmd = new OleDbCommand("select OrderNumber from OrderInfo where OrderNumber = '" + ON + "'", con);
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    if (reader["OrderNumber"].ToString() == ON)
                    {
                        IsExist = true;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return IsExist;
        }
        private void setdata() {
            // set data in item combobox
            ItemsComboBox.Items.Clear();
            try {
                cmd = new OleDbCommand("select Distinct iName from Stock where iQuentity not in('0')",con);
                reader = cmd.ExecuteReader();
                
                while(reader.Read()){
                    ItemsComboBox.Items.Add(reader["iName"].ToString());
                }
            }
            catch(Exception ex){
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // (toolstripmenu) delete data from datagridview and update data from database
            int index = ItemsGridView.CurrentCell.RowIndex;
            String Name = ItemsGridView.Rows[index].Cells[0].Value.ToString();
            String qty = ItemsGridView.Rows[index].Cells[3].Value.ToString();
            AddData(Name,qty,false);
            shopping.RemoveAt(index);
            setgridview();
            ItemsComboBox.SelectedIndex = -1;
            PriceTextBox.Text = "";
            CurrentStockTextBox.Text = "";
        }

        private void ItemsGridView_MouseDown(object sender, MouseEventArgs e)
        {
            // show toolstrip menu
            if (shopping.Count != 0)
            {
                if (e.Button == System.Windows.Forms.MouseButtons.Right)
                {
                    var ht = ItemsGridView.HitTest(e.X, e.Y);
                    ItemsGridView.Rows[ht.RowIndex].Selected = true;
                    ContextMenuStrip.Show(ItemsGridView, e.X, e.Y);
                }
            }
        }

        private void PrintPreviewButton_Click(object sender, EventArgs e)
        {
            // click print preview button and show bill
            if(shopping.Count <= 0){
                MessageBox.Show("Item Is Empty, Select 1 OR More then Items","Choose Item",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return;
            }
            if (PaymentComboBox.SelectedIndex == -1)
            {
                MessageBox.Show("Please Select Payment Type", "Select Payment Type", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            PrintPreviewDialog.Document = PrintDocument;
            PrintPreviewDialog.ShowDialog();
        }

        private void PrintOrderButton_Click(object sender, EventArgs e)
        {
            // click print order button and print order 
            if (shopping.Count <= 0)
            {
                MessageBox.Show("Item Is Empty, Select 1 OR More then Items", "Choose Item", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if(PaymentComboBox.SelectedIndex == -1){
                MessageBox.Show("Please Select Payment Type","Select Payment Type",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return;
            }
            // transaction for insert order data
            // transaction null
            OleDbTransaction trans = null;
            try {
                // transaction start
                trans = con.BeginTransaction();
                decimal gst = (Convert.ToDecimal(TotalAmountTextBox.Text) * (Convert.ToInt16(CgstTextBox.Text) + Convert.ToInt16(SgstTextBox.Text))) / 100;
                // insert order information in database
                cmd = new OleDbCommand("insert into OrderInfo(OrderNumber,CoustomerName,TransactionDate,PaymentType,CGST,SGST,Discount,TotalAmount,TotalGst,TotalToPay,SalesBy) values('"+OrderNumberTextBox.Text+"','"+CoustomerNameTextBox.Text+"','"+TransactionDate.Text+"','"+PaymentComboBox.SelectedItem.ToString()+"','"+Convert.ToInt16(CgstTextBox.Text)+"','"+Convert.ToInt16(SgstTextBox.Text)+"','"+Convert.ToInt16(DiscountTextBox.Text)+"','"+Convert.ToDecimal(TotalAmountTextBox.Text)+"','"+gst+"','"+Convert.ToDecimal(TotalToPayTextBox.Text)+"','"+ UserClass.UserName.ToString() +"')",con);
                cmd.Transaction = trans;
                cmd.ExecuteNonQuery();
                
                foreach(DataGridViewRow row in ItemsGridView.Rows){
                    // insert order items in database
                    cmd = new OleDbCommand("insert into OrderItems(OrderNumbers,ItemName,Quantity,UnitPrice,TotalPrice,Company) values('"+OrderNumberTextBox.Text+"','"+row.Cells[0].Value.ToString()+"','"+row.Cells[3].Value+"','"+Convert.ToDecimal(row.Cells[2].Value.ToString())+"','"+Convert.ToDecimal(row.Cells[4].Value.ToString())+"','"+row.Cells[1].Value+"')",con);
                    cmd.Transaction = trans;
                    cmd.ExecuteNonQuery();
                }
                // save transaction
                trans.Commit();
            }
            catch(Exception ex){
                // transaction rollback and no store data from database
                trans.Rollback();
                // update data from data base
                foreach(DataGridViewRow rows in ItemsGridView.Rows){
                    AddData(rows.Cells[0].Value.ToString(),rows.Cells[3].Value.ToString(),false);
                }
                // gridview empty
                ItemsGridView.DataSource = null;
                // list<> empty
                shopping.Clear();
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                // textbox clear and button enable false
                OrderNumberTextBox.Text = "";
                CoustomerNameTextBox.Text = "";
                PaymentComboBox.SelectedIndex = -1;
                enabledtf(false);
                ItemsComboBox.SelectedIndex = -1;
                PriceTextBox.Text = "";
                CurrentStockTextBox.Text = "";
                TotalAmountTextBox.Text = "0";
                TotalToPayTextBox.Text = "0";
                NewOrderButton.Enabled = true;
                PrintPreviewButton.Enabled = false;
                PrintOrderButton.Enabled = false;
                CancelOrderButton.Enabled = false;
                PaymentComboBox.SelectedIndex = -1;
                return;
            }
            
            PrintDocument.Print();
            enabledtf(false);
            CoustomerNameTextBox.Text = "";
            OrderNumberTextBox.Text = "";
            CancelOrderButton.Enabled = false;
            NewOrderButton.Enabled = true;
            PrintPreviewButton.Enabled = false;
            PrintOrderButton.Enabled = false;
            shopping.Clear();
            ItemsGridView.DataSource = null;
            TotalAmountTextBox.Text = "0";
            TotalToPayTextBox.Text = "0";
            PaymentComboBox.SelectedIndex = -1;
        }


        private void PrintDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            // print document print order

            StringFormat sformat = new StringFormat();
            sformat.Alignment = StringAlignment.Center;
            // Company Name
            e.Graphics.DrawString(Company.CompanyName.ToString(), new Font("Arial", 35, FontStyle.Bold), Brushes.Black, new Point(400,10),sformat);
            //Company Address
            e.Graphics.DrawString("Address: "+ Company.CAddress.ToString(), new Font("Arial",15,FontStyle.Italic), Brushes.Black, new Point(400,65),sformat);
            //Company Mobile
            e.Graphics.DrawString("Mobile: "+Company.CMobile, new Font("Arial", 15, FontStyle.Italic), Brushes.Black, new Point(400,85),sformat);
            //Company Email
            e.Graphics.DrawString("Email: "+Company.CEmail, new Font("Arial", 15, FontStyle.Italic), Brushes.Black, new Point(400,105),sformat);
            //GST Number
            e.Graphics.DrawString("GST Number: "+Company.GSTNUMBER, new Font("Arial", 15, FontStyle.Italic), Brushes.Black, new Point(400,125),sformat);
            // Date
            e.Graphics.DrawString("Date: "+DateTime.Now.ToShortDateString(), new Font("Arial",15,FontStyle.Regular),Brushes.Black,new Point(25,160));
            // Sales By Name
            e.Graphics.DrawString("Sales By: " + UserClass.UserName.ToString(), new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(405, 160)); 
            // Client Name
            e.Graphics.DrawString("Client Name: "+CoustomerNameTextBox.Text.Trim(), new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(25, 190));
            if(PaymentComboBox.SelectedItem.ToString() == "Unpaid"){
            // Unpaid Order
            e.Graphics.DrawString("Order Unpaid", new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(405, 190));
            }
            // ------
            e.Graphics.DrawString("------------------------------------------------------------------------------------------------------------------", new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(25, 235));
            // Item Header
            e.Graphics.DrawString("Sr", new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(30, 255));
            e.Graphics.DrawString("Item Name", new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(70, 255));
            e.Graphics.DrawString("Quantity:", new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(405, 255));
            e.Graphics.DrawString("Unit Price:", new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(535, 255));
            e.Graphics.DrawString("Total Price", new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(680, 255));
            // ------
            e.Graphics.DrawString("------------------------------------------------------------------------------------------------------------------", new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(25, 270));
            int pos = 295;
            // items
            for (int i = printItem; i < shopping.Count; i++ )
            {
                itemNumber++;
                if(itemNumber <= 20){
                    printItem++;
                    if (printItem <= shopping.Count)
                    {
                        e.Graphics.DrawString(no.ToString(), new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(30, pos));
                        e.Graphics.DrawString(shopping[i].ItemName.ToString(), new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(70, pos));
                        e.Graphics.DrawString(shopping[i].Quantity.ToString(), new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(420, pos));
                        e.Graphics.DrawString(shopping[i].UnitPrice.ToString(), new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(545, pos));
                        e.Graphics.DrawString(shopping[i].TotalPrice.ToString(), new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(680, pos));

                        pos += 30;
                        no++;
                    }
                    else {
                        e.HasMorePages = false;
                    }
                }
                else{
                    e.Graphics.DrawString("------------------------------------------------------------------------------------------------------------------", new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(25, pos));
                    pos += 30;
            
                    itemNumber = 0;
                    e.HasMorePages = true;
                    return;
                }
            }
            pos -= 5;
            // ------
            e.Graphics.DrawString("------------------------------------------------------------------------------------------------------------------", new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(25,pos));
            // total
            pos += 25;
            e.Graphics.DrawString("Total", new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(70, pos));
            e.Graphics.DrawString(shopping.Sum(y => y.Quantity).ToString(), new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(420, pos));
            e.Graphics.DrawString(shopping.Sum(x => x.TotalPrice).ToString(), new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(680, pos));
            pos += 20;
            e.Graphics.DrawString("------------------------------------------------------------------------------------------------------------------", new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(25, pos));
            decimal price = shopping.Sum(x => x.TotalPrice);
            int cgst = Convert.ToInt16(CgstTextBox.Text);
            int sgst = Convert.ToInt16(SgstTextBox.Text);
            decimal CGST = (price * cgst) / 100;
            decimal SGST = (price * sgst) / 100;
            pos += 30;
            // cgst
            e.Graphics.DrawString("CGST "+CgstTextBox.Text+"%", new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(405, pos));
            e.Graphics.DrawString(CGST.ToString(), new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(680, pos));
            pos += 30;
            // sgst
            e.Graphics.DrawString("SGST "+SgstTextBox.Text+"%", new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(405, pos));
            e.Graphics.DrawString(SGST.ToString(), new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(680, pos));
            pos += 30;
            // total
            e.Graphics.DrawString("Total", new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(405, pos));
            e.Graphics.DrawString((price + CGST + SGST).ToString(), new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(680, pos));
            
            pos += 35;
            // discount
            int discount = Convert.ToInt16(DiscountTextBox.Text);
            decimal DISCOUNT = ((price + CGST +SGST) * discount) / 100;
            e.Graphics.DrawString("Discount "+DiscountTextBox.Text+"%", new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(405, pos));
            e.Graphics.DrawString(DISCOUNT.ToString(), new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(680, pos));
            pos += 30;
            // total to pay
            e.Graphics.DrawString("Total To Pay", new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(405, pos));
            e.Graphics.DrawString(((price + CGST + SGST ) - DISCOUNT).ToString(), new Font("Arial", 15, FontStyle.Bold), Brushes.Black, new Point(680, pos));
            itemNumber = 0;
            printItem = 0;
            no = 1;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void OrderForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            // if form close and order item update from database
            foreach (DataGridViewRow rin in ItemsGridView.Rows)
            {
                AddData(rin.Cells[0].Value.ToString(), rin.Cells[3].Value.ToString(), false);
            }
            Application.Exit();
        }

        private void searchItemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // show search item form 
            SearchItemForm SIF = new SearchItemForm();
            SIF.ShowDialog();
        }

        private void unpaidOrderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // show unpaid orderform
            UnpaidOrder UO = new UnpaidOrder();
            UO.ShowDialog();
        }

        private void exitToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void LogoLabel_ClientSizeChanged(object sender, EventArgs e)
        {
            LogoLabel.Left = (this.ClientSize.Width - LogoLabel.Size.Width) / 2;
        }


    }
}
