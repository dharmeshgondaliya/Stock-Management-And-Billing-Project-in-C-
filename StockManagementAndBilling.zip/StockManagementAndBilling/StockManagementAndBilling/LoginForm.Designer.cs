﻿namespace StockManagementAndBilling
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LoginLogoLabel = new System.Windows.Forms.Label();
            this.LoginLabel = new System.Windows.Forms.Label();
            this.LoginGroupBox = new System.Windows.Forms.GroupBox();
            this.PasswordPictureBox = new System.Windows.Forms.PictureBox();
            this.UserIdPictureBox = new System.Windows.Forms.PictureBox();
            this.LoginButton = new System.Windows.Forms.Button();
            this.UserComboBox = new System.Windows.Forms.ComboBox();
            this.PasswordTextbox = new System.Windows.Forms.TextBox();
            this.SelectUserLabel = new System.Windows.Forms.Label();
            this.PasswordLabel = new System.Windows.Forms.Label();
            this.UserIdTextBox = new System.Windows.Forms.TextBox();
            this.UserIdLabel = new System.Windows.Forms.Label();
            this.LoginGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PasswordPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.UserIdPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // LoginLogoLabel
            // 
            this.LoginLogoLabel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.LoginLogoLabel.AutoSize = true;
            this.LoginLogoLabel.BackColor = System.Drawing.Color.LightSteelBlue;
            this.LoginLogoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LoginLogoLabel.Location = new System.Drawing.Point(118, 32);
            this.LoginLogoLabel.Name = "LoginLogoLabel";
            this.LoginLogoLabel.Size = new System.Drawing.Size(490, 39);
            this.LoginLogoLabel.TabIndex = 4;
            this.LoginLogoLabel.Text = "Stock Management And  Billing";
            this.LoginLogoLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.LoginLogoLabel.ClientSizeChanged += new System.EventHandler(this.LoginLogoLabel_ClientSizeChanged);
            // 
            // LoginLabel
            // 
            this.LoginLabel.AutoSize = true;
            this.LoginLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LoginLabel.Location = new System.Drawing.Point(240, 19);
            this.LoginLabel.Name = "LoginLabel";
            this.LoginLabel.Size = new System.Drawing.Size(80, 31);
            this.LoginLabel.TabIndex = 0;
            this.LoginLabel.Text = "Login";
            // 
            // LoginGroupBox
            // 
            this.LoginGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LoginGroupBox.Controls.Add(this.PasswordPictureBox);
            this.LoginGroupBox.Controls.Add(this.UserIdPictureBox);
            this.LoginGroupBox.Controls.Add(this.LoginButton);
            this.LoginGroupBox.Controls.Add(this.UserComboBox);
            this.LoginGroupBox.Controls.Add(this.PasswordTextbox);
            this.LoginGroupBox.Controls.Add(this.SelectUserLabel);
            this.LoginGroupBox.Controls.Add(this.PasswordLabel);
            this.LoginGroupBox.Controls.Add(this.UserIdTextBox);
            this.LoginGroupBox.Controls.Add(this.LoginLabel);
            this.LoginGroupBox.Controls.Add(this.UserIdLabel);
            this.LoginGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LoginGroupBox.Location = new System.Drawing.Point(90, 114);
            this.LoginGroupBox.Name = "LoginGroupBox";
            this.LoginGroupBox.Size = new System.Drawing.Size(561, 327);
            this.LoginGroupBox.TabIndex = 3;
            this.LoginGroupBox.TabStop = false;
            // 
            // PasswordPictureBox
            // 
            this.PasswordPictureBox.BackColor = System.Drawing.SystemColors.Window;
            this.PasswordPictureBox.Location = new System.Drawing.Point(225, 139);
            this.PasswordPictureBox.Name = "PasswordPictureBox";
            this.PasswordPictureBox.Size = new System.Drawing.Size(40, 30);
            this.PasswordPictureBox.TabIndex = 5;
            this.PasswordPictureBox.TabStop = false;
            // 
            // UserIdPictureBox
            // 
            this.UserIdPictureBox.BackColor = System.Drawing.SystemColors.Window;
            this.UserIdPictureBox.Location = new System.Drawing.Point(225, 85);
            this.UserIdPictureBox.Name = "UserIdPictureBox";
            this.UserIdPictureBox.Size = new System.Drawing.Size(45, 30);
            this.UserIdPictureBox.TabIndex = 4;
            this.UserIdPictureBox.TabStop = false;
            // 
            // LoginButton
            // 
            this.LoginButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LoginButton.Location = new System.Drawing.Point(223, 248);
            this.LoginButton.Name = "LoginButton";
            this.LoginButton.Size = new System.Drawing.Size(153, 46);
            this.LoginButton.TabIndex = 3;
            this.LoginButton.Text = "  Login";
            this.LoginButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.LoginButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.LoginButton.UseVisualStyleBackColor = true;
            this.LoginButton.Click += new System.EventHandler(this.LoginButton_Click);
            // 
            // UserComboBox
            // 
            this.UserComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.UserComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserComboBox.FormattingEnabled = true;
            this.UserComboBox.Items.AddRange(new object[] {
            "Admin",
            "User"});
            this.UserComboBox.Location = new System.Drawing.Point(223, 192);
            this.UserComboBox.Name = "UserComboBox";
            this.UserComboBox.Size = new System.Drawing.Size(263, 33);
            this.UserComboBox.TabIndex = 2;
            this.UserComboBox.SelectedIndexChanged += new System.EventHandler(this.UserComboBox_SelectedIndexChanged);
            // 
            // PasswordTextbox
            // 
            this.PasswordTextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PasswordTextbox.Location = new System.Drawing.Point(223, 138);
            this.PasswordTextbox.Name = "PasswordTextbox";
            this.PasswordTextbox.PasswordChar = '*';
            this.PasswordTextbox.Size = new System.Drawing.Size(263, 33);
            this.PasswordTextbox.TabIndex = 1;
            this.PasswordTextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.PasswordTextbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.PasswordTextbox_KeyPress);
            // 
            // SelectUserLabel
            // 
            this.SelectUserLabel.AutoSize = true;
            this.SelectUserLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectUserLabel.Location = new System.Drawing.Point(62, 192);
            this.SelectUserLabel.Name = "SelectUserLabel";
            this.SelectUserLabel.Size = new System.Drawing.Size(113, 25);
            this.SelectUserLabel.TabIndex = 0;
            this.SelectUserLabel.Text = "Select User";
            // 
            // PasswordLabel
            // 
            this.PasswordLabel.AutoSize = true;
            this.PasswordLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PasswordLabel.Location = new System.Drawing.Point(62, 138);
            this.PasswordLabel.Name = "PasswordLabel";
            this.PasswordLabel.Size = new System.Drawing.Size(149, 25);
            this.PasswordLabel.TabIndex = 0;
            this.PasswordLabel.Text = "Enter Password";
            // 
            // UserIdTextBox
            // 
            this.UserIdTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserIdTextBox.Location = new System.Drawing.Point(223, 83);
            this.UserIdTextBox.Name = "UserIdTextBox";
            this.UserIdTextBox.Size = new System.Drawing.Size(263, 33);
            this.UserIdTextBox.TabIndex = 0;
            this.UserIdTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.UserIdTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.UserIdTextBox_KeyPress);
            // 
            // UserIdLabel
            // 
            this.UserIdLabel.AutoSize = true;
            this.UserIdLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserIdLabel.Location = new System.Drawing.Point(62, 86);
            this.UserIdLabel.Name = "UserIdLabel";
            this.UserIdLabel.Size = new System.Drawing.Size(125, 25);
            this.UserIdLabel.TabIndex = 0;
            this.UserIdLabel.Text = "Enter User Id";
            // 
            // LoginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(726, 479);
            this.Controls.Add(this.LoginLogoLabel);
            this.Controls.Add(this.LoginGroupBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "LoginForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.LoginForm_FormClosing);
            this.Load += new System.EventHandler(this.LoginForm_Load);
            this.LoginGroupBox.ResumeLayout(false);
            this.LoginGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PasswordPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.UserIdPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LoginLogoLabel;
        private System.Windows.Forms.Label LoginLabel;
        private System.Windows.Forms.GroupBox LoginGroupBox;
        private System.Windows.Forms.Button LoginButton;
        private System.Windows.Forms.ComboBox UserComboBox;
        private System.Windows.Forms.TextBox PasswordTextbox;
        private System.Windows.Forms.Label SelectUserLabel;
        private System.Windows.Forms.Label PasswordLabel;
        private System.Windows.Forms.TextBox UserIdTextBox;
        private System.Windows.Forms.Label UserIdLabel;
        private System.Windows.Forms.PictureBox UserIdPictureBox;
        private System.Windows.Forms.PictureBox PasswordPictureBox;
    }
}