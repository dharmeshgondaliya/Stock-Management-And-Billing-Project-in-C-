﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace StockManagementAndBilling
{
    class CompanyClass
    {
        OleDbConnection con;
        OleDbCommand cmd;
        OleDbDataReader reader;
        public String CompanyName;
        public String CAddress,CMobile,CEmail,GSTNUMBER;
        public String NameColor, NameBackColor, FormBackColor, FontColor, TextboxFontColor, TextboxBackColor, ButtonFontColor, ButtonBackColor;
        public CompanyClass() {
            //Database Connection
            con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Application.StartupPath + "\\Database/StockManagement.accdb;Persist Security Info=False");
            con.Open();

            // Check Connection, if not then exit in Application
            if (con.State != ConnectionState.Open)
            {
                DialogResult res = MessageBox.Show("Connection fail", "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (res == DialogResult.OK)
                {
                    Application.Exit();
                }
            }
            try
            {
                // select company info data and store variable
                cmd = new OleDbCommand("select CompanyName,MobileNumber,Email,CompanyAddress,GSTNumber from CompanyInfo",con);
                reader = cmd.ExecuteReader();
                reader.Read();
                CompanyName = reader["CompanyName"].ToString();
                CAddress = reader["CompanyAddress"].ToString();
                CEmail = reader["Email"].ToString();
                CMobile = reader["MobileNumber"].ToString();
                GSTNUMBER = reader["GSTNumber"].ToString();
                // select color data and store variable
                cmd = new OleDbCommand("select * from Colors",con);
                reader = cmd.ExecuteReader();
                reader.Read();
                NameColor = reader["NameColor"].ToString();
                NameBackColor = reader["NameBackColor"].ToString();
                FormBackColor = reader["FormBackColor"].ToString();
            }
            catch(Exception excep)
            {
                MessageBox.Show(excep.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }
        }
    }
}
