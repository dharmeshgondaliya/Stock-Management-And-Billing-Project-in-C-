﻿namespace StockManagementAndBilling
{
    partial class CompanySettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CompanySettingGroupBox = new System.Windows.Forms.GroupBox();
            this.EditeButton = new System.Windows.Forms.Button();
            this.CompanySettingLabel = new System.Windows.Forms.Label();
            this.SaveCompanySetting = new System.Windows.Forms.Button();
            this.AddressTextBox = new System.Windows.Forms.TextBox();
            this.DiscountTextBox = new System.Windows.Forms.TextBox();
            this.SgstTextBox = new System.Windows.Forms.TextBox();
            this.CgstTextBox = new System.Windows.Forms.TextBox();
            this.GstNumberTextBox = new System.Windows.Forms.TextBox();
            this.MobileNumberTextBox = new System.Windows.Forms.TextBox();
            this.EmailIdTextBox = new System.Windows.Forms.TextBox();
            this.CompanyNameTextBox = new System.Windows.Forms.TextBox();
            this.ColorSettingGroupBox = new System.Windows.Forms.GroupBox();
            this.ChangeFormBackColor = new System.Windows.Forms.Button();
            this.ChangeComNameColor = new System.Windows.Forms.Button();
            this.ChangeComBackColor = new System.Windows.Forms.Button();
            this.ColorSettingLabel = new System.Windows.Forms.Label();
            this.LogoRectangle = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.AvailabelStockLabel = new System.Windows.Forms.Label();
            this.CompanySettingsLabel = new System.Windows.Forms.Label();
            this.ColorSettingsLabel = new System.Windows.Forms.Label();
            this.StockManageMenu = new System.Windows.Forms.MenuStrip();
            this.stockManageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CompanySettingGroupBox.SuspendLayout();
            this.ColorSettingGroupBox.SuspendLayout();
            this.StockManageMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // CompanySettingGroupBox
            // 
            this.CompanySettingGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.CompanySettingGroupBox.Controls.Add(this.EditeButton);
            this.CompanySettingGroupBox.Controls.Add(this.CompanySettingLabel);
            this.CompanySettingGroupBox.Controls.Add(this.SaveCompanySetting);
            this.CompanySettingGroupBox.Controls.Add(this.AddressTextBox);
            this.CompanySettingGroupBox.Controls.Add(this.DiscountTextBox);
            this.CompanySettingGroupBox.Controls.Add(this.SgstTextBox);
            this.CompanySettingGroupBox.Controls.Add(this.CgstTextBox);
            this.CompanySettingGroupBox.Controls.Add(this.GstNumberTextBox);
            this.CompanySettingGroupBox.Controls.Add(this.MobileNumberTextBox);
            this.CompanySettingGroupBox.Controls.Add(this.EmailIdTextBox);
            this.CompanySettingGroupBox.Controls.Add(this.CompanyNameTextBox);
            this.CompanySettingGroupBox.Location = new System.Drawing.Point(30, 137);
            this.CompanySettingGroupBox.Name = "CompanySettingGroupBox";
            this.CompanySettingGroupBox.Size = new System.Drawing.Size(586, 554);
            this.CompanySettingGroupBox.TabIndex = 0;
            this.CompanySettingGroupBox.TabStop = false;
            // 
            // EditeButton
            // 
            this.EditeButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EditeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EditeButton.Location = new System.Drawing.Point(74, 501);
            this.EditeButton.Name = "EditeButton";
            this.EditeButton.Size = new System.Drawing.Size(140, 40);
            this.EditeButton.TabIndex = 9;
            this.EditeButton.Text = "Edit";
            this.EditeButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.EditeButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.EditeButton.UseVisualStyleBackColor = true;
            this.EditeButton.Click += new System.EventHandler(this.EditeButton_Click);
            // 
            // CompanySettingLabel
            // 
            this.CompanySettingLabel.AutoSize = true;
            this.CompanySettingLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CompanySettingLabel.Location = new System.Drawing.Point(75, 41);
            this.CompanySettingLabel.Name = "CompanySettingLabel";
            this.CompanySettingLabel.Size = new System.Drawing.Size(139, 440);
            this.CompanySettingLabel.TabIndex = 3;
            this.CompanySettingLabel.Text = "Company Name\r\n\r\n\r\nMobile Number\r\n\r\n\r\nEmail ID\r\n\r\n\r\nCompany Address\r\n\r\n\r\nGST Numbe" +
    "r\r\n\r\n\r\nCGST\r\n\r\n\r\nSGST\r\n\r\n\r\nDiscount";
            // 
            // SaveCompanySetting
            // 
            this.SaveCompanySetting.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaveCompanySetting.Location = new System.Drawing.Point(237, 495);
            this.SaveCompanySetting.Name = "SaveCompanySetting";
            this.SaveCompanySetting.Size = new System.Drawing.Size(254, 40);
            this.SaveCompanySetting.TabIndex = 8;
            this.SaveCompanySetting.Text = "Save";
            this.SaveCompanySetting.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.SaveCompanySetting.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.SaveCompanySetting.UseVisualStyleBackColor = true;
            this.SaveCompanySetting.Click += new System.EventHandler(this.SaveCompanySetting_Click);
            // 
            // AddressTextBox
            // 
            this.AddressTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddressTextBox.Location = new System.Drawing.Point(237, 205);
            this.AddressTextBox.Multiline = true;
            this.AddressTextBox.Name = "AddressTextBox";
            this.AddressTextBox.Size = new System.Drawing.Size(254, 57);
            this.AddressTextBox.TabIndex = 3;
            this.AddressTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.AddressTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.AddressTextBox_KeyPress);
            // 
            // DiscountTextBox
            // 
            this.DiscountTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DiscountTextBox.Location = new System.Drawing.Point(237, 455);
            this.DiscountTextBox.Name = "DiscountTextBox";
            this.DiscountTextBox.Size = new System.Drawing.Size(254, 26);
            this.DiscountTextBox.TabIndex = 7;
            this.DiscountTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.DiscountTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DiscountTextBox_KeyPress);
            // 
            // SgstTextBox
            // 
            this.SgstTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SgstTextBox.Location = new System.Drawing.Point(237, 397);
            this.SgstTextBox.Name = "SgstTextBox";
            this.SgstTextBox.Size = new System.Drawing.Size(254, 26);
            this.SgstTextBox.TabIndex = 6;
            this.SgstTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.SgstTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.GST_Keypress);
            // 
            // CgstTextBox
            // 
            this.CgstTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CgstTextBox.Location = new System.Drawing.Point(237, 338);
            this.CgstTextBox.Name = "CgstTextBox";
            this.CgstTextBox.Size = new System.Drawing.Size(254, 26);
            this.CgstTextBox.TabIndex = 5;
            this.CgstTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.CgstTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.GST_Keypress);
            // 
            // GstNumberTextBox
            // 
            this.GstNumberTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GstNumberTextBox.Location = new System.Drawing.Point(237, 283);
            this.GstNumberTextBox.Name = "GstNumberTextBox";
            this.GstNumberTextBox.Size = new System.Drawing.Size(254, 26);
            this.GstNumberTextBox.TabIndex = 4;
            this.GstNumberTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.GstNumberTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.GstNumberTextBox_KeyPress);
            // 
            // MobileNumberTextBox
            // 
            this.MobileNumberTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MobileNumberTextBox.Location = new System.Drawing.Point(237, 98);
            this.MobileNumberTextBox.MaxLength = 10;
            this.MobileNumberTextBox.Name = "MobileNumberTextBox";
            this.MobileNumberTextBox.Size = new System.Drawing.Size(254, 26);
            this.MobileNumberTextBox.TabIndex = 1;
            this.MobileNumberTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.MobileNumberTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MobileNumberTextBox_KeyPress);
            // 
            // EmailIdTextBox
            // 
            this.EmailIdTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmailIdTextBox.Location = new System.Drawing.Point(237, 158);
            this.EmailIdTextBox.Name = "EmailIdTextBox";
            this.EmailIdTextBox.Size = new System.Drawing.Size(254, 26);
            this.EmailIdTextBox.TabIndex = 2;
            this.EmailIdTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.EmailIdTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.EmailIdTextBox_KeyPress);
            // 
            // CompanyNameTextBox
            // 
            this.CompanyNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CompanyNameTextBox.Location = new System.Drawing.Point(237, 40);
            this.CompanyNameTextBox.Name = "CompanyNameTextBox";
            this.CompanyNameTextBox.Size = new System.Drawing.Size(254, 26);
            this.CompanyNameTextBox.TabIndex = 0;
            this.CompanyNameTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.CompanyNameTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CompanyNameTextBox_KeyPress);
            // 
            // ColorSettingGroupBox
            // 
            this.ColorSettingGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ColorSettingGroupBox.Controls.Add(this.ChangeFormBackColor);
            this.ColorSettingGroupBox.Controls.Add(this.ChangeComNameColor);
            this.ColorSettingGroupBox.Controls.Add(this.ChangeComBackColor);
            this.ColorSettingGroupBox.Controls.Add(this.ColorSettingLabel);
            this.ColorSettingGroupBox.Location = new System.Drawing.Point(627, 137);
            this.ColorSettingGroupBox.Name = "ColorSettingGroupBox";
            this.ColorSettingGroupBox.Size = new System.Drawing.Size(587, 321);
            this.ColorSettingGroupBox.TabIndex = 1;
            this.ColorSettingGroupBox.TabStop = false;
            // 
            // ChangeFormBackColor
            // 
            this.ChangeFormBackColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChangeFormBackColor.Location = new System.Drawing.Point(405, 227);
            this.ChangeFormBackColor.Name = "ChangeFormBackColor";
            this.ChangeFormBackColor.Size = new System.Drawing.Size(112, 35);
            this.ChangeFormBackColor.TabIndex = 2;
            this.ChangeFormBackColor.Text = "Change";
            this.ChangeFormBackColor.UseVisualStyleBackColor = true;
            this.ChangeFormBackColor.Click += new System.EventHandler(this.ChangeFormBackColor_Click);
            // 
            // ChangeComNameColor
            // 
            this.ChangeComNameColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChangeComNameColor.Location = new System.Drawing.Point(405, 132);
            this.ChangeComNameColor.Name = "ChangeComNameColor";
            this.ChangeComNameColor.Size = new System.Drawing.Size(112, 35);
            this.ChangeComNameColor.TabIndex = 1;
            this.ChangeComNameColor.Text = "Change";
            this.ChangeComNameColor.UseVisualStyleBackColor = true;
            this.ChangeComNameColor.Click += new System.EventHandler(this.ChangeComNameColor_Click);
            // 
            // ChangeComBackColor
            // 
            this.ChangeComBackColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChangeComBackColor.Location = new System.Drawing.Point(405, 34);
            this.ChangeComBackColor.Name = "ChangeComBackColor";
            this.ChangeComBackColor.Size = new System.Drawing.Size(112, 35);
            this.ChangeComBackColor.TabIndex = 0;
            this.ChangeComBackColor.Text = "Change";
            this.ChangeComBackColor.UseVisualStyleBackColor = true;
            this.ChangeComBackColor.Click += new System.EventHandler(this.ChangeComBackColor_Click);
            // 
            // ColorSettingLabel
            // 
            this.ColorSettingLabel.AutoSize = true;
            this.ColorSettingLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ColorSettingLabel.Location = new System.Drawing.Point(44, 41);
            this.ColorSettingLabel.Name = "ColorSettingLabel";
            this.ColorSettingLabel.Size = new System.Drawing.Size(313, 220);
            this.ColorSettingLabel.TabIndex = 0;
            this.ColorSettingLabel.Text = "Change Company Name Background Color\r\n\r\n\r\n\r\n\r\nChange Company Name Color\r\n\r\n\r\n\r\n\r\n" +
    "Change Form Background Color";
            // 
            // LogoRectangle
            // 
            this.LogoRectangle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LogoRectangle.BackColor = System.Drawing.Color.Black;
            this.LogoRectangle.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.LogoRectangle.Location = new System.Drawing.Point(-3, 27);
            this.LogoRectangle.Name = "LogoRectangle";
            this.LogoRectangle.Size = new System.Drawing.Size(1257, 72);
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.LogoRectangle});
            this.shapeContainer1.Size = new System.Drawing.Size(1243, 712);
            this.shapeContainer1.TabIndex = 2;
            this.shapeContainer1.TabStop = false;
            // 
            // AvailabelStockLabel
            // 
            this.AvailabelStockLabel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.AvailabelStockLabel.AutoSize = true;
            this.AvailabelStockLabel.BackColor = System.Drawing.Color.Black;
            this.AvailabelStockLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AvailabelStockLabel.ForeColor = System.Drawing.Color.White;
            this.AvailabelStockLabel.Location = new System.Drawing.Point(386, 41);
            this.AvailabelStockLabel.Name = "AvailabelStockLabel";
            this.AvailabelStockLabel.Size = new System.Drawing.Size(471, 46);
            this.AvailabelStockLabel.TabIndex = 5;
            this.AvailabelStockLabel.Text = "Stock Management & Billig";
            this.AvailabelStockLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.AvailabelStockLabel.ClientSizeChanged += new System.EventHandler(this.AvailabelStockLabel_ClientSizeChanged);
            // 
            // CompanySettingsLabel
            // 
            this.CompanySettingsLabel.AutoSize = true;
            this.CompanySettingsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CompanySettingsLabel.Location = new System.Drawing.Point(25, 109);
            this.CompanySettingsLabel.Name = "CompanySettingsLabel";
            this.CompanySettingsLabel.Size = new System.Drawing.Size(179, 25);
            this.CompanySettingsLabel.TabIndex = 6;
            this.CompanySettingsLabel.Text = "Company Seetings";
            // 
            // ColorSettingsLabel
            // 
            this.ColorSettingsLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ColorSettingsLabel.AutoSize = true;
            this.ColorSettingsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ColorSettingsLabel.Location = new System.Drawing.Point(622, 109);
            this.ColorSettingsLabel.Name = "ColorSettingsLabel";
            this.ColorSettingsLabel.Size = new System.Drawing.Size(141, 25);
            this.ColorSettingsLabel.TabIndex = 6;
            this.ColorSettingsLabel.Text = "Color Seetings";
            // 
            // StockManageMenu
            // 
            this.StockManageMenu.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.StockManageMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stockManageToolStripMenuItem,
            this.toolStripMenuItem1,
            this.exitToolStripMenuItem});
            this.StockManageMenu.Location = new System.Drawing.Point(0, 0);
            this.StockManageMenu.Name = "StockManageMenu";
            this.StockManageMenu.Size = new System.Drawing.Size(1243, 29);
            this.StockManageMenu.TabIndex = 11;
            this.StockManageMenu.Text = "menuStrip1";
            // 
            // stockManageToolStripMenuItem
            // 
            this.stockManageToolStripMenuItem.Name = "stockManageToolStripMenuItem";
            this.stockManageToolStripMenuItem.Size = new System.Drawing.Size(54, 25);
            this.stockManageToolStripMenuItem.Text = "&Back";
            this.stockManageToolStripMenuItem.Click += new System.EventHandler(this.stockManageToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Enabled = false;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(26, 25);
            this.toolStripMenuItem1.Text = "|";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(46, 25);
            this.exitToolStripMenuItem.Text = "&Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // CompanySettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(1243, 712);
            this.Controls.Add(this.StockManageMenu);
            this.Controls.Add(this.ColorSettingsLabel);
            this.Controls.Add(this.CompanySettingsLabel);
            this.Controls.Add(this.AvailabelStockLabel);
            this.Controls.Add(this.ColorSettingGroupBox);
            this.Controls.Add(this.CompanySettingGroupBox);
            this.Controls.Add(this.shapeContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "CompanySettings";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CompanySettings";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CompanySettings_FormClosing);
            this.Load += new System.EventHandler(this.CompanySettings_Load);
            this.CompanySettingGroupBox.ResumeLayout(false);
            this.CompanySettingGroupBox.PerformLayout();
            this.ColorSettingGroupBox.ResumeLayout(false);
            this.ColorSettingGroupBox.PerformLayout();
            this.StockManageMenu.ResumeLayout(false);
            this.StockManageMenu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox CompanySettingGroupBox;
        private System.Windows.Forms.GroupBox ColorSettingGroupBox;
        private Microsoft.VisualBasic.PowerPacks.RectangleShape LogoRectangle;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private System.Windows.Forms.Label AvailabelStockLabel;
        private System.Windows.Forms.Label CompanySettingsLabel;
        private System.Windows.Forms.Label ColorSettingsLabel;
        private System.Windows.Forms.TextBox AddressTextBox;
        private System.Windows.Forms.TextBox DiscountTextBox;
        private System.Windows.Forms.TextBox SgstTextBox;
        private System.Windows.Forms.TextBox CgstTextBox;
        private System.Windows.Forms.TextBox GstNumberTextBox;
        private System.Windows.Forms.TextBox MobileNumberTextBox;
        private System.Windows.Forms.TextBox EmailIdTextBox;
        private System.Windows.Forms.TextBox CompanyNameTextBox;
        private System.Windows.Forms.Button SaveCompanySetting;
        private System.Windows.Forms.Label ColorSettingLabel;
        private System.Windows.Forms.Button ChangeComBackColor;
        private System.Windows.Forms.Button ChangeComNameColor;
        private System.Windows.Forms.Button ChangeFormBackColor;
        private System.Windows.Forms.Label CompanySettingLabel;
        private System.Windows.Forms.Button EditeButton;
        private System.Windows.Forms.MenuStrip StockManageMenu;
        private System.Windows.Forms.ToolStripMenuItem stockManageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
    }
}