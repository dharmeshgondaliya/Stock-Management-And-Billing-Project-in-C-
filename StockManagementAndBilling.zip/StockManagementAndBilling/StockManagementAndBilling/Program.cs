﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data.OleDb;

namespace StockManagementAndBilling
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            OleDbCommand cmd;
            OleDbDataReader reader;
            //Database Connection
            OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Application.StartupPath + "\\Database/StockManagement.accdb;Persist Security Info=False");
            con.Open();

            // Check Connection, if not then exit in Application
            if (con.State != System.Data.ConnectionState.Open)
            {
                DialogResult res = MessageBox.Show("Connection fail", "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (res == DialogResult.OK)
                {
                    Application.Exit();
                }
            }
            // company data
            cmd = new OleDbCommand("select * from CompanyInfo",con);
            reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                cmd = new OleDbCommand("select * from Login",con);
                reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    // show login form
                    Application.EnableVisualStyles();
                    Application.SetCompatibleTextRenderingDefault(false);
                    Application.Run(new LoginForm());
                }
                else {
                    // delete company and color table data and show create company form
                    cmd = new OleDbCommand("delete from CompanyInfo",con);
                    cmd.ExecuteNonQuery();
                    cmd = new OleDbCommand("delete from Colors",con);
                    cmd.ExecuteNonQuery();
                    Application.EnableVisualStyles();
                    Application.SetCompatibleTextRenderingDefault(false);
                    Application.Run(new CreateCompany());
                }
            }
            else {
                // show product key form
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new ProductKey());
            }
        }
    }
}