﻿namespace StockManagementAndBilling
{
    partial class UnpaidOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LogoRectangle = new Microsoft.VisualBasic.PowerPacks.RectangleShape();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.UnpaidOrderLabel = new System.Windows.Forms.Label();
            this.SearchButton = new System.Windows.Forms.Button();
            this.BillNumberTextBox = new System.Windows.Forms.TextBox();
            this.SearchGroupBox = new System.Windows.Forms.GroupBox();
            this.BillNumberLabel = new System.Windows.Forms.Label();
            this.InfoGroupBox = new System.Windows.Forms.GroupBox();
            this.CancleButton = new System.Windows.Forms.Button();
            this.PaymentButton = new System.Windows.Forms.Button();
            this.TotalAmount = new System.Windows.Forms.Label();
            this.TotalAmountLabel = new System.Windows.Forms.Label();
            this.TransactionDate = new System.Windows.Forms.Label();
            this.CoustomerName = new System.Windows.Forms.Label();
            this.TransactionDateLabel = new System.Windows.Forms.Label();
            this.CoustomerNameLabel = new System.Windows.Forms.Label();
            this.UnpaidOrderMenu = new System.Windows.Forms.MenuStrip();
            this.stockManageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.UnpaidOrderPrintDocument = new System.Drawing.Printing.PrintDocument();
            this.SearchGroupBox.SuspendLayout();
            this.InfoGroupBox.SuspendLayout();
            this.UnpaidOrderMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // LogoRectangle
            // 
            this.LogoRectangle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LogoRectangle.BackColor = System.Drawing.Color.Black;
            this.LogoRectangle.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque;
            this.LogoRectangle.BorderColor = System.Drawing.Color.White;
            this.LogoRectangle.Location = new System.Drawing.Point(-6, 28);
            this.LogoRectangle.Name = "LogoRectangle";
            this.LogoRectangle.Size = new System.Drawing.Size(782, 67);
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.LogoRectangle});
            this.shapeContainer1.Size = new System.Drawing.Size(767, 545);
            this.shapeContainer1.TabIndex = 0;
            this.shapeContainer1.TabStop = false;
            // 
            // UnpaidOrderLabel
            // 
            this.UnpaidOrderLabel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.UnpaidOrderLabel.AutoSize = true;
            this.UnpaidOrderLabel.BackColor = System.Drawing.Color.Black;
            this.UnpaidOrderLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UnpaidOrderLabel.ForeColor = System.Drawing.Color.White;
            this.UnpaidOrderLabel.Location = new System.Drawing.Point(148, 39);
            this.UnpaidOrderLabel.Name = "UnpaidOrderLabel";
            this.UnpaidOrderLabel.Size = new System.Drawing.Size(471, 46);
            this.UnpaidOrderLabel.TabIndex = 5;
            this.UnpaidOrderLabel.Text = "Stock Management & Billig";
            this.UnpaidOrderLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.UnpaidOrderLabel.ClientSizeChanged += new System.EventHandler(this.UnpaidOrderLabel_ClientSizeChanged);
            // 
            // SearchButton
            // 
            this.SearchButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.SearchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchButton.Location = new System.Drawing.Point(419, 24);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(150, 34);
            this.SearchButton.TabIndex = 1;
            this.SearchButton.Text = "  Search";
            this.SearchButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.SearchButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.SearchButton.UseVisualStyleBackColor = true;
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // BillNumberTextBox
            // 
            this.BillNumberTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BillNumberTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BillNumberTextBox.Location = new System.Drawing.Point(138, 28);
            this.BillNumberTextBox.Name = "BillNumberTextBox";
            this.BillNumberTextBox.Size = new System.Drawing.Size(227, 30);
            this.BillNumberTextBox.TabIndex = 0;
            this.BillNumberTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BillNumberTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.BillNumberTextBox_KeyPress);
            // 
            // SearchGroupBox
            // 
            this.SearchGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.SearchGroupBox.Controls.Add(this.BillNumberLabel);
            this.SearchGroupBox.Controls.Add(this.SearchButton);
            this.SearchGroupBox.Controls.Add(this.BillNumberTextBox);
            this.SearchGroupBox.Location = new System.Drawing.Point(80, 125);
            this.SearchGroupBox.Name = "SearchGroupBox";
            this.SearchGroupBox.Size = new System.Drawing.Size(606, 76);
            this.SearchGroupBox.TabIndex = 8;
            this.SearchGroupBox.TabStop = false;
            // 
            // BillNumberLabel
            // 
            this.BillNumberLabel.AutoSize = true;
            this.BillNumberLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BillNumberLabel.Location = new System.Drawing.Point(18, 29);
            this.BillNumberLabel.Name = "BillNumberLabel";
            this.BillNumberLabel.Size = new System.Drawing.Size(111, 25);
            this.BillNumberLabel.TabIndex = 8;
            this.BillNumberLabel.Text = "Bill Number";
            // 
            // InfoGroupBox
            // 
            this.InfoGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.InfoGroupBox.Controls.Add(this.CancleButton);
            this.InfoGroupBox.Controls.Add(this.PaymentButton);
            this.InfoGroupBox.Controls.Add(this.TotalAmount);
            this.InfoGroupBox.Controls.Add(this.TotalAmountLabel);
            this.InfoGroupBox.Controls.Add(this.TransactionDate);
            this.InfoGroupBox.Controls.Add(this.CoustomerName);
            this.InfoGroupBox.Controls.Add(this.TransactionDateLabel);
            this.InfoGroupBox.Controls.Add(this.CoustomerNameLabel);
            this.InfoGroupBox.Location = new System.Drawing.Point(80, 207);
            this.InfoGroupBox.Name = "InfoGroupBox";
            this.InfoGroupBox.Size = new System.Drawing.Size(606, 296);
            this.InfoGroupBox.TabIndex = 9;
            this.InfoGroupBox.TabStop = false;
            // 
            // CancleButton
            // 
            this.CancleButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.CancleButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CancleButton.Location = new System.Drawing.Point(299, 198);
            this.CancleButton.Name = "CancleButton";
            this.CancleButton.Size = new System.Drawing.Size(157, 49);
            this.CancleButton.TabIndex = 2;
            this.CancleButton.Text = "Cancle";
            this.CancleButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.CancleButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.CancleButton.UseVisualStyleBackColor = true;
            this.CancleButton.Click += new System.EventHandler(this.CancleButton_Click);
            // 
            // PaymentButton
            // 
            this.PaymentButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.PaymentButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PaymentButton.Location = new System.Drawing.Point(76, 198);
            this.PaymentButton.Name = "PaymentButton";
            this.PaymentButton.Size = new System.Drawing.Size(157, 49);
            this.PaymentButton.TabIndex = 3;
            this.PaymentButton.Text = "Pay";
            this.PaymentButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.PaymentButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.PaymentButton.UseVisualStyleBackColor = true;
            this.PaymentButton.Click += new System.EventHandler(this.PaymentButton_Click);
            // 
            // TotalAmount
            // 
            this.TotalAmount.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.TotalAmount.AutoSize = true;
            this.TotalAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalAmount.Location = new System.Drawing.Point(295, 150);
            this.TotalAmount.Name = "TotalAmount";
            this.TotalAmount.Size = new System.Drawing.Size(0, 25);
            this.TotalAmount.TabIndex = 10;
            // 
            // TotalAmountLabel
            // 
            this.TotalAmountLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.TotalAmountLabel.AutoSize = true;
            this.TotalAmountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalAmountLabel.Location = new System.Drawing.Point(72, 150);
            this.TotalAmountLabel.Name = "TotalAmountLabel";
            this.TotalAmountLabel.Size = new System.Drawing.Size(140, 25);
            this.TotalAmountLabel.TabIndex = 10;
            this.TotalAmountLabel.Text = "Total Amount :";
            // 
            // TransactionDate
            // 
            this.TransactionDate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.TransactionDate.AutoSize = true;
            this.TransactionDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TransactionDate.Location = new System.Drawing.Point(295, 97);
            this.TransactionDate.Name = "TransactionDate";
            this.TransactionDate.Size = new System.Drawing.Size(0, 25);
            this.TransactionDate.TabIndex = 10;
            // 
            // CoustomerName
            // 
            this.CoustomerName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.CoustomerName.AutoSize = true;
            this.CoustomerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CoustomerName.Location = new System.Drawing.Point(295, 44);
            this.CoustomerName.Name = "CoustomerName";
            this.CoustomerName.Size = new System.Drawing.Size(0, 25);
            this.CoustomerName.TabIndex = 10;
            // 
            // TransactionDateLabel
            // 
            this.TransactionDateLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.TransactionDateLabel.AutoSize = true;
            this.TransactionDateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TransactionDateLabel.Location = new System.Drawing.Point(72, 97);
            this.TransactionDateLabel.Name = "TransactionDateLabel";
            this.TransactionDateLabel.Size = new System.Drawing.Size(172, 25);
            this.TransactionDateLabel.TabIndex = 10;
            this.TransactionDateLabel.Text = "Transaction Date :";
            // 
            // CoustomerNameLabel
            // 
            this.CoustomerNameLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.CoustomerNameLabel.AutoSize = true;
            this.CoustomerNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CoustomerNameLabel.Location = new System.Drawing.Point(72, 44);
            this.CoustomerNameLabel.Name = "CoustomerNameLabel";
            this.CoustomerNameLabel.Size = new System.Drawing.Size(176, 25);
            this.CoustomerNameLabel.TabIndex = 10;
            this.CoustomerNameLabel.Text = "Coustomer Name :";
            // 
            // UnpaidOrderMenu
            // 
            this.UnpaidOrderMenu.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.UnpaidOrderMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stockManageToolStripMenuItem,
            this.toolStripMenuItem1,
            this.exitToolStripMenuItem});
            this.UnpaidOrderMenu.Location = new System.Drawing.Point(0, 0);
            this.UnpaidOrderMenu.Name = "UnpaidOrderMenu";
            this.UnpaidOrderMenu.Size = new System.Drawing.Size(767, 29);
            this.UnpaidOrderMenu.TabIndex = 12;
            this.UnpaidOrderMenu.Text = "menuStrip1";
            // 
            // stockManageToolStripMenuItem
            // 
            this.stockManageToolStripMenuItem.Name = "stockManageToolStripMenuItem";
            this.stockManageToolStripMenuItem.Size = new System.Drawing.Size(54, 25);
            this.stockManageToolStripMenuItem.Text = "&Back";
            this.stockManageToolStripMenuItem.Click += new System.EventHandler(this.stockManageToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Enabled = false;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(26, 25);
            this.toolStripMenuItem1.Text = "|";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(46, 25);
            this.exitToolStripMenuItem.Text = "&Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // UnpaidOrderPrintDocument
            // 
            this.UnpaidOrderPrintDocument.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.UnpaidOrderPrintDocument_PrintPage);
            // 
            // UnpaidOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(767, 545);
            this.Controls.Add(this.UnpaidOrderMenu);
            this.Controls.Add(this.InfoGroupBox);
            this.Controls.Add(this.SearchGroupBox);
            this.Controls.Add(this.UnpaidOrderLabel);
            this.Controls.Add(this.shapeContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MinimizeBox = false;
            this.Name = "UnpaidOrder";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "UnpaidOrder";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.UnpaidOrder_FormClosing);
            this.Load += new System.EventHandler(this.UnpaidOrder_Load);
            this.SearchGroupBox.ResumeLayout(false);
            this.SearchGroupBox.PerformLayout();
            this.InfoGroupBox.ResumeLayout(false);
            this.InfoGroupBox.PerformLayout();
            this.UnpaidOrderMenu.ResumeLayout(false);
            this.UnpaidOrderMenu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Microsoft.VisualBasic.PowerPacks.RectangleShape LogoRectangle;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private System.Windows.Forms.Label UnpaidOrderLabel;
        private System.Windows.Forms.Button SearchButton;
        private System.Windows.Forms.TextBox BillNumberTextBox;
        private System.Windows.Forms.GroupBox SearchGroupBox;
        private System.Windows.Forms.Label BillNumberLabel;
        private System.Windows.Forms.GroupBox InfoGroupBox;
        private System.Windows.Forms.Button PaymentButton;
        private System.Windows.Forms.Label TotalAmount;
        private System.Windows.Forms.Label TotalAmountLabel;
        private System.Windows.Forms.Label TransactionDate;
        private System.Windows.Forms.Label CoustomerName;
        private System.Windows.Forms.Label TransactionDateLabel;
        private System.Windows.Forms.Label CoustomerNameLabel;
        private System.Windows.Forms.Button CancleButton;
        private System.Windows.Forms.MenuStrip UnpaidOrderMenu;
        private System.Windows.Forms.ToolStripMenuItem stockManageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Drawing.Printing.PrintDocument UnpaidOrderPrintDocument;

    }
}