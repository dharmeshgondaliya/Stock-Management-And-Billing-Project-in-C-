﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace StockManagementAndBilling
{
    public partial class UserManageForm : Form
    {
        String nm,fname = "",lname = "",compareUser = "";
        int btn = 0;
        OleDbConnection con;
        OleDbCommand cmd;
        OleDbDataReader reader;
        public UserManageForm()
        {
            InitializeComponent();
        }

        private void UserManageForm_Load(object sender, EventArgs e)
        {
            CompanySetting();
            //Database Connection
            con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source="+Application.StartupPath+"\\Database/StockManagement.accdb;Persist Security Info=False");
            con.Open();

            // Check Connection, if not then exit in Application
            if(con.State != ConnectionState.Open){
                DialogResult res =  MessageBox.Show("Connection fail","Connection Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                if(res == DialogResult.OK){
                    Application.Exit();
                }
            }

            // Set Icon for Button
            InsertButton.Image = Image.FromFile(Application.StartupPath + "/icons/Add New.png");
            AddNewUserButton.Image = Image.FromFile(Application.StartupPath + "/icons/Add New.png");
            UpdateUserButton.Image = Image.FromFile(Application.StartupPath + "/icons/Update.png");
            DeleteUserButton.Image = Image.FromFile(Application.StartupPath + "/icons/Delete.png");
            OkButton.Image = Image.FromFile(Application.StartupPath + "/icons/OK.png");
            CancelButton.Image = Image.FromFile(Application.StartupPath + "/icons/Cancel.png");
            
            // Button And Text Enabled true/false
            enabledtf(false);
            userbutton(true);
            UserComboBox.Enabled = false;
            OkButton.Enabled = false;
            AddNewUserButton.Focus();
            this.WindowState = FormWindowState.Maximized;
        }

        private void CompanySetting()
        {
            // set company name and color
            CompanyClass Company = new CompanyClass();
            UserManagementLabel.Text = Company.CompanyName.ToString();
            UserManagementLabel.ForeColor = System.Drawing.ColorTranslator.FromHtml(Company.NameColor.ToString());
            UserManagementLabel.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.NameBackColor.ToString());
            UserManageRectangle.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.NameBackColor.ToString());
            // form color
            this.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.FormBackColor.ToString());
        }
        private void MobileNumberTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Enter only Number
            if (e.KeyChar >= 48 && e.KeyChar <= 57 || e.KeyChar == 8 || e.KeyChar == 13)
            {
                if(e.KeyChar == 13 && MobileNumberTextBox.Text != "")
                {
                    AddressTextBox.Focus();
                }
                else
                {
                    e.Handled = false;
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void AddressTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // enter address
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122 || e.KeyChar >= 48 && e.KeyChar <= 57 || e.KeyChar == 13 || e.KeyChar == 8 || e.KeyChar == 32 || e.KeyChar == 46 || e.KeyChar == 13 || e.KeyChar == 44)
            {
                if(e.KeyChar == 13 && AddressTextBox.Text != "")
                {
                    SelectUserComboBox.Focus();
                }
                else
                {
                    e.Handled = false;
                }
            }
            else
            {
                e.Handled = true;
            }
        }
        
        private void NameValidation(object sender, KeyPressEventArgs e)
        {
            // Enter Only Characters(String)
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122 || e.KeyChar == 8 || e.KeyChar == 13)
            {
                if (e.KeyChar == 13)
                {
                    if (sender == FirstNameTextBox && FirstNameTextBox.Text != "")
                    {
                        LastNameTextBox.Focus();
                    }
                    if (sender == LastNameTextBox && LastNameTextBox.Text != "")
                    {
                        UserIdTextBox.Focus();
                    }
                }
                else
                {
                    e.Handled = false;
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void UserIdTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Enter only number and a-z and A-Z
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122 || e.KeyChar == 13 || e.KeyChar >= 48 && e.KeyChar <= 57 || e.KeyChar == 8 || e.KeyChar == 32 || e.KeyChar == 46)
            {
                if(e.KeyChar == 13)
                {
                    PasswordTextBox.Focus();
                }
                else
                {
                    e.Handled = false;
                }
            }
            else
            {
                e.Handled = true;
            }
        }
        private void PasswordTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == 13 && PasswordTextBox.Text != ""){
                MobileNumberTextBox.Focus();
            }
        }
        private void enabledtf(Boolean tf)
        {
            // Button And Textbox Enabled true/false
            FirstNameTextBox.Enabled = tf;
            LastNameTextBox.Enabled = tf;
            UserIdTextBox.Enabled = tf;
            PasswordTextBox.Enabled = tf;
            MobileNumberTextBox.Enabled = tf;
            AddressTextBox.Enabled = tf;
            SelectUserComboBox.Enabled = tf;
            InsertButton.Enabled = tf;
            CancelButton.Enabled = tf;
        }
        private void TextboxEmpty()
        {
            // Empty Texrbox Value
            FirstNameTextBox.Text = "";
            LastNameTextBox.Text = "";
            UserIdTextBox.Text = "";
            PasswordTextBox.Text = "";
            MobileNumberTextBox.Text = "";
            AddressTextBox.Text = "";
            SelectUserComboBox.SelectedIndex = -1;
        }
        private Boolean TextboxValidation()
        {
            //TextBox Validation
            if (FirstNameTextBox.Text.Trim() == "" || LastNameTextBox.Text.Trim() == "")
            {
                MessageBox.Show("Please Enter Your Name","Enter Name",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return false;
            }
            if (UserIdTextBox.Text.Trim() == "")
            {
                MessageBox.Show("Please Enter User Id","Enter User Id",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return false;
            }
            if (PasswordTextBox.Text.Trim() == "")
            {
                MessageBox.Show("Please Enter Password", "Enter Password", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (MobileNumberTextBox.Text.Trim() == "")
            {
                MessageBox.Show("Please Enter Mobile Number", "Enter Mobile Number", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (MobileNumberTextBox.Text.Length < 10)
            {
                MessageBox.Show("Please Enter Valid Mobile Number", "Enter Mobile Number", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (AddressTextBox.Text.Trim() == "")
            {
                MessageBox.Show("Please Enter Address", "Enter Address", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (SelectUserComboBox.SelectedIndex == -1)
            {
                MessageBox.Show("Please Select User Type", "Select User Type", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }
        private void userbutton(Boolean tf) {
            // Main Button true/false
            AddNewUserButton.Enabled = tf;
            UpdateUserButton.Enabled = tf;
            DeleteUserButton.Enabled = tf;
        }
        private void AddNewUserButton_Click(object sender, EventArgs e)
        {
            // button enabled true / false
            btn = 1;
            InsertButton.Text = "  Add User";
            InsertButton.Image = Image.FromFile(Application.StartupPath + "/icons/Add New.png");
            enabledtf(true);
            UserComboBox.Enabled = false;
            OkButton.Enabled = false;
            DeleteUserButton.Enabled = false;
            UpdateUserButton.Enabled = false;
            FirstNameTextBox.Focus();
        }

        private void UpdateUserButton_Click(object sender, EventArgs e)
        {
            // button enabled true / false
            btn = 2;
            InsertButton.Text = "  Update";
            InsertButton.Image = Image.FromFile(Application.StartupPath + "/icons/Update.png");
            enabledtf(false);
            UserComboBox.Enabled = true;
            OkButton.Enabled = true;
            DeleteUserButton.Enabled = false;
            AddNewUserButton.Enabled = false;
            ComboBoxValue();
        }

        private void DeleteUserButton_Click(object sender, EventArgs e)
        {
            // button enabled true / false
            btn = 3;
            InsertButton.Text = "  Delete";
            InsertButton.Image = Image.FromFile(Application.StartupPath + "/icons/Delete.png");
            enabledtf(false);
            UserComboBox.Enabled = true;
            OkButton.Enabled = true;
            AddNewUserButton.Enabled = false;
            UpdateUserButton.Enabled = false;
            ComboBoxValue();
        }

        private void InsertButton_Click(object sender, EventArgs e)
        {
            // Call Specific Methods
            if (TextboxValidation())
            {
                if (InsertButton.Text == "  Add User" && btn == 1)
                {
                    insertdata();
                    return;
                }
                if (InsertButton.Text == "  Update" && btn == 2)
                {
                    updatedata();
                    return;
                }
                if (InsertButton.Text == "  Delete" && btn == 3)
                {
                    deletedata();
                    return;
                }
                if(btn != 0){
                    btn = 0;
                }
            }
        }
        
        
        private void insertdata()
        {
            // Insert User data
            String name = FirstNameTextBox.Text + " " + LastNameTextBox.Text.Trim();
            String userid = UserIdTextBox.Text.Trim();
            String password = PasswordTextBox.Text.Trim();
            String mobile = MobileNumberTextBox.Text.Trim();
            String Address = AddressTextBox.Text.Trim();
            String user = SelectUserComboBox.SelectedItem.ToString();

            try{
                cmd = new OleDbCommand("select UserId from Login",con);
                reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    // user id from user exist or not. if exis then not insert data
                    if (userid == reader["UserId"].ToString())
                    {
                        MessageBox.Show(userid + " user Id Is Not Available, Please Enter Another User ID", "Enter Another User Id", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        UserIdTextBox.Text = "";
                        UserIdTextBox.Focus();
                        return;
                    }
                }

                String query = "insert into Login(Name,UserId,Pass,Mobile,Addr,Utype) values('" + name + "','" + userid + "','" + password + "','" + mobile + "','" + Address + "','" + user + "')";
                cmd = new OleDbCommand(query,con);
                cmd.ExecuteNonQuery();
            }
            catch(Exception ex){
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            MessageBox.Show("Record insert Successful", "Record Insert", MessageBoxButtons.OK, MessageBoxIcon.Information);
            // empty textbox and button enabled true / false
            TextboxEmpty();
            enabledtf(false);
            AddNewUserButton.Enabled = true;
            UpdateUserButton.Enabled = true;
            DeleteUserButton.Enabled = true;
            UserComboBox.Enabled = false;
            OkButton.Enabled = false;
        }
        private void ComboBoxValue(){
            // Add Items(User Names) in Combobox
            UserComboBox.Items.Clear();
            try
            {
                cmd = new OleDbCommand("select Name from Login", con);
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    UserComboBox.Items.Add(reader["Name"].ToString());
                }
            }
            catch(Exception ex){
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }
        private void updatedata()
        {
            // update data from database
            String ufullnm = fname + " " + lname;
            String uFullName = FirstNameTextBox.Text + " " + LastNameTextBox.Text.Trim(); ;
            String uUid = UserIdTextBox.Text.Trim();
            String upass = PasswordTextBox.Text.Trim();
            String umob = MobileNumberTextBox.Text.Trim();
            String uadd = AddressTextBox.Text.Trim();
            String uutype = SelectUserComboBox.SelectedItem.ToString();

            try{
                if(compareUser != uUid)
                {
                    cmd = new OleDbCommand("select UserId from Login", con);
                    reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        // check user id from database exist or not. if exist then not update data
                        if (uUid == reader["UserId"].ToString())
                        {
                            MessageBox.Show(uUid + " user Id Is Not Available, Please Enter Another User ID", "Enter Another UserId", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            UserIdTextBox.Text = "";
                            UserIdTextBox.Focus();
                            return;
                        }
                    }
                }
                cmd = new OleDbCommand();
                cmd.Connection = con;
                cmd.CommandText = "update Login set Name='" + uFullName + "',UserId='" + uUid + "',Pass='" + upass + "',Mobile='" + umob +"',Addr='"+uadd+"',Utype='"+uutype+"' where Name='"+ufullnm+"'";
                cmd.ExecuteNonQuery();
            }
            catch(Exception ex){
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            MessageBox.Show("Record Update Successful", "Record Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
            // button enabled true / false
            enabledtf(false);
            TextboxEmpty();
            userbutton(true);
            UserComboBox.SelectedIndex = -1;
            UserComboBox.Enabled = false;
            OkButton.Enabled = false;
        }
        private void deletedata()
        {
            // Delete user Data
            String nm = fname+" "+lname;
            cmd = new OleDbCommand("delete from Login where Name='"+nm+"'",con);
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch(Exception ex){
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            MessageBox.Show("Record Delete Successful", "Record Delete", MessageBoxButtons.OK, MessageBoxIcon.Information);
            // textbox empty and button enabled true / false
            TextboxEmpty();
            enabledtf(false);
            CancelButton.Enabled = false;
            userbutton(true);
            UserComboBox.Enabled = false;
            UserComboBox.SelectedIndex = -1;
            OkButton.Enabled = false;
        }

        private void OkButton_Click(object sender, EventArgs e)
        {
            // check user name select or not
            if(UserComboBox.SelectedIndex == -1){
                MessageBox.Show("Please Select User Name", "Select User Name", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else{
                nm = UserComboBox.SelectedItem.ToString();
                setdata();            
            }
        }

        private void setdata() {
            // Set Data in Textbox
            try
            {
                cmd = new OleDbCommand("select * from Login where Name = '" + nm + "'", con);
                reader = cmd.ExecuteReader();
                reader.Read();
            }
            catch(Exception ex){
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            String name;
            name = reader["Name"].ToString();
            int i = name.IndexOf(" ");
            lname = name.Substring(i+1);
            fname = name.Remove(i);
            compareUser = reader["UserId"].ToString();
            // set data in textbox
            FirstNameTextBox.Text = fname.ToString();
            LastNameTextBox.Text = lname.ToString(); ;
            UserIdTextBox.Text = reader["UserId"].ToString();
            PasswordTextBox.Text = reader["Pass"].ToString();
            MobileNumberTextBox.Text = reader["Mobile"].ToString();
            AddressTextBox.Text = reader["Addr"].ToString();
            SelectUserComboBox.SelectedItem = reader["Utype"].ToString();
            enabledtf(true);
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            // button enabled true / false. and textbox empty
            TextboxEmpty();
            enabledtf(false);
            userbutton(true);
            UserComboBox.SelectedIndex = -1;
            UserComboBox.Enabled = false;
            OkButton.Enabled = false;
            InsertButton.Text = "Add User";
            InsertButton.Image = Image.FromFile(Application.StartupPath + "/icons/Add New.png");
            btn = 0;
        }

        private void UserManageForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.con.Close();
            this.Hide();
        }

        private void stockManageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.con.Close();
            this.Close();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void UserManagementLabel_ClientSizeChanged(object sender, EventArgs e)
        {
            UserManagementLabel.Left = (this.ClientSize.Width - UserManagementLabel.Size.Width) / 2;
        }

    }
}
