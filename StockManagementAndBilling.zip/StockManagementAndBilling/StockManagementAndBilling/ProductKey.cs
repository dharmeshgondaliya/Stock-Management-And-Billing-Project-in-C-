﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Mail;

namespace StockManagementAndBilling
{
    public partial class ProductKey : Form
    {
        String com;
        int i = 0;
        public ProductKey()
        {
            InitializeComponent();
        }

        private void KeyPressEvent(object sender, KeyPressEventArgs e)
        {
            // enter only number and capital character
            if (e.KeyChar >= 48 && e.KeyChar <= 57 || e.KeyChar == 8 || e.KeyChar >= 65 && e.KeyChar <= 90)
            {
                e.Handled = false;
            }
            else {
                e.Handled = true;
            }
        }

        private void KeyDownEvent(object sender, KeyEventArgs e)
        {
            // set focus
            if (sender == FirstTextBox && FirstTextBox.Text.Length == 3)
            {
                SecondTextBox.Focus();
            }
            if (sender == SecondTextBox && SecondTextBox.Text.Length == 3)
            {
                ThirdTextBox.Focus();
            }
            if (sender == ThirdTextBox && ThirdTextBox.Text.Length == 3)
            {
                FourthTextBox.Focus();
            }
            if (sender == FourthTextBox && FourthTextBox.Text.Length == 3)
            {
                SubmitButton.Focus();
            }
        }


        private void GenerateButton_Click(object sender, EventArgs e)
        {
            // send (product key) email from developer
            try
            {
                MailMessage msg = new MailMessage();
                msg.From = new MailAddress("stockmanagement.sm@gmail.com");
                msg.To.Add("gondaliyadharmesh.gd@gmail.com");
                msg.Subject = "Stock Management Software Product Key";
                msg.Body = "Key: "+Generate() + " Date: " + DateTime.Now.ToLongDateString() + "  Time:- " + DateTime.Now.ToLongTimeString() + "  IP:- " + Dns.GetHostByName(Dns.GetHostName()).AddressList[0].ToString();

                SmtpClient smt = new SmtpClient();
                smt.Host = "smtp.gmail.com";
                System.Net.NetworkCredential ntcd = new NetworkCredential();
                ntcd.UserName = "stockmanagement.sm@gmail.com";
                ntcd.Password = "stockmanagement";
                smt.Credentials = ntcd;
                smt.EnableSsl = true;
                smt.Port = 587;
                smt.Send(msg);
            }
            catch(Exception ex){
                MessageBox.Show(ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }
            FirstTextBox.Focus();
        }

        private String Generate() {
            // generate key data and store variable
            Random r = new Random();
            int no1 = r.Next(0, 9);
            int no2 = r.Next(0, 9);
            int no3 = r.Next(0, 9);
            int no4 = r.Next(0, 9);
            int no5 = r.Next(0, 9);
            int no6 = r.Next(0, 9);
            int no7 = r.Next(0, 9);
            int no8 = r.Next(0, 9);
            Char ch1 = (Char)r.Next('A', 'Z');
            Char ch2 = (Char)r.Next('A', 'Z');
            Char ch3 = (Char)r.Next('A', 'Z');
            Char ch4 = (Char)r.Next('A', 'Z');
            Char ch5 = (Char)r.Next('A', 'Z');
            Char ch6 = (Char)r.Next('A', 'Z');
            Char ch7 = (Char)r.Next('A', 'Z');
            Char ch8 = (Char)r.Next('A', 'Z');
            return com = no1 + "" + ch1 + "" + no2 + "" + ch3 + "-" + no3 + "" + ch3 + "" + no4 + "" + ch4 + "-" + no5 + "" + ch5 + "" + no6 + "" + ch6 + "-" + no7 + "" + ch7 + "" + no8 + "" + ch8;    
        }
        private void SubmitButton_Click(object sender, EventArgs e)
        {
            // check product key
            i++;
            String Pass = FirstTextBox.Text+ "-"+SecondTextBox.Text+"-"+ThirdTextBox.Text+"-"+FourthTextBox.Text;
            if (Pass == com)
            {
                CreateCompany CC = new CreateCompany();
                CC.Show();
                this.Hide();
            }
            else {
                MessageBox.Show("Enter Valid Product Key","Enter Valid Key",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }
            if(i >= 3){
                Application.Exit();
            }
            FirstTextBox.Clear();
            SecondTextBox.Clear();
            ThirdTextBox.Clear();
            FourthTextBox.Clear();
        }

        private void ProductKey_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();    
        }

        private void ProductKey_Load(object sender, EventArgs e)
        {

        }

    }
}
