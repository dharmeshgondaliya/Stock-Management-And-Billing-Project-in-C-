﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace StockManagementAndBilling
{
    public partial class AvailableStockForm : Form
    {
        OleDbConnection con;
        OleDbCommand cmd;
        OleDbDataReader reader;
        OleDbDataAdapter da;
        DataTable dt;
        String query;
        public AvailableStockForm()
        {
            InitializeComponent();
        }

        private void AvailableStockForm_Load(object sender, EventArgs e)
        {
            CompanySetting();
            //Database Connection
            con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Application.StartupPath + "\\Database/StockManagement.accdb;Persist Security Info=False");
            con.Open();

            // Check Connection, if not then exit in Application
            if (con.State != ConnectionState.Open)
            {
                DialogResult res = MessageBox.Show("Connection fail", "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (res == DialogResult.OK)
                {
                    Application.Exit();
                }
            }
            query = "select iName AS [Item Name],iPrice AS [Item Price],iQuentity AS [Item Quantity],cName AS [Company Name] from Stock";
            SearchButton.Image = Image.FromFile(Application.StartupPath+"/icons/Search.png");
            setdata();
            SelectItemComboBox.SelectedIndex = -1;
            SelectCompanyComboBox.SelectedIndex = -1;
            ShowDataGridView(query);
            this.WindowState = FormWindowState.Maximized;
        }

        private void CompanySetting()
        {
            CompanyClass Company = new CompanyClass();
            //company name
            AvailabelStockLabel.Text = Company.CompanyName.ToString();
            //logo color
            AvailabelStockLabel.ForeColor = System.Drawing.ColorTranslator.FromHtml(Company.NameColor.ToString());
            AvailabelStockLabel.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.NameBackColor.ToString());
            LogoRectangle.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.NameBackColor.ToString());
            this.BackColor = System.Drawing.ColorTranslator.FromHtml(Company.FormBackColor.ToString());
        }

        private void setdata()
        {
            // Set Data in ComboBox
            SelectItemComboBox.Items.Clear();
            SelectCompanyComboBox.Items.Clear();
            SelectItemComboBox.Items.Add("All");
            SelectCompanyComboBox.Items.Add("All");
            try{
                cmd = new OleDbCommand("select Distinct iName from Stock",con);
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    SelectItemComboBox.Items.Add(reader["iName"].ToString());
                }
                cmd = new OleDbCommand("select Distinct cName from Stock", con);
                reader = cmd.ExecuteReader();
                while(reader.Read()){
                    SelectCompanyComboBox.Items.Add(reader["cName"].ToString());
                }
            }
            catch(Exception ex){
                MessageBox.Show(ex.Message);
                return;
            }
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            // select all
            if((SelectItemComboBox.SelectedIndex == -1 || SelectItemComboBox.SelectedItem.ToString() == "All") && (SelectCompanyComboBox.SelectedIndex == -1 || SelectCompanyComboBox.SelectedItem.ToString() == "All")){
                query = "select iName AS [Item Name],iPrice AS [Item Price],iQuentity AS [Item Quantity],cName AS [Company Name] from Stock";
            }
            // select item
            if((SelectItemComboBox.SelectedIndex != -1 && SelectItemComboBox.SelectedItem.ToString() != "All") && (SelectCompanyComboBox.SelectedIndex == -1 || SelectCompanyComboBox.SelectedItem.ToString() == "All")){
                query = "select iName AS [Item Name],iPrice AS [Item Price],iQuentity AS [Item Quantity],cName AS [Company Name] from Stock where iName = '" + SelectItemComboBox.SelectedItem.ToString() + "'";
            }
            // select company           
            if((SelectCompanyComboBox.SelectedIndex != -1 && SelectCompanyComboBox.SelectedItem.ToString() != "All") && (SelectItemComboBox.SelectedIndex == -1 || SelectItemComboBox.SelectedItem.ToString() == "All")){
                query = "select iName AS [Item Name],iPrice AS [Item Price],iQuentity AS [Item Quantity],cName AS [Company Name] from Stock where cName = '" + SelectCompanyComboBox.SelectedItem.ToString() + "'";
            }
            // select item & company
            if ((SelectItemComboBox.SelectedIndex != -1 && SelectItemComboBox.SelectedItem.ToString() != "All") && (SelectCompanyComboBox.SelectedIndex != -1 && SelectCompanyComboBox.SelectedItem.ToString() != "All")){
                query = "select iName AS [Item Name],iPrice AS [Item Price],iQuentity AS [Item Quantity],cName AS [Company Name] from Stock where iName = '" + SelectItemComboBox.SelectedItem.ToString() + "' and cName = '" + SelectCompanyComboBox.SelectedItem.ToString() + "'";
            }

            ShowDataGridView(query);
        }

        private void ShowDataGridView(String equery)
        {
            // datagridview store data
            StockDataGridView.DataSource = null;
            try
            {
                cmd = con.CreateCommand();
                cmd.CommandText = equery;
                cmd.ExecuteNonQuery();
                dt = new DataTable();
                da = new OleDbDataAdapter(cmd);
                da.Fill(dt);
                StockDataGridView.DataSource = dt;
            }
            catch(Exception ex){
                MessageBox.Show(ex.Message);
                return;
            }
        }

        private void AvailableStockForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.con.Close();
            this.Hide();
        }

        private void stockManageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.con.Close();
            this.Close();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void AvailabelStockLabel_ClientSizeChanged(object sender, EventArgs e)
        {
            AvailabelStockLabel.Left = (this.ClientSize.Width - AvailabelStockLabel.Size.Width) / 2;
        }

    }
}
